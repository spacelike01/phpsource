<?php

$this->_upgradeDatabase('2.0.0rc10');

$bCompleted = true;

?>