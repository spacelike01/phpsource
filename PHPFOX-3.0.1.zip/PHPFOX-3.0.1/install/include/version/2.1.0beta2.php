<?php

$this->_upgradeDatabase('2.1.0beta2');
	
$bCompleted = true;

?>