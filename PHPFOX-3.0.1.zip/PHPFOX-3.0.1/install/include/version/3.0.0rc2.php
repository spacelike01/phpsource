<?php

$this->_upgradeDatabase('3.0.0rc2');

$bCompleted = true;

?>