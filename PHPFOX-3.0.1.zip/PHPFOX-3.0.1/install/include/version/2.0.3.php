<?php

$this->_upgradeDatabase('2.0.3');

$bCompleted = true;

?>