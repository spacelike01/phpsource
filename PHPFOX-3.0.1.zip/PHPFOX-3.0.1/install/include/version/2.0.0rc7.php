<?php

$this->_upgradeDatabase('2.0.0rc7');

$bCompleted = true;

?>