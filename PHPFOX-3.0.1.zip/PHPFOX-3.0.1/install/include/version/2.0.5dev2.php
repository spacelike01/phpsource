<?php

$this->_upgradeDatabase('2.0.5dev2');
	
$bCompleted = true;

?>