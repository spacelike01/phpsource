<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 * Abstract layer for CDN.
 * 
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author			Raymond Benc
 * @package 		Phpfox
 * @version 		$Id: abstract.class.php 1666 2010-07-07 08:17:00Z Raymond_Benc $
 * @abstract 
 */
abstract class Phpfox_Cdn_Abstract
{

}

?>