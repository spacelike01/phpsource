<?php
/** $Id: installer.xml.php 2832 2011-08-15 17:36:44Z Raymond_Benc $ **/
defined('PHPFOX') or exit('NO DICE!');
?>
<language>
	<settings>
		<parent_id></parent_id>
		<title>English (US)</title>
		<user_select>1</user_select>
		<language_code>en</language_code>
		<charset>UTF-8</charset>
		<direction>ltr</direction>
		<flag_id>png</flag_id>
		<time_stamp>1184048203</time_stamp>
		<created>N/A (Core)</created>
		<site />
	</settings>
	<phrases>
		<phrase module_id="core" version_id="2.0.0alpha1" var_name="module_installer" added="1215331034">Core Installer</phrase>
		<phrase module_id="core" version_id="2.0.0alpha1" var_name="phpfox_installer" added="1215331083">Installer</phrase>
	</phrases>
</language>