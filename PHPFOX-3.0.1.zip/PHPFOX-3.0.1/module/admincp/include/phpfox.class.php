<?php
/**
 * [PHPFOX_HEADER]
 */

defined('PHPFOX') or exit('NO DICE!');

/**
 * 
 * 
 * @copyright		[PHPFOX_COPYRIGHT]
 * @author  		Raymond Benc
 * @package  		Module_Admincp
 * @version 		$Id: phpfox.class.php 977 2009-09-12 15:29:04Z Raymond_Benc $
 */
class Module_Admincp 
{	
	public static $aTables = array();
}

?>