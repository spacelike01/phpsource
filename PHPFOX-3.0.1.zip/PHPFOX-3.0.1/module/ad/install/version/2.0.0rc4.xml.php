<upgrade>
	<update_templates>
		<file type="controller">index.html.php</file>
		<file type="controller">sample.html.php</file>
		<file type="block">display.html.php</file>
		<file type="block">sample.html.php</file>
	</update_templates>
</upgrade>