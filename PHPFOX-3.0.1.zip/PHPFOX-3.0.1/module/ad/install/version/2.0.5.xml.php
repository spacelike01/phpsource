<upgrade>
	<update_templates>
		<file type="controller">manage.html.php</file>
	</update_templates>
</upgrade>