<upgrade>
	<sql><![CDATA[a:1:{s:9:"ADD_FIELD";a:1:{s:14:"phpfox_ad_plan";a:2:{s:7:"d_width";a:4:{i:0;s:7:"VCHAR:4";i:1;N;i:2;s:0:"";i:3;s:3:"YES";}s:8:"d_height";a:4:{i:0;s:7:"VCHAR:4";i:1;N;i:2;s:0:"";i:3;s:3:"YES";}}}}]]></sql>
</upgrade>