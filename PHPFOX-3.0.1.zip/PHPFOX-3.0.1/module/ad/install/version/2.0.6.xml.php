<upgrade>
	<phrases>
		<phrase>
			<module_id>ad</module_id>
			<version_id>2.0.6</version_id>
			<var_name>and</var_name>
			<added>1285598055</added>
			<value>and</value>
		</phrase>
	</phrases>
	<update_templates>
		<file type="controller">sponsor.html.php</file>
		<file type="controller">add.html.php</file>
		<file type="controller">manage-sponsor.html.php</file>
	</update_templates>
</upgrade>