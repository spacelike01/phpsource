<upgrade>
	<sql><![CDATA[a:1:{s:9:"ADD_FIELD";a:1:{s:9:"phpfox_ad";a:1:{s:10:"gmt_offset";a:4:{i:0;s:8:"VCHAR:15";i:1;N;i:2;s:0:"";i:3;s:3:"YES";}}}}]]></sql>
</upgrade>