<upgrade>
	<hooks>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_construct__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_updateactivity__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_updateactivity__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_update__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_update__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_delete__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_delete__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_add__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_add__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_get__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_get__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_getforblock__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_getforblock__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_getadredirect__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_getadredirect__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_getforedit__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_getforedit__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_getsizes__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_ad_getsizes__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>service</hook_type>
			<module>ad</module>
			<call_name>ad.service_callback_construct__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>component</hook_type>
			<module>ad</module>
			<call_name>ad.component_ajax_update__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>component</hook_type>
			<module>ad</module>
			<call_name>ad.component_ajax_update__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>controller</hook_type>
			<module>ad</module>
			<call_name>ad.component_controller_iframe_clean</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>controller</hook_type>
			<module>ad</module>
			<call_name>ad.component_controller_process__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>controller</hook_type>
			<module>ad</module>
			<call_name>ad.component_controller_admincp_add_process__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>controller</hook_type>
			<module>ad</module>
			<call_name>ad.component_controller_admincp_add_process__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>controller</hook_type>
			<module>ad</module>
			<call_name>ad.component_controller_admincp_process__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>controller</hook_type>
			<module>ad</module>
			<call_name>ad.component_controller_admincp_process__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>component</hook_type>
			<module>ad</module>
			<call_name>ad.component_block_display_process__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>component</hook_type>
			<module>ad</module>
			<call_name>ad.component_block_display_process__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>template</hook_type>
			<module>ad</module>
			<call_name>ad.template_block_display__start</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>template</hook_type>
			<module>ad</module>
			<call_name>ad.template_block_display__end</call_name>
			<added>1263387694</added>
			<version_id>2.0.2</version_id>
			<value />
		</hook>
	</hooks>
	<update_templates>
		<file type="block">display.html.php</file>
	</update_templates>
</upgrade>