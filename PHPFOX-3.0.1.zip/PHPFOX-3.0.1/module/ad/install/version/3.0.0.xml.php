<upgrade>
	<phrases>
		<phrase>
			<module_id>ad</module_id>
			<version_id>3.0.0</version_id>
			<var_name>manage_ads</var_name>
			<added>1323261463</added>
			<value>Manage Ads</value>
		</phrase>
		<phrase>
			<module_id>ad</module_id>
			<version_id>3.0.0</version_id>
			<var_name>manage_invoices</var_name>
			<added>1323261476</added>
			<value>Manage Invoices</value>
		</phrase>
		<phrase>
			<module_id>ad</module_id>
			<version_id>3.0.0</version_id>
			<var_name>manage_sponsorships</var_name>
			<added>1323261491</added>
			<value>Manage Sponsorships</value>
		</phrase>
		<phrase>
			<module_id>ad</module_id>
			<version_id>3.0.0</version_id>
			<var_name>choose_image</var_name>
			<added>1323261560</added>
			<value>Choose image</value>
		</phrase>
	</phrases>
</upgrade>