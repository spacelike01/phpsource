<upgrade>
	<hooks>
		<hook>
			<module_id>ad</module_id>
			<hook_type>component</hook_type>
			<module>ad</module>
			<call_name>ad.component_block_inner_process__start</call_name>
			<added>1319729453</added>
			<version_id>3.0.0rc1</version_id>
			<value />
		</hook>
		<hook>
			<module_id>ad</module_id>
			<hook_type>component</hook_type>
			<module>ad</module>
			<call_name>ad.component_block_inner_process__end</call_name>
			<added>1319729453</added>
			<version_id>3.0.0rc1</version_id>
			<value />
		</hook>
	</hooks>
</upgrade>