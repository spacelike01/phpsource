<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class pageController extends appRain_Base_Core
{
    public $name = 'Page';

    /**
     * This function will reander the home page
     *
     * @return null
     */
    private function index()
    {
    }

    /**
     * Mange static page
     *
     * @parameter page_id integer
     * @return null
     */
    public function manageAction( $action = "update", $page_id = NULL )
    {
        // Check access
        $errors = Array();
        $this->setAdminTab('page_manager');
        $this->addons = array('validation','rich_text_editor','linedtextarea','dialogs');

        // Save page
        if( !empty( $this->data ))
        {
            if( $action == 'create' || $action == 'createsnip')$content = App::Load("Model/Page")->find("name='{$this->data['Page']['name']}' AND fkey=" . $this->getUserStatusId());
            else $content = App::Model("Page")->findById($page_id);

            if( isset($this->post['Button']['button_delete']))
            {
                App::Load("Model/Page")->DeleteById($page_id);
                App::Module('Notification')->Push("Deleted successfully.");
                $this->redirect("/page/manage");
                exit;
            }
            else
            {
                $this->data['Page']['fkey']= $this->getUserStatusId();
                if(isset($this->data['Page']['name']))
                {
                    $this->data['Page']['name'] = App::Helper('Utility')->text2NOrmalize($this->data['Page']['name']);
                }
                $result = App::Load("Model/Page")->Save($this->data);
                $errors = $result->getErrorInfo();

                if(empty($errors))
                {
                    App::Module('Notification')->Push("Updated successfully.");
                    $this->redirect("/page/manage/update/" . $result->getId());
                    exit;
                }
                else
                {
                    App::Module('Notification')->Push(implode("<br />",$errors),Array('level'=>'Error'));
                }

            }
        }

        if( $action == 'update' || $action == 'snip')
        {
            $page_arr = App::Pagemanager()->Pages("name_only");

            if(empty($page_arr))
            {
                $this->redirect("/page/manage/create");
                exit;
            }
            $this->set( 'static_page_arr', $page_arr);

            $page_id = isset(  $page_id )?  $page_id : key( $page_arr ) ;
            $this->set('page_id',$page_id);

            $page_current = App::PageManager()->Pages( $page_id );
            $this->set("page_current",$page_current );
        }

        $title = isset($page_current['title']) ? $page_current['title'] : 'Create Page';
        $this->set("action",$action );
        $this->page_title= "{$title}" . app::__def()->SysConfig('ADMIN_PAGE_TITLE_SAPARATOR') . "Page Manager";
        $this->set("page_id",$page_id);
    }

    /**
     * View page content by default it set to about us
     *
     * @parameter page_name string
     * @return null
     */
    public function viewAction( $page_name = 'about_us' )
    {
        $page_content = $this->staticPageNameToMetaInfo($page_name);

        if($page_content['contenttype']== 'Snip')
        {
            $this->redirect("/");
            exit;
        }

        $this->set("selected",$page_name);
        $this->set("section_title",$page_content['title']);
        $this->set( 'page_content' ,$page_content );
    }
}