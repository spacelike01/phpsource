-- query
DROP TABLE IF EXISTS app_administrators;
-- query
CREATE TABLE `app_administrators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey` int(11) NOT NULL,
  `f_name` varchar(50) NOT NULL,
  `l_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `createdate` datetime NOT NULL,
  `latestlogin` int(11) NOT NULL,
  `lastlogin` int(11) NOT NULL,
  `status` enum('Active','Pending') NOT NULL DEFAULT 'Active',
  `type` enum('Super','Normal') NOT NULL DEFAULT 'Normal',
  `acl` text NOT NULL,
  `description` text NOT NULL,
  `resetsid` varchar(200) CHARACTER SET ucs2 NOT NULL,
  `lastresettime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
-- query
INSERT INTO app_administrators VALUES ('1', '0', 'Website', 'Administrator', 'admin', 'e10adc3949ba59abbe56e057f20f883e', 'info@site.com', '2011-04-08 19:51:52', '1302285132', '0', 'Active', 'Super', '', '', '', '1302285112');
-- query
DROP TABLE IF EXISTS app_categories;
-- query
CREATE TABLE `app_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey` int(11) NOT NULL DEFAULT '0',
  `adminref` int(11) NOT NULL DEFAULT '0',
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `image` varchar(200) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `generic` varchar(250) NOT NULL,
  `entry_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
-- query
INSERT INTO app_categories VALUES ('8', '0', '1', '0', '', 'Uncategorized', '<p>
	Sample Category</p>
', 'blog-cat', '13', '2011-04-08 02:22:10', '2011-04-08 02:22:10');
-- query
INSERT INTO app_categories VALUES ('12', '0', '1', '0', '', 'Lorem ipsum dolor sit amet, consectetur', '<p>
	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus augue odio, pharetra non congue a, pellentesque pellentesque erat. Etiam sed consectetur turpis. In neque nisl, ullamcorper sit amet ornare pretium, cursus quis eros.</p>
', 'forum-cat', '10', '2010-09-02 09:17:55', '2010-09-02 09:17:55');
-- query
INSERT INTO app_categories VALUES ('13', '0', '1', '0', '', 'Raesent vitae ipsum sapien, nec sollicitudin lectus', '<p>
	Raesent vitae ipsum sapien, nec sollicitudin lectus. Aliquam eros neque, gravida et dictum euismod, molestie ut enim. Aenean at leo in arcu sodales suscipit. Nullam lacinia felis id odio consequat mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus molestie sagittis ultrices.</p>
', 'forum-cat', '11', '2010-09-02 09:18:47', '2010-09-02 09:18:47');
-- query
INSERT INTO app_categories VALUES ('14', '0', '1', '0', '', 'Fusce molestie justo nec mi venenatis placerat', '<p>
	Nullam ullamcorper tristique vestibulum. Aliquam erat volutpat. Vivamus nec vestibulum leo. Aliquam interdum pharetra erat eu hendrerit. Etiam velit est, placerat vel aliquet et, commodo eget nulla. Fusce molestie justo nec mi venenatis placerat.</p>
', 'forum-cat', '13', '2011-03-21 11:14:59', '2011-03-21 11:14:59');
-- query
INSERT INTO app_categories VALUES ('15', '0', '1', '0', '', 'Vivamus molestie sagittis ultrices.', '<p>
	Praesent vitae ipsum sapien, nec sollicitudin lectus. Aliquam eros neque, gravida et dictum euismod, molestie ut enim. Aenean at leo in arcu sodales suscipit. Nullam lacinia felis id odio consequat mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus molestie sagittis ultrices.</p>
', 'forum-cat', '14', '2010-09-02 09:20:17', '2010-09-02 09:20:17');
-- query
INSERT INTO app_categories VALUES ('16', '0', '1', '0', '', 'Mauris dignissim placerat orci', '<p>
	Etiam sagittis, felis pellentesque dignissim dictum, neque massa euismod velit, nec tincidunt augue eros vitae lorem. Morbi imperdiet placerat leo, quis hendrerit sapien mattis eget. Suspendisse velit odio, lacinia sit amet condimentum vel, aliquam in diam. Mauris dignissim placerat orci. Fusce eu massa vitae augue tristique cursus ut a eros.</p>
', 'forum-cat', '15', '2010-09-02 09:21:18', '2010-09-02 09:21:18');
-- query
INSERT INTO app_categories VALUES ('17', '0', '1', '0', '', 'Lorem ipsum dolor', '<p>
	Pellentesque pharetra nibh id quam pharetra vel convallis dui faucibus. Aliquam nec nibh at turpis volutpat pulvinar id quis ligula. In bibendum auctor imperdiet. Donec dignissim aliquet scelerisque. Duis condimentum molestie justo viverra porttitor. Vestibulum nisi risus, eleifend quis porta id, vulputate eu metus</p>
', 'product-cat', '10', '2010-09-15 09:50:21', '2010-09-15 09:50:21');
-- query
INSERT INTO app_categories VALUES ('18', '0', '1', '0', '', 'Raesent vitae ipsum', '<p>
	Pellentesque pharetra nibh id quam pharetra vel convallis dui faucibus. Aliquam nec nibh at turpis volutpat pulvinar id quis ligula. In bibendum auctor imperdiet. Donec dignissim aliquet scelerisque. Duis condimentum molestie justo viverra porttitor. Vestibulum nisi risus, eleifend quis porta id, vulputate eu metus</p>
', 'product-cat', '11', '2010-09-15 09:50:41', '2010-09-15 09:50:41');
-- query
INSERT INTO app_categories VALUES ('19', '0', '1', '0', '', 'In euismod, lacus ut ultrices ', '<p>
	Pellentesque pharetra nibh id quam pharetra vel convallis dui faucibus. Aliquam nec nibh at turpis volutpat pulvinar id quis ligula. In bibendum auctor imperdiet. Donec dignissim aliquet scelerisque. Duis condimentum molestie justo viverra porttitor. Vestibulum nisi risus, eleifend quis porta id, vulputate eu metus</p>
', 'product-cat', '12', '2010-09-15 09:50:05', '2010-09-15 09:50:05');
-- query
INSERT INTO app_categories VALUES ('20', '0', '1', '0', '', 'Euismod cus utltrices ', '<p>
	Pellentesque pharetra nibh id quam pharetra vel convallis dui faucibus. Aliquam nec nibh at turpis volutpat pulvinar id quis ligula. In bibendum auctor imperdiet. Donec dignissim aliquet scelerisque. Duis condimentum molestie justo viverra porttitor. Vestibulum nisi risus, eleifend quis porta id, vulputate eu metus</p>
', 'product-cat', '13', '2010-09-15 09:49:27', '2010-09-15 09:49:27');
-- query
INSERT INTO app_categories VALUES ('21', '0', '1', '0', '', 'Duis placerat libero eget', '<p>
	Suspendisse eleifend commodo magna cursus sodales. Vivamus molestie felis non nisl auctor iaculis. Morbi porttitor, ipsum nec tincidunt tempus, lacus justo placerat enim, dignissim hendrerit justo magna non tortor. Quisque placerat nisi vitae quam auctor fermentum at non elit. Sed cursus luctus turpis, vulputate hendrerit enim pharetra placerat.</p>
', 'product-cat', '14', '2010-09-15 09:49:20', '2010-09-15 09:49:20');
-- query
INSERT INTO app_categories VALUES ('22', '0', '1', '0', '', 'Proin iaculis congue mattis', '<p>
	Pellentesque pharetra nibh id quam pharetra vel convallis dui faucibus. Aliquam nec nibh at turpis volutpat pulvinar id quis ligula. In bibendum auctor imperdiet. Donec dignissim aliquet scelerisque. Duis condimentum molestie justo viverra porttitor. Vestibulum nisi risus, eleifend quis porta id, vulputate eu metus</p>
', 'product-cat', '15', '2010-09-15 09:50:34', '2010-09-15 09:50:34');
-- query
INSERT INTO app_categories VALUES ('23', '0', '1', '0', '', 'Fermentum at dui', '<p>
	Pellentesque pharetra nibh id quam pharetra vel convallis dui faucibus. Aliquam nec nibh at turpis volutpat pulvinar id quis ligula. In bibendum auctor imperdiet. Donec dignissim aliquet scelerisque. Duis condimentum molestie justo viverra porttitor. Vestibulum nisi risus, eleifend quis porta id, vulputate eu metus</p>
', 'product-cat', '16', '2010-09-15 09:49:58', '2010-09-15 09:49:58');
-- query
INSERT INTO app_categories VALUES ('24', '0', '1', '20', '', 'Nullam lectus urna', '<p>
	Pellentesque pharetra nibh id quam pharetra vel convallis dui faucibus. Aliquam nec nibh at turpis volutpat pulvinar id quis ligula. In bibendum auctor imperdiet. Donec dignissim aliquet scelerisque. Duis condimentum molestie justo viverra porttitor. Vestibulum nisi risus, eleifend quis porta id, vulputate eu metus</p>
', 'product-cat', '10', '2010-09-15 09:49:33', '2010-09-15 09:49:33');
-- query
INSERT INTO app_categories VALUES ('25', '0', '1', '20', '', 'Nunc fringilla lobortis torto', '<p>
	Pellentesque pharetra nibh id quam pharetra vel convallis dui faucibus. Aliquam nec nibh at turpis volutpat pulvinar id quis ligula. In bibendum auctor imperdiet. Donec dignissim aliquet scelerisque. Duis condimentum molestie justo viverra porttitor. Vestibulum nisi risus, eleifend quis porta id, vulputate eu metus</p>
', 'product-cat', '11', '2010-09-15 09:49:48', '2010-09-15 09:49:48');
-- query
INSERT INTO app_categories VALUES ('26', '0', '1', '24', '', 'Nullam consequat', '<p>
	Pellentesque pharetra nibh id quam pharetra vel convallis dui faucibus. Aliquam nec nibh at turpis volutpat pulvinar id quis ligula. In bibendum auctor imperdiet. Donec dignissim aliquet scelerisque. Duis condimentum molestie justo viverra porttitor. Vestibulum nisi risus, eleifend quis porta id, vulputate eu metus</p>
', 'product-cat', '10', '2010-09-15 09:49:41', '2010-09-15 09:49:41');
-- query
INSERT INTO app_categories VALUES ('27', '0', '1', '19', '', 'Ligula a convallis', '<p>
	Pellentesque pharetra nibh id quam pharetra vel convallis dui faucibus. Aliquam nec nibh at turpis volutpat pulvinar id quis ligula. In bibendum auctor imperdiet. Donec dignissim aliquet scelerisque. Duis condimentum molestie justo viverra porttitor. Vestibulum nisi risus, eleifend quis porta id, vulputate eu metus</p>
', 'product-cat', '10', '2010-09-15 09:50:13', '2010-09-15 09:50:13');
-- query
INSERT INTO app_categories VALUES ('28', '0', '1', '0', '4.jpeg', 'Lorem ipsum dolor sit', '<p>
	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor. Duis scelerisque viverra rutrum. Cras et bibendum libero. Vivamus ante diam, volutpat et gravida posuere, adipiscing tristique sapien. Donec eget tortor vitae erat pharetra dapibus et eu lectus. Nullam interdum mollis nisl at commodo. Duis vestibulum nunc in risus placerat ac rhoncus mi fringilla.</p>
', 'gallery-cat', '10', '2010-09-09 14:07:07', '2010-09-09 14:07:07');
-- query
INSERT INTO app_categories VALUES ('29', '0', '1', '0', '3.jpeg', 'Duis placerat libero eget est', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique a. Nullam lectus urna, dapibus vitae venenatis nec, vestibulum sed lacus. Etiam odio odio, semper sit amet tincidunt eu, vehicula a turpis. Suspendisse potenti.</p>
', 'gallery-cat', '11', '2010-09-09 14:06:31', '2010-09-09 14:06:31');
-- query
INSERT INTO app_categories VALUES ('30', '0', '1', '0', '2.jpeg', 'Rullam onsequat, ortor itae', '<p>
	Nullam consequat, tortor vitae pellentesque lobortis, tortor odio iaculis nisl, ut malesuada dui nisi a tellus. Cras id odio non tortor pellentesque dictum sit amet in nulla. Mauris tortor odio iaculis nisl, ut malesuada dui nisi eget mauris sit amet libero rutrum mollis.</p>
', 'gallery-cat', '14', '2010-09-09 14:13:28', '2010-09-09 14:13:28');
-- query
INSERT INTO app_categories VALUES ('31', '0', '1', '0', '5.jpeg', 'Nullam eget lacus massa', '<p>
	Nullam ut vestibulum urna. Proin malesuada, mauris id faucibus faucibus, velit magna luctus purus, sed hendrerit metus massa id purus. Vestibulum eget risus non nulla volutpat convallis. Nulla et nisi vitae leo mollis condimentum. Aenean malesuada ultrices tempor. Etiam id ultrices metus. Nullam eget lacus massa, in tincidunt purus. Nulla non purus ut tellus tincidunt molestie id nec libero. Nulla sit amet rutrum sapien. Sed non ligula quam,</p>
', 'gallery-cat', '13', '2010-09-09 14:08:31', '2010-09-09 14:08:31');
-- query
INSERT INTO app_categories VALUES ('32', '0', '1', '0', '1.jpeg', 'Duis placerat libero eget', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique a.</p>
', 'gallery-cat', '12', '2010-09-09 14:04:27', '2010-09-09 14:04:27');
-- query
INSERT INTO app_categories VALUES ('33', '0', '1', '0', '7.jpeg', 'Proin iaculis congue mattis', '<p>
	Proin iaculis congue mattis. Ut lorem leo, scelerisque ac mollis vel, fermentum at dui. Quisque luctus, neque quis faucibus bibendum, quam est euismod diam, eget commodo mauris augue ac arcu.</p>
', 'gallery-cat', '15', '2010-09-09 14:08:45', '2010-09-09 14:08:45');
-- query
INSERT INTO app_categories VALUES ('34', '0', '1', '0', '8.jpeg', 'Nulla et nisi vitae leo mollis', '<p>
	Proin malesuada, mauris id faucibus faucibus, velit magna luctus purus, sed hendrerit metus massa id purus. Vestibulum eget risus non nulla volutpat convallis. Nulla et nisi vitae leo mollis condimentum. Aenean malesuada ultrices tempor. Etiam id ultrices metus. Nullam eget lacus massa, in tincidunt purus.</p>
', 'gallery-cat', '15', '2010-09-09 14:07:43', '2010-09-09 14:07:43');
-- query
INSERT INTO app_categories VALUES ('35', '0', '1', '0', '6.jpeg', 'Nullam consequat, tortor vitae', '<p>
	Nullam consequat, tortor vitae pellentesque lobortis, tortor odio iaculis nisl, ut malesuada dui nisi a tellus. Cras id odio non tortor pellentesque dictum sit amet in nulla. Mauris tortor odio iaculis nisl, ut malesuada dui nisi eget mauris sit amet libero rutrum mollis.</p>
', 'gallery-cat', '17', '2010-09-09 14:13:53', '2010-09-09 14:13:53');
-- query
INSERT INTO app_categories VALUES ('36', '0', '1', '0', 'm1.jpeg', 'Category 1', '', 'mobilegallerycat', '', '2011-01-23 08:37:03', '2011-01-23 08:37:03');
-- query
INSERT INTO app_categories VALUES ('37', '0', '1', '0', 'm2.jpeg', 'Category 2', '', 'mobilegallerycat', '', '2011-01-23 08:37:09', '2011-01-23 08:37:09');
-- query
INSERT INTO app_categories VALUES ('38', '0', '1', '0', 'm3.jpeg', 'Category 3', '', 'mobilegallerycat', '', '2011-01-23 08:37:16', '2011-01-23 08:37:16');
-- query
INSERT INTO app_categories VALUES ('39', '0', '1', '0', 'm4.jpeg', 'Category 4', '', 'mobilegallerycat', '', '2011-01-23 08:37:23', '2011-01-23 08:37:23');
-- query
DROP TABLE IF EXISTS app_comments;
-- query
CREATE TABLE `app_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `comment` text NOT NULL,
  `dated` datetime NOT NULL,
  `type` enum('Blog','Forum') NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
-- query
DROP TABLE IF EXISTS app_coreresources;
-- query
CREATE TABLE `app_coreresources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `type` enum('Model','Module','Plugin','Component') NOT NULL DEFAULT 'Model',
  `version` varchar(200) NOT NULL DEFAULT '',
  `status` enum('Active','Inactive') NOT NULL,
  `info` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
-- query
INSERT INTO app_coreresources VALUES ('20', 'Admin', 'Model', '0.1.0', 'Active', '');
-- query
INSERT INTO app_coreresources VALUES ('21', 'Category', 'Model', '0.1.0', 'Active', '');
-- query
INSERT INTO app_coreresources VALUES ('22', 'Config', 'Model', '0.1.0', 'Active', '');
-- query
INSERT INTO app_coreresources VALUES ('23', 'Coreresource', 'Model', '0.1.0', 'Active', '');
-- query
INSERT INTO app_coreresources VALUES ('24', 'Developer', 'Model', '0.1.0', 'Active', '');
-- query
INSERT INTO app_coreresources VALUES ('25', 'Home', 'Model', '0.1.0', 'Active', '');
-- query
INSERT INTO app_coreresources VALUES ('26', 'Infodata', 'Model', '0.1.0', 'Active', '');
-- query
INSERT INTO app_coreresources VALUES ('27', 'Information', 'Model', '0.1.0', 'Active', '');
-- query
INSERT INTO app_coreresources VALUES ('28', 'Log', 'Model', '0.1.0', 'Active', '');
-- query
INSERT INTO app_coreresources VALUES ('29', 'Member', 'Model', '0.1.0', 'Active', '');
-- query
INSERT INTO app_coreresources VALUES ('30', 'My', 'Model', '0.1.0', 'Active', '');
-- query
INSERT INTO app_coreresources VALUES ('31', 'Page', 'Model', '0.1.0', 'Active', '');
-- query
INSERT INTO app_coreresources VALUES ('32', 'appslide', 'Component', '0.1.0', 'Active', 'a:1:{s:11:"installdate";s:19:"2011-04-08 10:54:38";}');
-- query
INSERT INTO app_coreresources VALUES ('33', 'homepress', 'Component', '0.1.0', 'Active', 'a:1:{s:11:"installdate";s:19:"2011-04-08 10:54:49";}');
-- query
INSERT INTO app_coreresources VALUES ('34', 'aboutuspage', 'Component', '0.1.0', 'Active', 'a:1:{s:11:"installdate";s:19:"2011-04-08 10:56:02";}');
-- query
INSERT INTO app_coreresources VALUES ('35', 'contactus', 'Component', '0.1.0', 'Active', 'a:1:{s:11:"installdate";s:19:"2011-04-08 10:56:11";}');
-- query
DROP TABLE IF EXISTS app_infodata;
-- query
CREATE TABLE `app_infodata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '0',
  `ioption` varchar(250) NOT NULL,
  `ivalue` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=614 DEFAULT CHARSET=utf8;
-- query
INSERT INTO app_infodata VALUES ('31', '7', 'title', 'Lorem ipsum');
-- query
INSERT INTO app_infodata VALUES ('32', '7', 'image', 'customizable.jpg');
-- query
INSERT INTO app_infodata VALUES ('33', '7', 'description', '<h1>
	Lorem ipsum</h1>
<p>
	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor. Duis scelerisque viverra rutrum. Cras et bibendum libero. Vivamus ante diam, volutpat et gravida posuere, adipiscing tristique sapien. Donec eget tortor vitae erat pharetra dapibus et eu lectus. Nullam interdum mollis nisl at commodo.</p>
');
-- query
INSERT INTO app_infodata VALUES ('597', '118', 'title', 'Sun dolor sit ameipiscing');
-- query
INSERT INTO app_infodata VALUES ('598', '118', 'image', '1_12962281445930.jpg');
-- query
INSERT INTO app_infodata VALUES ('35', '8', 'title', 'Terms');
-- query
INSERT INTO app_infodata VALUES ('36', '8', 'description', '<p>
	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor. Duis scelerisque viverra rutrum. Cras et bibendum libero. Vivamus ante diam, volutpat et gravida posuere, adipiscing tristique sapien. Donec&nbsp; dapibus et eu lectus. Nullam interdum mollis nisl at commodo. Duis vestibulum nunc in risus placerat ac rhoncus mi fringilla eget tortor vitae erat pharetra rhoncus mi fringilla eget tortor vitae erat pharetra mi fringilla eget tortor vitae erat pharetra.</p>
');
-- query
INSERT INTO app_infodata VALUES ('34', '7', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('37', '8', 'linked-to', 'terms-and-conditions');
-- query
INSERT INTO app_infodata VALUES ('38', '8', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('43', '10', 'title', 'About Us');
-- query
INSERT INTO app_infodata VALUES ('44', '10', 'description', '<p>
	Proin iaculis congue mattis. Ut lorem leo, scelerisque ac mollis vel, fermentum at dui. Quisque luctus, neque quis faucibus bibendum, quam est euismod diam, eget commodo mauris augue ac arcu. Nunc fringilla lobortis tortor, volutpat fermentum enim placerat eget. Sed dolor nisl, lobortis vel accumsan vel, posuere a dui.<br />
	<br />
	Nullam consequat, tortor vitae pellentesque lobortis, tortor odio iaculis nisl, ut malesuada dui nisi a tellus. Cras id odio non tortor pellentesque dictum sit amet in nulla. Mauris tortor odio iaculis nisl.</p>
');
-- query
INSERT INTO app_infodata VALUES ('45', '10', 'linked-to', 'about-us');
-- query
INSERT INTO app_infodata VALUES ('46', '10', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('47', '11', 'title', 'Contact Us');
-- query
INSERT INTO app_infodata VALUES ('48', '11', 'description', '<p>
	Vivamus porta laoreet ligula a convallis. Vestibulum sagittis nunc metus, ut aliquam massa. <br />
	<br />
	Nullam ut vestibulum urna. Proin malesuada, mauris id faucibus faucibus, velit magna luctus purus, sed hendrerit metus massa id purus. Vestibulum eget risus non nulla volutpat convallis. Nulla et nisi vitae leo mollis condimentum. Aenean malesuada ultrices tempor. Etiam id ultrices metus. Nullam eget lacus massa, in tincidunt purus. Nulla non purus ut tellus tincidunt molestie id nec libero. Nulla sit amet rutrum sapien. Sed non ligula quam,</p>
');
-- query
INSERT INTO app_infodata VALUES ('49', '11', 'linked-to', 'contact-us');
-- query
INSERT INTO app_infodata VALUES ('50', '11', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('59', '14', 'title', 'Nunc sem velit');
-- query
INSERT INTO app_infodata VALUES ('60', '14', 'image', 'customizable_12832203074986.jpg');
-- query
INSERT INTO app_infodata VALUES ('61', '14', 'description', '<h1>
	Nunc sem velit facilisis</h1>
<p>
	Nunc sem velit, facilisis et mattis non, imperdiet sed nisi. Phasellus ut enim diam, a tincidunt tellus. <br />
	<br />
	Ut pharetra, ante at aliquet tempus, tortor odio rhoncus dui, in condimentum mauris nibh non metus. Maecenas ultricies, ipsum quis fermentum ultrices, quam erat porttitor ipsum, eu pulvinar leo ante faucibus augue. Maecenas libero turpis, pretium ac placerat vitae, viverra quis nibh.</p>
');
-- query
INSERT INTO app_infodata VALUES ('62', '14', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('63', '15', 'title', 'Proin iaculis');
-- query
INSERT INTO app_infodata VALUES ('64', '15', 'image', 'customizable_12832204605009.jpg');
-- query
INSERT INTO app_infodata VALUES ('65', '15', 'description', '<h1>
	Proin iaculis congue mattis</h1>
<p>
	Proin iaculis congue mattis. Ut lorem leo, scelerisque ac mollis vel, fermentum at dui. Quisque luctus, neque quis faucibus bibendum, quam est euismod diam, eget commodo mauris augue ac arcu. Nunc fringilla lobortis tortor, volutpat fermentum enim.<br />
	<br />
	Nullam consequat, tortor vitae pellentesque lobortis, tortor odio iaculis nisl, ut malesuada dui nisi a tellus.</p>
');
-- query
INSERT INTO app_infodata VALUES ('66', '15', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('67', '16', 'title', 'Cras id odio');
-- query
INSERT INTO app_infodata VALUES ('68', '16', 'image', 'customizable_12832205525088.jpg');
-- query
INSERT INTO app_infodata VALUES ('69', '16', 'description', '<h1>
	Cras id odio non tortor</h1>
<p>
	Nullam consequat, tortor vitae pellentesque lobortis, tortor odio iaculis nisl, ut malesuada dui nisi a tellus. Cras id odio non tortor pellentesque dictum sit amet in nulla. Mauris eget mauris sit amet libero rutrum mollis. Fusce facilisis ipsum vitae augue laoreet vitae gravida felis sodales. Duis non tincidunt risus. In blandit dapibus sollicitudin. Phasellus eget est ipsum, nec fringilla erat. Suspendisse laoreet justo dui, quis posuere leo. Integer ullamcorper eleifend urna, dictum semper quam consectetur eu.</p>
');
-- query
INSERT INTO app_infodata VALUES ('70', '16', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('71', '17', 'title', 'Cras mauris');
-- query
INSERT INTO app_infodata VALUES ('72', '17', 'image', 'customizable_12832206388530.jpg');
-- query
INSERT INTO app_infodata VALUES ('73', '17', 'description', '<h1>
	Cras mauris purus</h1>
<p>
	Maecenas at dolor lorem, ut venenatis turpis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam ut enim erat. Duis et felis velit. <br />
	<br />
	Nam non neque quam, eu ullamcorper elit. Duis quis tellus ut eros dapibus euismod a sed est. Maecenas tincidunt tincidunt erat, et scelerisque nibh feugiat id. Donec vel augue justo, ultricies ornare nunc. Nam orci justo, tempor sit amet egestas blandit.</p>
');
-- query
INSERT INTO app_infodata VALUES ('74', '17', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('79', '19', 'title', 'Quisque posuere, nulla vitae malesuada euismod');
-- query
INSERT INTO app_infodata VALUES ('80', '19', 'category', '8');
-- query
INSERT INTO app_infodata VALUES ('81', '19', 'description', '<p>
	Quisque posuere, nulla vitae malesuada euismod, nibh augue condimentum nulla, sed sodales nunc nulla fermentum velit. Donec ultricies felis sit amet nibh dapibus ornare. Ut vitae ligula quis neque mattis condimentum. Nam porttitor egestas dapibus. Integer sed augue purus, in blandit nunc. Integer volutpat semper faucibus. Morbi luctus mattis sapien vulputate suscipit. Aliquam sollicitudin tempor nisi, sed interdum tellus adipiscing sed. Vestibulum et congue est. Proin ligula risus, scelerisque pellentesque fermentum vel, cursus non neque. In vel sem dui, at egestas magna.<br />
	<br />
	Etiam adipiscing congue nisl, non tincidunt nulla dignissim vel. Phasellus malesuada nisi convallis odio adipiscing auctor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Integer sed dui nibh. Curabitur dui mauris, placerat id dignissim ac, mattis eu urna. Nullam cursus dolor in leo feugiat euismod. Donec molestie bibendum enim in suscipit. Duis interdum, risus ac dapibus semper, felis arcu tincidunt felis, a molestie ipsum eros eget quam. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam scelerisque pharetra magna, id tempor felis elementum eget. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc pretium iaculis molestie. Curabitur tempor urna non lacus pharetra in suscipit elit bibendum. Praesent felis nisl, accumsan et tristique in, lacinia id mi. Aliquam nec enim non mauris porta ultrices ut convallis enim. Vestibulum tincidunt, eros et porttitor porta, enim purus posuere elit, et sollicitudin ipsum ante vel odio.<br />
	<br />
	Mauris tempus, odio eu volutpat viverra, mi velit ornare leo, eget faucibus quam leo vel nisi. Morbi quis dui quam. Donec molestie interdum massa, ac luctus nisl faucibus vitae. Mauris elementum mattis nisl, eu dignissim justo auctor nec. Curabitur velit mauris, condimentum non venenatis eu, rhoncus ac diam. Cras luctus ornare eleifend. Nunc vitae libero lorem. Maecenas ante risus, ornare eu ultricies vel, faucibus ut nunc. Phasellus congue dignissim fringilla. Proin auctor, ipsum vel rutrum rutrum, quam nulla faucibus neque, a vestibulum mauris lectus et orci. Nam viverra arcu non nisl adipiscing dapibus. Praesent egestas pharetra dolor nec commodo. Maecenas porttitor nunc sed nulla fringilla tempor. Proin at ipsum vitae mauris rutrum sollicitudin. Fusce quis luctus neque. Suspendisse sit amet eros id justo mollis mollis. Nam porttitor tortor id turpis interdum pulvinar. Vestibulum faucibus metus et sapien tincidunt euismod. Donec ac orci id dui tincidunt mollis.</p>
');
-- query
INSERT INTO app_infodata VALUES ('82', '19', 'status', 'Public');
-- query
INSERT INTO app_infodata VALUES ('103', '25', 'title', 'Maecenas at dolor lorem, ut venenatis turpis');
-- query
INSERT INTO app_infodata VALUES ('104', '25', 'userid', '1');
-- query
INSERT INTO app_infodata VALUES ('105', '25', 'category', '14');
-- query
INSERT INTO app_infodata VALUES ('106', '25', 'description', '<p>
	Maecenas at dolor lorem, ut venenatis turpis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nullam ut enim erat. Duis et felis velit. Nam non neque quam, eu ullamcorper elit. Duis quis tellus ut eros dapibus euismod a sed est. Maecenas tincidunt tincidunt erat, et scelerisque nibh feugiat id.<br />
	<br />
	Donec vel augue justo, ultricies ornare nunc. Nam orci justo, tempor sit amet egestas blandit, posuere id lorem.</p>
');
-- query
INSERT INTO app_infodata VALUES ('107', '25', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('108', '26', 'title', 'Fusce ultricies molestie turpis');
-- query
INSERT INTO app_infodata VALUES ('109', '26', 'userid', '1');
-- query
INSERT INTO app_infodata VALUES ('110', '26', 'category', '12');
-- query
INSERT INTO app_infodata VALUES ('111', '26', 'description', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique a. Nullam lectus urna, dapibus vitae venenatis nec, vestibulum sed lacus. Etiam odio odio, semper sit amet tincidunt eu, vehicula a turpis. Suspendisse potenti.</p>
');
-- query
INSERT INTO app_infodata VALUES ('112', '26', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('113', '27', 'title', 'Proin iaculis congue mattis');
-- query
INSERT INTO app_infodata VALUES ('114', '27', 'userid', '1');
-- query
INSERT INTO app_infodata VALUES ('115', '27', 'category', '13');
-- query
INSERT INTO app_infodata VALUES ('116', '27', 'description', '<p>
	Proin iaculis congue mattis. Ut lorem leo, scelerisque ac mollis vel, fermentum at dui. Quisque luctus, neque quis faucibus bibendum, quam est euismod diam, eget commodo mauris augue ac arcu. Nunc fringilla lobortis tortor, volutpat fermentum enim placerat eget. Sed dolor nisl, lobortis vel accumsan vel, posuere a dui.</p>
');
-- query
INSERT INTO app_infodata VALUES ('117', '27', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('118', '28', 'title', 'Aenean malesuada ultrices tempor');
-- query
INSERT INTO app_infodata VALUES ('119', '28', 'userid', '1');
-- query
INSERT INTO app_infodata VALUES ('120', '28', 'category', '15');
-- query
INSERT INTO app_infodata VALUES ('121', '28', 'description', '<p>
	Nullam ut vestibulum urna. Proin malesuada, mauris id faucibus faucibus, velit magna luctus purus, sed hendrerit metus massa id purus. Vestibulum eget risus non nulla volutpat convallis. Nulla et nisi vitae leo mollis condimentum. Aenean malesuada ultrices tempor. Etiam id ultrices metus. Nullam eget lacus massa, in tincidunt purus.</p>
');
-- query
INSERT INTO app_infodata VALUES ('122', '28', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('123', '29', 'title', 'Molestie ut enim. Aenean at leo in ');
-- query
INSERT INTO app_infodata VALUES ('124', '29', 'userid', '1');
-- query
INSERT INTO app_infodata VALUES ('125', '29', 'category', '16');
-- query
INSERT INTO app_infodata VALUES ('126', '29', 'description', '<p>
	Praesent vitae ipsum sapien, nec sollicitudin lectus. Aliquam eros neque, gravida et dictum euismod, molestie ut enim. Aenean at leo in arcu sodales suscipit.</p>
');
-- query
INSERT INTO app_infodata VALUES ('127', '29', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('128', '30', 'title', ' Vivamus molestie sagittis ultrices.');
-- query
INSERT INTO app_infodata VALUES ('129', '30', 'userid', '1');
-- query
INSERT INTO app_infodata VALUES ('130', '30', 'category', '12');
-- query
INSERT INTO app_infodata VALUES ('131', '30', 'description', '<p>
	Raesent vitae ipsum sapien, nec sollicitudin lectus. Aliquam eros neque, gravida et dictum euismod, molestie ut enim. Aenean at leo in arcu sodales suscipit. Nullam lacinia felis id odio consequat mollis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus molestie sagittis ultrices.</p>
');
-- query
INSERT INTO app_infodata VALUES ('132', '30', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('133', '31', 'title', 'Duis placerat libero eget est scelerisque in egestas');
-- query
INSERT INTO app_infodata VALUES ('134', '31', 'userid', '1');
-- query
INSERT INTO app_infodata VALUES ('135', '31', 'category', '13');
-- query
INSERT INTO app_infodata VALUES ('136', '31', 'description', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique a. Nullam lectus urna, dapibus vitae venenatis nec, vestibulum sed lacus. Etiam odio odio, semper sit amet tincidunt eu, vehicula a turpis. Suspendisse potenti.</p>
');
-- query
INSERT INTO app_infodata VALUES ('137', '31', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('138', '32', 'title', 'Vivamus molestie felis ');
-- query
INSERT INTO app_infodata VALUES ('139', '32', 'category', '19,17,22,18');
-- query
INSERT INTO app_infodata VALUES ('140', '32', 'imagethumb', 'g_iphone.jpg');
-- query
INSERT INTO app_infodata VALUES ('141', '32', 'image', '');
-- query
INSERT INTO app_infodata VALUES ('142', '32', 'shortdesc', '<p>
	Suspendisse eleifend commodo magna cursus sodales. Vivamus molestie felis non nisl auctor iaculis.</p>
');
-- query
INSERT INTO app_infodata VALUES ('143', '32', 'desc', '<p>
	Suspendisse eleifend commodo magna cursus sodales. Vivamus molestie felis non nisl auctor iaculis. Morbi porttitor, ipsum nec tincidunt tempus, lacus justo placerat enim, dignissim hendrerit justo magna non tortor. Quisque placerat nisi vitae quam auctor fermentum at non elit. Sed cursus luctus turpis, vulputate hendrerit enim pharetra placerat. Pellentesque pharetra nibh id quam pharetra vel convallis dui faucibus. Aliquam nec nibh at turpis volutpat pulvinar id quis ligula. <br />
	<br />
	In bibendum auctor imperdiet. Donec dignissim aliquet scelerisque. Duis condimentum molestie justo viverra porttitor. Vestibulum nisi risus, eleifend quis porta id, vulputate eu metus.</p>
');
-- query
INSERT INTO app_infodata VALUES ('144', '32', 'price', '560');
-- query
INSERT INTO app_infodata VALUES ('145', '32', 'isfeatured', 'Yes');
-- query
INSERT INTO app_infodata VALUES ('146', '32', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('147', '33', 'title', 'Suspendisse eleifend commodo');
-- query
INSERT INTO app_infodata VALUES ('148', '33', 'category', '20,24,26,25');
-- query
INSERT INTO app_infodata VALUES ('149', '33', 'imagethumb', 'g_iphone.jpg');
-- query
INSERT INTO app_infodata VALUES ('150', '33', 'image', '');
-- query
INSERT INTO app_infodata VALUES ('151', '33', 'shortdesc', '<p>
	Suspendisse eleifend commodo magna cursus sodales. Vivamus molestie felis non nisl auctor iaculis.</p>
');
-- query
INSERT INTO app_infodata VALUES ('152', '33', 'desc', '<p>
	Suspendisse eleifend commodo magna cursus sodales. Vivamus molestie felis non nisl auctor iaculis. Morbi porttitor, ipsum nec tincidunt tempus, lacus justo placerat enim, dignissim hendrerit justo magna non tortor. Quisque placerat nisi vitae quam auctor fermentum at non elit. Sed cursus luctus turpis, vulputate hendrerit enim pharetra placerat. Pellentesque pharetra nibh id quam pharetra vel convallis dui faucibus. Aliquam nec nibh at turpis volutpat pulvinar id quis ligula. <br />
	<br />
	In bibendum auctor imperdiet. Donec dignissim aliquet scelerisque. Duis condimentum molestie justo viverra porttitor. Vestibulum nisi risus, eleifend quis porta id, vulputate eu metus.</p>
');
-- query
INSERT INTO app_infodata VALUES ('153', '33', 'price', '560');
-- query
INSERT INTO app_infodata VALUES ('154', '33', 'isfeatured', 'Yes');
-- query
INSERT INTO app_infodata VALUES ('155', '33', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('156', '34', 'title', 'Duis placerat libero eget est');
-- query
INSERT INTO app_infodata VALUES ('157', '34', 'category', '21,20,24,26,25,23,19,17,22,18');
-- query
INSERT INTO app_infodata VALUES ('158', '34', 'imagethumb', 'g_iphone.jpg');
-- query
INSERT INTO app_infodata VALUES ('159', '34', 'image', '');
-- query
INSERT INTO app_infodata VALUES ('160', '34', 'shortdesc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non.</p>
');
-- query
INSERT INTO app_infodata VALUES ('161', '34', 'desc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique a.</p>
');
-- query
INSERT INTO app_infodata VALUES ('162', '34', 'price', '560');
-- query
INSERT INTO app_infodata VALUES ('163', '34', 'isfeatured', 'Yes');
-- query
INSERT INTO app_infodata VALUES ('164', '34', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('165', '35', 'title', 'Praesent magna nis');
-- query
INSERT INTO app_infodata VALUES ('166', '35', 'category', '21,20,24,26,25,23,19,17,22,18');
-- query
INSERT INTO app_infodata VALUES ('167', '35', 'imagethumb', 'g_iphone.jpg');
-- query
INSERT INTO app_infodata VALUES ('168', '35', 'image', '');
-- query
INSERT INTO app_infodata VALUES ('169', '35', 'shortdesc', '<p>
	Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue, praesent magna nisl.</p>
');
-- query
INSERT INTO app_infodata VALUES ('170', '35', 'desc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique a.</p>
');
-- query
INSERT INTO app_infodata VALUES ('171', '35', 'price', '560');
-- query
INSERT INTO app_infodata VALUES ('172', '35', 'isfeatured', 'Yes');
-- query
INSERT INTO app_infodata VALUES ('173', '35', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('174', '36', 'title', 'Duis placerat libero eget');
-- query
INSERT INTO app_infodata VALUES ('175', '36', 'category', '21,20,24,26,25,23,19,17,22,18');
-- query
INSERT INTO app_infodata VALUES ('176', '36', 'imagethumb', 'g_iphone.jpg');
-- query
INSERT INTO app_infodata VALUES ('177', '36', 'image', '');
-- query
INSERT INTO app_infodata VALUES ('178', '36', 'shortdesc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nis</p>
');
-- query
INSERT INTO app_infodata VALUES ('179', '36', 'desc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique a.</p>
');
-- query
INSERT INTO app_infodata VALUES ('180', '36', 'price', '560');
-- query
INSERT INTO app_infodata VALUES ('181', '36', 'isfeatured', 'Yes');
-- query
INSERT INTO app_infodata VALUES ('182', '36', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('183', '37', 'title', 'Duis placerat libero eget');
-- query
INSERT INTO app_infodata VALUES ('184', '37', 'category', '21,20,24,26,25,23,19,17,22,18');
-- query
INSERT INTO app_infodata VALUES ('185', '37', 'imagethumb', 'g_iphone.jpg');
-- query
INSERT INTO app_infodata VALUES ('186', '37', 'image', '');
-- query
INSERT INTO app_infodata VALUES ('187', '37', 'shortdesc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing.</p>
');
-- query
INSERT INTO app_infodata VALUES ('188', '37', 'desc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique a.</p>
');
-- query
INSERT INTO app_infodata VALUES ('189', '37', 'price', '560');
-- query
INSERT INTO app_infodata VALUES ('190', '37', 'isfeatured', 'Yes');
-- query
INSERT INTO app_infodata VALUES ('191', '37', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('192', '38', 'title', 'Egestas nibh adipiscing');
-- query
INSERT INTO app_infodata VALUES ('193', '38', 'category', '21,20,24,26,25,23,19,17,22,18');
-- query
INSERT INTO app_infodata VALUES ('194', '38', 'imagethumb', 'g_iphone.jpg');
-- query
INSERT INTO app_infodata VALUES ('195', '38', 'image', '');
-- query
INSERT INTO app_infodata VALUES ('196', '38', 'shortdesc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl.</p>
');
-- query
INSERT INTO app_infodata VALUES ('197', '38', 'desc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique.</p>
');
-- query
INSERT INTO app_infodata VALUES ('198', '38', 'price', '560');
-- query
INSERT INTO app_infodata VALUES ('199', '38', 'isfeatured', 'Yes');
-- query
INSERT INTO app_infodata VALUES ('200', '38', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('201', '39', 'title', 'Non fringilla sed');
-- query
INSERT INTO app_infodata VALUES ('202', '39', 'category', '21,20,24,26,25,23,19,17,22,18');
-- query
INSERT INTO app_infodata VALUES ('203', '39', 'imagethumb', 'g_iphone.jpg');
-- query
INSERT INTO app_infodata VALUES ('204', '39', 'image', '');
-- query
INSERT INTO app_infodata VALUES ('205', '39', 'shortdesc', '<p>
	Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel.</p>
');
-- query
INSERT INTO app_infodata VALUES ('206', '39', 'desc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique.</p>
');
-- query
INSERT INTO app_infodata VALUES ('207', '39', 'price', '560');
-- query
INSERT INTO app_infodata VALUES ('208', '39', 'isfeatured', 'Yes');
-- query
INSERT INTO app_infodata VALUES ('209', '39', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('210', '40', 'title', 'Ullamcorper non fringilla sed');
-- query
INSERT INTO app_infodata VALUES ('211', '40', 'category', '21,20,24,26,25,23,19,17,22,18');
-- query
INSERT INTO app_infodata VALUES ('212', '40', 'imagethumb', 'g_iphone.jpg');
-- query
INSERT INTO app_infodata VALUES ('213', '40', 'image', '');
-- query
INSERT INTO app_infodata VALUES ('214', '40', 'shortdesc', '<p>
	Ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat.</p>
');
-- query
INSERT INTO app_infodata VALUES ('215', '40', 'desc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique.</p>
');
-- query
INSERT INTO app_infodata VALUES ('216', '40', 'price', '560');
-- query
INSERT INTO app_infodata VALUES ('217', '40', 'isfeatured', 'Yes');
-- query
INSERT INTO app_infodata VALUES ('218', '40', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('219', '41', 'title', 'Oo ullamcorper non fringilla');
-- query
INSERT INTO app_infodata VALUES ('220', '41', 'category', '21,20,24,26,25,23,19,17,22,18');
-- query
INSERT INTO app_infodata VALUES ('221', '41', 'imagethumb', 'g_iphone.jpg');
-- query
INSERT INTO app_infodata VALUES ('222', '41', 'image', '');
-- query
INSERT INTO app_infodata VALUES ('223', '41', 'shortdesc', '<p>
	Oo ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulu.</p>
');
-- query
INSERT INTO app_infodata VALUES ('224', '41', 'desc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique.</p>
');
-- query
INSERT INTO app_infodata VALUES ('225', '41', 'price', '560');
-- query
INSERT INTO app_infodata VALUES ('226', '41', 'isfeatured', 'Yes');
-- query
INSERT INTO app_infodata VALUES ('227', '41', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('228', '42', 'title', 'Raesent magna nisl');
-- query
INSERT INTO app_infodata VALUES ('229', '42', 'category', '21,20,24,26,25,23,19,17,22,18');
-- query
INSERT INTO app_infodata VALUES ('230', '42', 'imagethumb', 'g_iphone.jpg');
-- query
INSERT INTO app_infodata VALUES ('231', '42', 'image', '');
-- query
INSERT INTO app_infodata VALUES ('232', '42', 'shortdesc', '<p>
	Raesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue.</p>
');
-- query
INSERT INTO app_infodata VALUES ('233', '42', 'desc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique.</p>
');
-- query
INSERT INTO app_infodata VALUES ('234', '42', 'price', '560');
-- query
INSERT INTO app_infodata VALUES ('235', '42', 'isfeatured', 'Yes');
-- query
INSERT INTO app_infodata VALUES ('236', '42', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('237', '43', 'title', 'Lacerat libero eget est');
-- query
INSERT INTO app_infodata VALUES ('238', '43', 'category', '21,20,24,26,25,23,19,27,17,22,18');
-- query
INSERT INTO app_infodata VALUES ('239', '43', 'imagethumb', 'g_iphone.jpg');
-- query
INSERT INTO app_infodata VALUES ('240', '43', 'image', '');
-- query
INSERT INTO app_infodata VALUES ('241', '43', 'shortdesc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing</p>
');
-- query
INSERT INTO app_infodata VALUES ('242', '43', 'desc', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique.</p>
');
-- query
INSERT INTO app_infodata VALUES ('243', '43', 'price', '560');
-- query
INSERT INTO app_infodata VALUES ('244', '43', 'isfeatured', 'Yes');
-- query
INSERT INTO app_infodata VALUES ('245', '43', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('246', '44', 'title', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('247', '44', 'category', '32,29,28,34,30,35,31,33');
-- query
INSERT INTO app_infodata VALUES ('248', '44', 'imagethumb', '1_12837826366405.jpg');
-- query
INSERT INTO app_infodata VALUES ('249', '44', 'image', '1_12837826366345.jpg');
-- query
INSERT INTO app_infodata VALUES ('250', '44', 'desc', 'Vivamus porta laoreet ligula a convallisVivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('251', '44', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('252', '45', 'title', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('253', '45', 'category', '32,29,28,34,30,35,31,33');
-- query
INSERT INTO app_infodata VALUES ('254', '45', 'imagethumb', '2.jpg');
-- query
INSERT INTO app_infodata VALUES ('255', '45', 'image', '2_12837826546848.jpg');
-- query
INSERT INTO app_infodata VALUES ('256', '45', 'desc', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('257', '45', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('258', '46', 'title', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('259', '46', 'category', '32,29,28,34,30,35,31,33');
-- query
INSERT INTO app_infodata VALUES ('260', '46', 'imagethumb', '3_12837826724903.jpg');
-- query
INSERT INTO app_infodata VALUES ('261', '46', 'image', '3_12837826728520.jpg');
-- query
INSERT INTO app_infodata VALUES ('262', '46', 'desc', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('263', '46', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('264', '47', 'title', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('265', '47', 'category', '32,29,28,34,30,35,31,33');
-- query
INSERT INTO app_infodata VALUES ('266', '47', 'imagethumb', '4_12837826904452.jpg');
-- query
INSERT INTO app_infodata VALUES ('267', '47', 'image', '4_12837826915956.jpg');
-- query
INSERT INTO app_infodata VALUES ('268', '47', 'desc', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('269', '47', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('270', '48', 'title', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('271', '48', 'category', '32,29,28,34,30,35,31,33');
-- query
INSERT INTO app_infodata VALUES ('272', '48', 'imagethumb', '5.jpg');
-- query
INSERT INTO app_infodata VALUES ('273', '48', 'image', '5_12837827104706.jpg');
-- query
INSERT INTO app_infodata VALUES ('274', '48', 'desc', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('275', '48', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('276', '49', 'title', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('277', '49', 'category', '32,29,28,34,30,35,31,33');
-- query
INSERT INTO app_infodata VALUES ('278', '49', 'imagethumb', '6.jpg');
-- query
INSERT INTO app_infodata VALUES ('279', '49', 'image', '6_12837827287769.jpg');
-- query
INSERT INTO app_infodata VALUES ('280', '49', 'desc', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('281', '49', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('282', '50', 'title', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('283', '50', 'category', '32,29,28,34,30,35,31,33');
-- query
INSERT INTO app_infodata VALUES ('284', '50', 'imagethumb', '7.jpg');
-- query
INSERT INTO app_infodata VALUES ('285', '50', 'image', '7_12837827483150.jpg');
-- query
INSERT INTO app_infodata VALUES ('286', '50', 'desc', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('287', '50', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('288', '51', 'title', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('289', '51', 'category', '32,29,28,34,30,35,31,33');
-- query
INSERT INTO app_infodata VALUES ('290', '51', 'imagethumb', '8.jpg');
-- query
INSERT INTO app_infodata VALUES ('291', '51', 'image', '8_12837827719673.jpg');
-- query
INSERT INTO app_infodata VALUES ('292', '51', 'desc', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('293', '51', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('294', '52', 'title', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('295', '52', 'category', '32,29,28,34,30,35,31,33');
-- query
INSERT INTO app_infodata VALUES ('296', '52', 'imagethumb', '9.jpg');
-- query
INSERT INTO app_infodata VALUES ('297', '52', 'image', '9_12837827936666.jpg');
-- query
INSERT INTO app_infodata VALUES ('298', '52', 'desc', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('299', '52', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('300', '53', 'title', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('301', '53', 'category', '32,29,28,34,30,35,31,33');
-- query
INSERT INTO app_infodata VALUES ('302', '53', 'imagethumb', '10.jpg');
-- query
INSERT INTO app_infodata VALUES ('303', '53', 'image', '10_12837828137913.jpg');
-- query
INSERT INTO app_infodata VALUES ('304', '53', 'desc', 'Vivamus porta laoreet ligula a convallis');
-- query
INSERT INTO app_infodata VALUES ('305', '53', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('306', '54', 'title', 'Lorem ipsum dolor sit amet, consectetur');
-- query
INSERT INTO app_infodata VALUES ('307', '54', 'category', '29');
-- query
INSERT INTO app_infodata VALUES ('308', '54', 'imagethumb', '1t_12837985987519.jpg');
-- query
INSERT INTO app_infodata VALUES ('309', '54', 'image', '1_12837985987416.jpg');
-- query
INSERT INTO app_infodata VALUES ('310', '54', 'desc', 'Lorem ipsum dolor sit amet, consectetur');
-- query
INSERT INTO app_infodata VALUES ('311', '54', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('312', '55', 'title', 'Fusce ultricies molestie turpis');
-- query
INSERT INTO app_infodata VALUES ('313', '55', 'category', '29');
-- query
INSERT INTO app_infodata VALUES ('314', '55', 'imagethumb', '2t_12837985812747.jpg');
-- query
INSERT INTO app_infodata VALUES ('315', '55', 'image', '2_12837985816048.jpg');
-- query
INSERT INTO app_infodata VALUES ('316', '55', 'desc', '/var/www/works/other/gallery/3DWallPhotoGallery/images');
-- query
INSERT INTO app_infodata VALUES ('317', '55', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('326', '58', 'message', 'Following message sen by {FirstName}{LastName}

{Message}

<hr />
Subject:  {Subject}
Sender Email:  {Email}


<a href="{baseurl}">View Website</a>
<a href="{baseurl}/admin">View Admin</a>');
-- query
INSERT INTO app_infodata VALUES ('324', '58', 'templatetype', 'ContactUs');
-- query
INSERT INTO app_infodata VALUES ('325', '58', 'subject', 'One message sent  by {FirstName}{LastName}');
-- query
INSERT INTO app_infodata VALUES ('327', '59', 'templatetype', 'BlogComment');
-- query
INSERT INTO app_infodata VALUES ('328', '59', 'subject', 'One Comment posted by {Name}');
-- query
INSERT INTO app_infodata VALUES ('329', '59', 'message', 'Following comment sent by : {Name}

{Comment}

<hr />
Sender Email: {EmailAddress}


<a href="{baseurl}">View Website</a>
<a href="{baseurl}/admin">View Admin</a>
');
-- query
INSERT INTO app_infodata VALUES ('330', '60', 'templatetype', 'ForumComment');
-- query
INSERT INTO app_infodata VALUES ('331', '60', 'subject', 'Comment Posted in Furm by {Name}');
-- query
INSERT INTO app_infodata VALUES ('332', '60', 'message', 'Following comment sent by : {Name}
{Comment}

<hr />
Email: {EmailAddress}
Website: {Website}

<a href="{baseurl}/appforum/managecomment">Click here</a> to Moderate The comments');
-- query
INSERT INTO app_infodata VALUES ('333', '61', 'templatetype', 'ForumPost');
-- query
INSERT INTO app_infodata VALUES ('334', '61', 'subject', 'New Thred posted in Forum by {Name}');
-- query
INSERT INTO app_infodata VALUES ('335', '61', 'message', 'A new thread "{Title}" posted by : {Name}

<hr />
Emial: {EmailAddress}
Website {Website}

<a href="{baseurl}/information/manage/forum-post">Click here </a> to moderate the post.');
-- query
INSERT INTO app_infodata VALUES ('356', '66', 'templatetype', 'StorePaymentSuccessCustomer');
-- query
INSERT INTO app_infodata VALUES ('357', '66', 'subject', 'Order Processed successfully');
-- query
INSERT INTO app_infodata VALUES ('358', '66', 'message', 'Dear {FirstName}{LastName},
Following order completed successfully.
{Invoice}

We will contact you soon.');
-- query
INSERT INTO app_infodata VALUES ('359', '67', 'templatetype', 'StorePaymentSuccessAdmin');
-- query
INSERT INTO app_infodata VALUES ('360', '67', 'subject', 'One Order Completed by {FirstName} {LastName}');
-- query
INSERT INTO app_infodata VALUES ('361', '67', 'message', 'Following order successfully completed by  {FirstName} {LastName},
{Invoice}

Customer Contact :-
Email address : {Email}
Phone Number: {Phone}');
-- query
INSERT INTO app_infodata VALUES ('362', '68', 'templatetype', 'StorePaymentFailedCustomer');
-- query
INSERT INTO app_infodata VALUES ('363', '68', 'subject', 'Payment Failed');
-- query
INSERT INTO app_infodata VALUES ('364', '68', 'message', 'Dear {FirstName}{LastName},
Unfortunately your payment did no go through. 
{Invoice}

We will contact you soon.');
-- query
INSERT INTO app_infodata VALUES ('365', '69', 'templatetype', 'StorePaymentFailedAdmin');
-- query
INSERT INTO app_infodata VALUES ('366', '69', 'subject', 'Payment Failed by {FirstName}{LastName},');
-- query
INSERT INTO app_infodata VALUES ('367', '69', 'message', 'Payment failed for order
{Invoice}

Customer Contact :-
Email address : {Email}
Phone Number: {Phone}');
-- query
INSERT INTO app_infodata VALUES ('368', '70', 'title', 'Lorem ipsum dolor sit ame');
-- query
INSERT INTO app_infodata VALUES ('369', '70', 'userid', '0');
-- query
INSERT INTO app_infodata VALUES ('370', '70', 'category', '16');
-- query
INSERT INTO app_infodata VALUES ('371', '70', 'description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor. Duis scelerisque viverra rutrum. Cras et bibendum libero.

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor. Duis scelerisque viverra rutrum. Cras et bibendum libero.

Laoreet sit amet dolor. Duis scelerisque viverra rutrum. Cras et bibendum libero');
-- query
INSERT INTO app_infodata VALUES ('372', '70', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('403', '77', 'title', ' Vivamus molestie sagittis ultrices.');
-- query
INSERT INTO app_infodata VALUES ('404', '77', 'userid', '1');
-- query
INSERT INTO app_infodata VALUES ('405', '77', 'category', '14');
-- query
INSERT INTO app_infodata VALUES ('406', '77', 'description', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor. 

Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor.

Duis scelerisque viverra rutrum. Cras et bibendum libero.');
-- query
INSERT INTO app_infodata VALUES ('407', '77', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('408', '78', 'title', 'Lorem ipsum dolor sit amet,');
-- query
INSERT INTO app_infodata VALUES ('409', '78', 'userid', '1');
-- query
INSERT INTO app_infodata VALUES ('410', '78', 'category', '16');
-- query
INSERT INTO app_infodata VALUES ('411', '78', 'description', '<p>
	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus augue odio, pharetra non congue a, pellentesque pellentesque erat. Etiam sed consectetur turpis. In neque nisl, ullamcorper sit amet ornare pretium, cursus quis eros.</p>
');
-- query
INSERT INTO app_infodata VALUES ('412', '78', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('413', '79', 'templatetype', 'MemberRegistration');
-- query
INSERT INTO app_infodata VALUES ('414', '79', 'subject', 'Member Registration notification');
-- query
INSERT INTO app_infodata VALUES ('415', '79', 'message', 'Dear {FirstName} {LastName},
Registration is almost click the following link to complete the registration

{VerificationLink}

<hr />
<a href="{baseurl}/contact-us">Click here</a> to contact with administrator

');
-- query
INSERT INTO app_infodata VALUES ('416', '80', 'templatetype', 'ForgotPassword');
-- query
INSERT INTO app_infodata VALUES ('417', '80', 'subject', 'Password Reset request');
-- query
INSERT INTO app_infodata VALUES ('418', '80', 'message', 'Dear {FirstName} {LastName},
Click the following link to reset password

{PasswordResetLink}

<hr />
<a href="{baseurl}/contact-us">Click here</a> to contact with administrator');
-- query
INSERT INTO app_infodata VALUES ('434', '84', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('433', '84', 'url', '');
-- query
INSERT INTO app_infodata VALUES ('432', '84', 'image', '1.jpg');
-- query
INSERT INTO app_infodata VALUES ('431', '84', 'title', 'Suspendisse eleifend commodo magna cursus sodales');
-- query
INSERT INTO app_infodata VALUES ('436', '85', 'image', '2_12954285817249.jpg');
-- query
INSERT INTO app_infodata VALUES ('435', '85', 'title', 'Suspendisse eleifend commodo magna cursus sodales');
-- query
INSERT INTO app_infodata VALUES ('438', '85', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('437', '85', 'url', '');
-- query
INSERT INTO app_infodata VALUES ('439', '86', 'title', 'Suspendisse eleifend commodo magna cursus sodales');
-- query
INSERT INTO app_infodata VALUES ('440', '86', 'image', '3.jpg');
-- query
INSERT INTO app_infodata VALUES ('441', '86', 'url', '');
-- query
INSERT INTO app_infodata VALUES ('442', '86', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('443', '87', 'title', 'Suspendisse eleifend commodo magna cursus sodales');
-- query
INSERT INTO app_infodata VALUES ('444', '87', 'image', '4.jpg');
-- query
INSERT INTO app_infodata VALUES ('445', '87', 'url', 'http://www.apprain.com');
-- query
INSERT INTO app_infodata VALUES ('446', '87', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('447', '88', 'title', 'Image 1');
-- query
INSERT INTO app_infodata VALUES ('448', '88', 'category', '36,37,38,39');
-- query
INSERT INTO app_infodata VALUES ('449', '88', 'image', 'm1_12958007611105.jpeg');
-- query
INSERT INTO app_infodata VALUES ('450', '88', 'desc', 'Image 1');
-- query
INSERT INTO app_infodata VALUES ('451', '88', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('452', '89', 'title', 'Image 2');
-- query
INSERT INTO app_infodata VALUES ('453', '89', 'category', '36,37,38,39');
-- query
INSERT INTO app_infodata VALUES ('454', '89', 'image', 'm2_12958009026867.jpeg');
-- query
INSERT INTO app_infodata VALUES ('455', '89', 'desc', 'Image ');
-- query
INSERT INTO app_infodata VALUES ('456', '89', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('457', '90', 'title', 'Image 3');
-- query
INSERT INTO app_infodata VALUES ('458', '90', 'category', '36,37,38,39');
-- query
INSERT INTO app_infodata VALUES ('459', '90', 'image', 'm3_12958009226725.jpeg');
-- query
INSERT INTO app_infodata VALUES ('460', '90', 'desc', 'Image 3');
-- query
INSERT INTO app_infodata VALUES ('461', '90', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('462', '91', 'title', 'Image 4');
-- query
INSERT INTO app_infodata VALUES ('463', '91', 'category', '36,37,38,39');
-- query
INSERT INTO app_infodata VALUES ('464', '91', 'image', 'm4_1295800939934.jpeg');
-- query
INSERT INTO app_infodata VALUES ('465', '91', 'desc', 'Image 4');
-- query
INSERT INTO app_infodata VALUES ('466', '91', 'status', 'Inactive');
-- query
INSERT INTO app_infodata VALUES ('481', '94', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('482', '95', 'title', 'rod stewart the faces - maggie may 1971');
-- query
INSERT INTO app_infodata VALUES ('483', '95', 'thumburl', 'http://i.ytimg.com/vi/TEoc13bwCw0/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('484', '95', 'description', 'rod stewart maggie may 1971');
-- query
INSERT INTO app_infodata VALUES ('485', '95', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/TEoc13bwCw0?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/TEoc13bwCw0?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('480', '94', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/Tbgv8PkO9eo?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/Tbgv8PkO9eo?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('477', '94', 'title', 'Harry Nilsson - Coconut (1971)');
-- query
INSERT INTO app_infodata VALUES ('478', '94', 'thumburl', 'http://i.ytimg.com/vi/Tbgv8PkO9eo/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('479', '94', 'description', 'once again Harry Nilsson - Coconut (1971)');
-- query
INSERT INTO app_infodata VALUES ('486', '95', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('487', '96', 'title', 'Funny Video');
-- query
INSERT INTO app_infodata VALUES ('488', '96', 'thumburl', 'http://i.ytimg.com/vi/aemXgP-2xyg/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('489', '96', 'description', 'Music: Carl Douglas - Kung Fu Fighting');
-- query
INSERT INTO app_infodata VALUES ('490', '96', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/aemXgP-2xyg?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/aemXgP-2xyg?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('491', '96', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('492', '97', 'title', 'Funny Football');
-- query
INSERT INTO app_infodata VALUES ('493', '97', 'thumburl', 'http://i.ytimg.com/vi/YPQ_N4imYVE/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('494', '97', 'description', 'Ignore the gay referee. It gets better after that');
-- query
INSERT INTO app_infodata VALUES ('495', '97', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/YPQ_N4imYVE?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/YPQ_N4imYVE?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('496', '97', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('497', '98', 'title', 'Comedy Football');
-- query
INSERT INTO app_infodata VALUES ('498', '98', 'thumburl', 'http://i.ytimg.com/vi/vt4X7zFfv4k/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('499', '98', 'description', 'Music: River Kwai march');
-- query
INSERT INTO app_infodata VALUES ('500', '98', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/vt4X7zFfv4k?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/vt4X7zFfv4k?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('501', '98', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('502', '99', 'title', 'Comedy Football');
-- query
INSERT INTO app_infodata VALUES ('503', '99', 'thumburl', 'http://i.ytimg.com/vi/vt4X7zFfv4k/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('504', '99', 'description', 'Music: River Kwai march');
-- query
INSERT INTO app_infodata VALUES ('505', '99', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/vt4X7zFfv4k?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/vt4X7zFfv4k?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('506', '99', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('507', '100', 'title', 'Comedy Football');
-- query
INSERT INTO app_infodata VALUES ('508', '100', 'thumburl', 'http://i.ytimg.com/vi/vt4X7zFfv4k/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('509', '100', 'description', 'Music: River Kwai march');
-- query
INSERT INTO app_infodata VALUES ('510', '100', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/vt4X7zFfv4k?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/vt4X7zFfv4k?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('511', '100', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('512', '101', 'title', 'Comedy Football');
-- query
INSERT INTO app_infodata VALUES ('513', '101', 'thumburl', 'http://i.ytimg.com/vi/vt4X7zFfv4k/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('514', '101', 'description', 'Music: River Kwai march');
-- query
INSERT INTO app_infodata VALUES ('515', '101', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/vt4X7zFfv4k?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/vt4X7zFfv4k?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('516', '101', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('517', '102', 'title', 'Funny Football');
-- query
INSERT INTO app_infodata VALUES ('518', '102', 'thumburl', 'http://i.ytimg.com/vi/YPQ_N4imYVE/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('519', '102', 'description', 'Ignore the gay referee. It gets better after that');
-- query
INSERT INTO app_infodata VALUES ('520', '102', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/YPQ_N4imYVE?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/YPQ_N4imYVE?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('521', '102', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('522', '103', 'title', 'Funny Football');
-- query
INSERT INTO app_infodata VALUES ('523', '103', 'thumburl', 'http://i.ytimg.com/vi/YPQ_N4imYVE/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('524', '103', 'description', 'Ignore the gay referee. It gets better after that');
-- query
INSERT INTO app_infodata VALUES ('525', '103', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/YPQ_N4imYVE?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/YPQ_N4imYVE?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('526', '103', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('527', '104', 'title', 'Comedy Football');
-- query
INSERT INTO app_infodata VALUES ('528', '104', 'thumburl', 'http://i.ytimg.com/vi/vt4X7zFfv4k/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('529', '104', 'description', 'Music: River Kwai march');
-- query
INSERT INTO app_infodata VALUES ('530', '104', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/vt4X7zFfv4k?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/vt4X7zFfv4k?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('531', '104', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('532', '105', 'title', 'Comedy Football');
-- query
INSERT INTO app_infodata VALUES ('533', '105', 'thumburl', 'http://i.ytimg.com/vi/vt4X7zFfv4k/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('534', '105', 'description', 'Music: River Kwai march');
-- query
INSERT INTO app_infodata VALUES ('535', '105', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/vt4X7zFfv4k?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/vt4X7zFfv4k?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('536', '105', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('537', '106', 'title', 'Funny Football');
-- query
INSERT INTO app_infodata VALUES ('538', '106', 'thumburl', 'http://i.ytimg.com/vi/YPQ_N4imYVE/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('539', '106', 'description', 'Ignore the gay referee. It gets better after that');
-- query
INSERT INTO app_infodata VALUES ('540', '106', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/YPQ_N4imYVE?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/YPQ_N4imYVE?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('541', '106', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('542', '107', 'title', 'Funny Football');
-- query
INSERT INTO app_infodata VALUES ('543', '107', 'thumburl', 'http://i.ytimg.com/vi/YPQ_N4imYVE/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('544', '107', 'description', 'Ignore the gay referee. It gets better after that');
-- query
INSERT INTO app_infodata VALUES ('545', '107', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/YPQ_N4imYVE?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/YPQ_N4imYVE?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('546', '107', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('547', '108', 'title', 'american football ... pick me');
-- query
INSERT INTO app_infodata VALUES ('548', '108', 'thumburl', 'http://i.ytimg.com/vi/GIVCjLALwQk/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('549', '108', 'description', 'chris cooley - Washington Redskins chris chambers - San Diego Chargers Jason Cambell - Washington Redskins Marques Colston - New Orleans Saints Andre Johnson - Houston Texans Mike Nugent - New York Jets Marc Bulger - St. Louis Rams Mason Crosby - Green Bay Packers showing their skills...the reason why to pick them ;)');
-- query
INSERT INTO app_infodata VALUES ('550', '108', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/GIVCjLALwQk?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/GIVCjLALwQk?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('551', '108', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('552', '109', 'title', 'american football ... pick me');
-- query
INSERT INTO app_infodata VALUES ('553', '109', 'thumburl', 'http://i.ytimg.com/vi/GIVCjLALwQk/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('554', '109', 'description', 'chris cooley - Washington Redskins chris chambers - San Diego Chargers Jason Cambell - Washington Redskins Marques Colston - New Orleans Saints Andre Johnson - Houston Texans Mike Nugent - New York Jets Marc Bulger - St. Louis Rams Mason Crosby - Green Bay Packers showing their skills...the reason why to pick them ;)');
-- query
INSERT INTO app_infodata VALUES ('555', '109', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/GIVCjLALwQk?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/GIVCjLALwQk?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('556', '109', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('557', '110', 'title', 'american football ... pick me');
-- query
INSERT INTO app_infodata VALUES ('558', '110', 'thumburl', 'http://i.ytimg.com/vi/GIVCjLALwQk/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('559', '110', 'description', 'chris cooley - Washington Redskins chris chambers - San Diego Chargers Jason Cambell - Washington Redskins Marques Colston - New Orleans Saints Andre Johnson - Houston Texans Mike Nugent - New York Jets Marc Bulger - St. Louis Rams Mason Crosby - Green Bay Packers showing their skills...the reason why to pick them ;)');
-- query
INSERT INTO app_infodata VALUES ('560', '110', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/GIVCjLALwQk?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/GIVCjLALwQk?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('561', '110', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('562', '111', 'title', 'Top 10 NCAA Football Hits- 2008-''09');
-- query
INSERT INTO app_infodata VALUES ('563', '111', 'thumburl', 'http://i.ytimg.com/vi/jFJqDKgUyPs/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('564', '111', 'description', 'Buy the MP3 at: www.amazon.com See more clips at: espn.go.com All the huge hits from the year put together into one video... a Must see! Audio Rights: Three Six Mafia "I Got" Video Rights: ESPN, NCAA, CBS, CSS, FOX');
-- query
INSERT INTO app_infodata VALUES ('565', '111', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/jFJqDKgUyPs?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/jFJqDKgUyPs?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('566', '111', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('567', '112', 'title', 'Top 10 NCAA Football Hits- 2008-''09');
-- query
INSERT INTO app_infodata VALUES ('568', '112', 'thumburl', 'http://i.ytimg.com/vi/jFJqDKgUyPs/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('569', '112', 'description', 'Buy the MP3 at: www.amazon.com See more clips at: espn.go.com All the huge hits from the year put together into one video... a Must see! Audio Rights: Three Six Mafia "I Got" Video Rights: ESPN, NCAA, CBS, CSS, FOX');
-- query
INSERT INTO app_infodata VALUES ('570', '112', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/jFJqDKgUyPs?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/jFJqDKgUyPs?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('571', '112', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('572', '113', 'title', 'Funny Football');
-- query
INSERT INTO app_infodata VALUES ('573', '113', 'thumburl', 'http://i.ytimg.com/vi/YPQ_N4imYVE/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('574', '113', 'description', 'Ignore the gay referee. It gets better after that');
-- query
INSERT INTO app_infodata VALUES ('575', '113', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/YPQ_N4imYVE?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/YPQ_N4imYVE?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('576', '113', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('577', '114', 'title', 'How To Create A Podcast');
-- query
INSERT INTO app_infodata VALUES ('578', '114', 'thumburl', 'http://i.ytimg.com/vi/-hrBbczS9I0/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('579', '114', 'description', 'This video will show you how to create a podcast and distribute it. We will use Audacity (audacity.sourcforge.net) to edit the podcast and then use one of these programs to upload it to the web: Podango - www.podango.com Podpress - www.mightyseek.com/podpress MyPodcast - www.mypodcast.com Then we will distribute the podcast by submitting to Podcast search engines found at Podcast411 (www.podcast411.com).');
-- query
INSERT INTO app_infodata VALUES ('580', '114', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/-hrBbczS9I0?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/-hrBbczS9I0?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('581', '114', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('582', '115', 'title', 'Playdom Video Podcast - Sorority Life');
-- query
INSERT INTO app_infodata VALUES ('583', '115', 'thumburl', 'http://i.ytimg.com/vi/DOpH9QIT_Sw/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('584', '115', 'description', 'Updates, new features, and more for all the Playdom games! Created by Jordy Serwin');
-- query
INSERT INTO app_infodata VALUES ('585', '115', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/DOpH9QIT_Sw?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/DOpH9QIT_Sw?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('586', '115', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('587', '116', 'title', 'How To Create A Podcast');
-- query
INSERT INTO app_infodata VALUES ('588', '116', 'thumburl', 'http://i.ytimg.com/vi/-hrBbczS9I0/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('589', '116', 'description', 'This video will show you how to create a podcast and distribute it. We will use Audacity (audacity.sourcforge.net) to edit the podcast and then use one of these programs to upload it to the web: Podango - www.podango.com Podpress - www.mightyseek.com/podpress MyPodcast - www.mypodcast.com Then we will distribute the podcast by submitting to Podcast search engines found at Podcast411 (www.podcast411.com).');
-- query
INSERT INTO app_infodata VALUES ('590', '116', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/-hrBbczS9I0?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/-hrBbczS9I0?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('591', '116', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('592', '117', 'title', 'Gameloft Podcast - Gameloft Podcast #11');
-- query
INSERT INTO app_infodata VALUES ('593', '117', 'thumburl', 'http://i.ytimg.com/vi/VrCONZYRKRA/default.jpg');
-- query
INSERT INTO app_infodata VALUES ('594', '117', 'description', '	To enter the contest post your holiday cheers in VIDEO response to this video! 11th episode of Gameloft video with iPhone games: NOVA 2 - Near Orbit Vanguard Alliance, Dungeon Hunter 2, Eternal Legacy, Asphalt 6: Adrenaline, Shadow Guardian; iPad games: Assassin''s Creed Altair''s Chronicles, StarFront: Collision, Spider-Man: Total Mayhem More info on: www.gameloft.com Also check out our Gameloft podcast holiday contest on blog.gameloft.com (official rules bit.ly )
');
-- query
INSERT INTO app_infodata VALUES ('595', '117', 'videocode', '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/VrCONZYRKRA?fs=1&hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/VrCONZYRKRA?fs=1&hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>');
-- query
INSERT INTO app_infodata VALUES ('596', '117', 'status', 'Inactive');
-- query
INSERT INTO app_infodata VALUES ('599', '118', 'description', '<p>
	Lorem ipsum dolor sit amet, consectetur adipiscing</p>
');
-- query
INSERT INTO app_infodata VALUES ('600', '118', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('601', '119', 'title', 'Ipsum dolor sit amet');
-- query
INSERT INTO app_infodata VALUES ('602', '119', 'image', '3_12962281694859.jpg');
-- query
INSERT INTO app_infodata VALUES ('603', '119', 'description', '<p>
	Lorem ipsum dolor sit amet, consectetur adipiscing</p>
');
-- query
INSERT INTO app_infodata VALUES ('604', '119', 'status', 'Active');
-- query
INSERT INTO app_infodata VALUES ('605', '120', 'title', 'Lorem ipsum dolor sit amet');
-- query
INSERT INTO app_infodata VALUES ('606', '120', 'image', '4_12962281906877.jpg');
-- query
INSERT INTO app_infodata VALUES ('607', '120', 'description', '<p>
	Lorem ipsum dolor sit amet, consectetur adipiscing</p>
');
-- query
INSERT INTO app_infodata VALUES ('608', '120', 'status', 'Active');
-- query
DROP TABLE IF EXISTS app_information;
-- query
CREATE TABLE `app_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `link_to` int(11) NOT NULL DEFAULT '0',
  `adminref` int(11) NOT NULL DEFAULT '0',
  `fkey` int(11) NOT NULL DEFAULT '0',
  `generic` varchar(200) NOT NULL,
  `type` varchar(50) NOT NULL,
  `entry_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `threshold` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=122 DEFAULT CHARSET=utf8;
-- query
INSERT INTO app_information VALUES ('7', '0', '1', '0', '10', 'home-press', '2011-01-28 06:48:00', '2011-01-28 06:48:00', '0');
-- query
INSERT INTO app_information VALUES ('8', '0', '1', '0', '12', 'home-synopsis', '2011-04-08 04:27:10', '2011-04-08 04:27:10', '0');
-- query
INSERT INTO app_information VALUES ('10', '0', '1', '0', '14', 'home-synopsis', '2010-09-17 06:03:16', '2010-09-17 06:03:16', '0');
-- query
INSERT INTO app_information VALUES ('11', '0', '1', '0', '13', 'home-synopsis', '2010-08-30 19:01:05', '2010-08-30 19:01:05', '0');
-- query
INSERT INTO app_information VALUES ('14', '0', '1', '0', '12', 'home-press', '2010-09-17 05:16:21', '2010-09-17 05:16:21', '0');
-- query
INSERT INTO app_information VALUES ('15', '0', '1', '0', '14', 'home-press', '2011-01-28 21:14:17', '2011-01-28 21:14:17', '0');
-- query
INSERT INTO app_information VALUES ('16', '0', '1', '0', '13', 'home-press', '2010-09-17 05:16:34', '2010-09-17 05:16:34', '0');
-- query
INSERT INTO app_information VALUES ('17', '0', '1', '0', '11', 'home-press', '2011-01-28 21:17:44', '2011-01-28 21:17:44', '0');
-- query
INSERT INTO app_information VALUES ('19', '0', '1', '0', '11', 'blog-post', '2010-09-02 08:54:14', '2010-09-02 08:54:14', '0');
-- query
INSERT INTO app_information VALUES ('25', '0', '1', '0', '', 'forum-post', '2010-09-02 20:41:35', '2010-09-02 20:41:35', '0');
-- query
INSERT INTO app_information VALUES ('26', '0', '1', '0', '', 'forum-post', '2010-09-02 21:27:29', '2010-09-02 21:27:29', '0');
-- query
INSERT INTO app_information VALUES ('27', '0', '1', '0', '', 'forum-post', '2010-09-02 21:09:39', '2010-09-02 21:09:39', '0');
-- query
INSERT INTO app_information VALUES ('28', '0', '1', '0', '', 'forum-post', '2010-09-02 21:12:43', '2010-09-02 21:12:43', '0');
-- query
INSERT INTO app_information VALUES ('29', '0', '1', '0', '', 'forum-post', '2010-09-02 21:13:52', '2010-09-02 21:13:52', '0');
-- query
INSERT INTO app_information VALUES ('30', '0', '1', '0', '', 'forum-post', '2010-09-02 21:18:49', '2010-09-02 21:18:49', '0');
-- query
INSERT INTO app_information VALUES ('31', '0', '1', '0', '', 'forum-post', '2010-09-02 21:28:27', '2010-09-02 21:28:27', '0');
-- query
INSERT INTO app_information VALUES ('32', '0', '1', '0', '', 'product', '2010-09-03 01:19:03', '2010-09-09 11:40:58', '0');
-- query
INSERT INTO app_information VALUES ('33', '0', '1', '0', '', 'product', '2010-09-03 01:19:16', '2010-09-09 11:40:53', '0');
-- query
INSERT INTO app_information VALUES ('34', '0', '1', '0', '', 'product', '2010-09-09 11:40:45', '2010-09-09 11:40:45', '0');
-- query
INSERT INTO app_information VALUES ('35', '0', '1', '0', '', 'product', '2010-09-09 11:40:39', '2010-09-09 11:40:39', '0');
-- query
INSERT INTO app_information VALUES ('36', '0', '1', '0', '', 'product', '2010-09-09 11:40:28', '2010-09-09 11:40:28', '0');
-- query
INSERT INTO app_information VALUES ('37', '0', '1', '0', '', 'product', '2010-09-09 11:40:22', '2010-09-09 11:40:22', '0');
-- query
INSERT INTO app_information VALUES ('38', '0', '1', '0', '', 'product', '2010-09-09 11:40:16', '2010-09-09 11:40:16', '0');
-- query
INSERT INTO app_information VALUES ('39', '0', '1', '0', '', 'product', '2010-09-09 11:40:10', '2010-09-09 11:40:10', '0');
-- query
INSERT INTO app_information VALUES ('40', '0', '1', '0', '', 'product', '2010-09-09 11:40:04', '2010-09-09 11:40:04', '0');
-- query
INSERT INTO app_information VALUES ('41', '0', '1', '0', '', 'product', '2010-09-09 11:39:59', '2010-09-09 11:39:59', '0');
-- query
INSERT INTO app_information VALUES ('42', '0', '1', '0', '', 'product', '2010-09-09 11:39:17', '2010-09-09 11:39:17', '0');
-- query
INSERT INTO app_information VALUES ('43', '0', '1', '0', '', 'product', '2010-09-09 11:36:39', '2010-09-09 11:38:54', '0');
-- query
INSERT INTO app_information VALUES ('44', '0', '1', '0', '', 'picture', '2010-09-06 07:17:16', '2010-09-06 07:17:16', '0');
-- query
INSERT INTO app_information VALUES ('45', '0', '1', '0', '', 'picture', '2010-09-06 07:17:34', '2010-09-06 07:17:34', '0');
-- query
INSERT INTO app_information VALUES ('46', '0', '1', '0', '', 'picture', '2010-09-06 07:17:52', '2010-09-06 07:17:52', '0');
-- query
INSERT INTO app_information VALUES ('47', '0', '1', '0', '', 'picture', '2010-09-06 07:18:11', '2010-09-06 07:18:11', '0');
-- query
INSERT INTO app_information VALUES ('48', '0', '1', '0', '', 'picture', '2010-09-06 07:18:30', '2010-09-06 07:18:30', '0');
-- query
INSERT INTO app_information VALUES ('49', '0', '1', '0', '', 'picture', '2010-09-06 07:18:48', '2010-09-06 07:18:48', '0');
-- query
INSERT INTO app_information VALUES ('50', '0', '1', '0', '', 'picture', '2010-09-06 07:19:08', '2010-09-06 07:19:08', '0');
-- query
INSERT INTO app_information VALUES ('51', '0', '1', '0', '', 'picture', '2010-09-06 07:19:31', '2010-09-06 07:19:31', '0');
-- query
INSERT INTO app_information VALUES ('52', '0', '1', '0', '', 'picture', '2010-09-06 07:19:53', '2010-09-06 07:19:53', '0');
-- query
INSERT INTO app_information VALUES ('53', '0', '1', '0', '', 'picture', '2010-09-06 07:20:14', '2010-09-06 07:20:14', '0');
-- query
INSERT INTO app_information VALUES ('54', '0', '1', '0', '', 'picture', '2010-09-06 11:43:18', '2010-09-06 11:43:18', '0');
-- query
INSERT INTO app_information VALUES ('55', '0', '1', '0', '', 'picture', '2010-09-06 11:43:52', '2010-09-06 11:43:52', '0');
-- query
INSERT INTO app_information VALUES ('58', '0', '1', '0', '', 'email-template', '2010-09-16 09:07:25', '2010-09-16 09:07:25', '0');
-- query
INSERT INTO app_information VALUES ('59', '0', '1', '0', '', 'email-template', '2010-09-16 09:28:37', '2010-09-16 09:28:37', '0');
-- query
INSERT INTO app_information VALUES ('60', '0', '1', '0', '', 'email-template', '2010-09-16 10:32:48', '2010-09-16 10:32:48', '0');
-- query
INSERT INTO app_information VALUES ('61', '0', '1', '0', '', 'email-template', '2010-09-16 10:34:30', '2010-09-16 10:34:30', '0');
-- query
INSERT INTO app_information VALUES ('66', '0', '1', '0', '', 'email-template', '2010-09-13 01:19:11', '2010-09-13 01:19:11', '0');
-- query
INSERT INTO app_information VALUES ('67', '0', '1', '0', '', 'email-template', '2010-09-13 02:13:08', '2010-09-13 02:13:08', '0');
-- query
INSERT INTO app_information VALUES ('68', '0', '1', '0', '', 'email-template', '2010-09-13 01:21:50', '2010-09-13 01:21:50', '0');
-- query
INSERT INTO app_information VALUES ('69', '0', '1', '0', '', 'email-template', '2010-09-13 01:24:36', '2010-09-13 01:24:36', '0');
-- query
INSERT INTO app_information VALUES ('70', '0', '0', '0', '', 'forum-post', '2010-09-16 10:10:07', '2010-09-16 10:10:07', '0');
-- query
INSERT INTO app_information VALUES ('77', '0', '1', '0', '', 'forum-post', '2010-09-16 10:25:58', '2010-09-16 10:25:58', '0');
-- query
INSERT INTO app_information VALUES ('78', '0', '1', '0', '', 'forum-post', '2011-03-21 11:16:39', '2011-03-21 11:16:39', '0');
-- query
INSERT INTO app_information VALUES ('79', '0', '1', '0', '', 'email-template', '2010-09-16 20:50:15', '2010-09-16 20:50:15', '0');
-- query
INSERT INTO app_information VALUES ('80', '0', '1', '0', '', 'email-template', '2010-09-16 23:02:57', '2010-09-16 23:02:57', '0');
-- query
INSERT INTO app_information VALUES ('84', '0', '1', '0', '', 'imagerotator-image', '2011-01-19 01:16:10', '2011-01-19 01:16:10', '0');
-- query
INSERT INTO app_information VALUES ('85', '0', '1', '0', '', 'imagerotator-image', '2011-01-19 01:16:21', '2011-01-19 01:16:21', '0');
-- query
INSERT INTO app_information VALUES ('86', '0', '1', '0', '', 'imagerotator-image', '2011-01-19 01:16:33', '2011-01-19 01:16:33', '0');
-- query
INSERT INTO app_information VALUES ('87', '0', '1', '0', '', 'imagerotator-image', '2011-01-19 01:23:14', '2011-01-19 01:23:14', '0');
-- query
INSERT INTO app_information VALUES ('88', '0', '1', '0', '', 'mobilegallery', '2011-01-23 08:39:21', '2011-01-23 08:39:21', '0');
-- query
INSERT INTO app_information VALUES ('89', '0', '1', '0', '', 'mobilegallery', '2011-01-23 08:41:42', '2011-01-23 08:41:42', '0');
-- query
INSERT INTO app_information VALUES ('90', '0', '1', '0', '', 'mobilegallery', '2011-01-23 08:42:02', '2011-01-23 08:42:02', '0');
-- query
INSERT INTO app_information VALUES ('91', '0', '1', '0', '', 'mobilegallery', '2011-01-23 09:02:29', '2011-01-23 09:02:29', '0');
-- query
INSERT INTO app_information VALUES ('94', '0', '1', '0', '', 'videopodcast', '2011-01-24 18:47:13', '2011-01-24 18:47:13', '0');
-- query
INSERT INTO app_information VALUES ('95', '0', '1', '0', '', 'videopodcast', '2011-01-24 18:47:28', '2011-01-24 18:47:28', '0');
-- query
INSERT INTO app_information VALUES ('96', '0', '1', '0', '', 'videopodcast', '2011-01-24 18:55:31', '2011-01-24 18:55:31', '0');
-- query
INSERT INTO app_information VALUES ('97', '0', '1', '0', '', 'videopodcast', '2011-01-24 18:57:33', '2011-01-24 18:57:33', '0');
-- query
INSERT INTO app_information VALUES ('98', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:00:14', '2011-01-24 19:00:14', '0');
-- query
INSERT INTO app_information VALUES ('99', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:03:48', '2011-01-24 19:03:48', '0');
-- query
INSERT INTO app_information VALUES ('100', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:04:46', '2011-01-24 19:04:46', '0');
-- query
INSERT INTO app_information VALUES ('101', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:05:31', '2011-01-24 19:05:31', '0');
-- query
INSERT INTO app_information VALUES ('102', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:05:39', '2011-01-24 19:05:39', '0');
-- query
INSERT INTO app_information VALUES ('103', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:05:39', '2011-01-24 19:05:39', '0');
-- query
INSERT INTO app_information VALUES ('104', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:06:52', '2011-01-24 19:06:52', '0');
-- query
INSERT INTO app_information VALUES ('105', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:06:52', '2011-01-24 19:06:52', '0');
-- query
INSERT INTO app_information VALUES ('106', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:06:58', '2011-01-24 19:06:58', '0');
-- query
INSERT INTO app_information VALUES ('107', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:06:58', '2011-01-24 19:06:58', '0');
-- query
INSERT INTO app_information VALUES ('108', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:07:03', '2011-01-24 19:07:03', '0');
-- query
INSERT INTO app_information VALUES ('109', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:07:03', '2011-01-24 19:07:03', '0');
-- query
INSERT INTO app_information VALUES ('110', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:07:03', '2011-01-24 19:07:03', '0');
-- query
INSERT INTO app_information VALUES ('111', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:07:07', '2011-01-24 19:07:07', '0');
-- query
INSERT INTO app_information VALUES ('112', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:07:07', '2011-01-24 19:07:07', '0');
-- query
INSERT INTO app_information VALUES ('113', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:10:04', '2011-01-24 19:10:04', '0');
-- query
INSERT INTO app_information VALUES ('114', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:18:07', '2011-01-24 19:18:07', '0');
-- query
INSERT INTO app_information VALUES ('115', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:19:11', '2011-01-24 19:19:11', '0');
-- query
INSERT INTO app_information VALUES ('116', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:19:28', '2011-01-24 19:19:28', '0');
-- query
INSERT INTO app_information VALUES ('117', '0', '1', '0', '', 'videopodcast', '2011-01-24 19:27:05', '2011-01-24 19:27:05', '0');
-- query
INSERT INTO app_information VALUES ('118', '0', '1', '0', '10', 'app-banner', '2011-01-28 07:23:57', '2011-01-28 07:23:57', '0');
-- query
INSERT INTO app_information VALUES ('119', '0', '1', '0', '', 'app-banner', '2011-01-28 07:23:37', '2011-01-28 07:23:37', '0');
-- query
INSERT INTO app_information VALUES ('120', '0', '1', '0', '', 'app-banner', '2011-01-28 07:23:24', '2011-01-28 07:23:24', '0');
-- query
DROP TABLE IF EXISTS app_items;
-- query
CREATE TABLE `app_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `dated` datetime NOT NULL,
  `title` varchar(200) NOT NULL,
  `unitprice` float NOT NULL,
  `totalprice` float NOT NULL,
  `productdata` text NOT NULL,
  `status` enum('Pending','Processing','Complete') NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
-- query
DROP TABLE IF EXISTS app_log;
-- query
CREATE TABLE `app_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `dated` datetime NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
-- query
DROP TABLE IF EXISTS app_members;
-- query
CREATE TABLE `app_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photo` varchar(50) NOT NULL,
  `name_title` varchar(200) NOT NULL,
  `f_name` varchar(200) NOT NULL,
  `l_name` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `state` varchar(50) NOT NULL,
  `zipcode` varchar(15) NOT NULL,
  `country` varchar(50) NOT NULL,
  `gmcoordinate` varchar(50) NOT NULL,
  `exp_date` date NOT NULL DEFAULT '0000-00-00',
  `website` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `signup_date` date NOT NULL DEFAULT '0000-00-00',
  `phone_no` varchar(50) NOT NULL,
  `status` enum('Applied','Accepted','Active','Inactive','Defaulter') NOT NULL DEFAULT 'Applied',
  `resetid` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
-- query
INSERT INTO app_members VALUES ('1', '', 'Mr.', 'appRain', 'CMF', 'afdd0b4ad2ec172c586e2150770fbf9e', 'info@apprain.com', 'appCity, appCountry', 'dhaka', '1209', 'BD', '', '0000-00-00', 'www.apprain.com', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor. Duis scelerisque viverra rutrum. Cras et bibendum libero. Vivamus ante diam, volutpat et gravida posuere, adipiscing tristique sapien. Donec eget tortor vitae erat pharetra dapibus et eu lectus. Nullam interdum mollis nisl at commodo. Duis vestibulum nunc in risus placerat ac rhoncus mi fringilla.', '2009-03-28', '1209', 'Active', '1284736279');
-- query
DROP TABLE IF EXISTS app_orders;
-- query
CREATE TABLE `app_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qty` int(11) NOT NULL,
  `totalcost` float NOT NULL,
  `shippingaddress` text NOT NULL,
  `shippingcost` float NOT NULL,
  `nextdaydelivery` enum('Yes','No') NOT NULL DEFAULT 'No',
  `orderdate` date NOT NULL,
  `paymenttype` varchar(50) NOT NULL,
  `paymentdata` text NOT NULL,
  `deliverystatus` enum('Processing','Pending','Complete') NOT NULL DEFAULT 'Pending',
  `paymentstatus` enum('Pending','Paid') NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
-- query
DROP TABLE IF EXISTS app_pages;
-- query
CREATE TABLE `app_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey` int(11) NOT NULL DEFAULT '0',
  `page_title` varchar(80) NOT NULL,
  `meta_keywords` varchar(200) NOT NULL,
  `meta_description` varchar(150) NOT NULL,
  `name` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `hook` varchar(255) NOT NULL,
  `rendertype` enum('h_link','smart_h_link','text') NOT NULL,
  `contenttype` enum('Content','Snip') NOT NULL DEFAULT 'Content',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fkey` (`fkey`,`name`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
-- query
INSERT INTO app_pages VALUES ('1', '0', 'Aretra facilisis lacus ac sollicitudin', 'Proin, pharetra facilisis, lacus, ac, sollicitudin, Sed congue, dolor, egestas, metus dictum, feugiatm, Ut eros', 'Sed congue dolor egestas metus dictum feugiat. Ut eros mi, pharetra vel adipiscing vitae', 'aboutus', 'About Us', '<p>
	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sit amet velit ipsum. Sed eu ipsum eu diam placerat volutpat. Suspendisse arcu arcu, mattis blandit tempus non, faucibus a felis. Fusce quis diam lobortis metus interdum laoreet. Nunc sodales, turpis aliquam vehicula condimentum, dui ipsum dignissim massa, tincidunt cursus neque felis sit amet turpis. Integer accumsan tempor euismod. Aenean cursus, est ac vestibulum venenatis, nulla purus aliquet enim, eget adipiscing ligula velit non mauris. Vivamus viverra rutrum lectus sit amet sagittis. Pellentesque sit amet lectus quis dui cursus iaculis eu et massa.</p>
<p>
	Duis arcu elit, rutrum a interdum quis, vulputate et diam. Mauris eleifend cursus tortor. Sed ut leo quis nisi vehicula sagittis. Maecenas sed nisl at quam vulputate mattis in nec sapien. Etiam vel massa in eros sodales bibendum. Vestibulum ut urna cursus lectus sodales facilisis vel vitae sem. Aenean a nisl ut nulla ullamcorper tristique non quis sem. Vestibulum at orci a velit varius consectetur quis sit amet diam. Phasellus eget felis purus.</p>
<p>
	Sed congue dolor egestas metus dictum feugiat. Ut eros mi, pharetra vel adipiscing vitae, ultricies vel mauris. Vestibulum sed urna in nibh porta volutpat. Nulla risus dui, ultrices sit amet consequat quis, tincidunt nec ipsum. In dolor ante, volutpat quis semper quis, faucibus ac nibh. Curabitur in feugiat ligula. Ut feugiat justo quis metus feugiat ac vulputate mauris varius. Etiam quis posuere elit. Sed vitae quam arcu. Aliquam erat volutpat. Cras malesuada sem id lacus consectetur ut laoreet justo fringilla. Nam nibh nunc, dapibus ac auctor vel, ultrices a neque. Nunc tempus odio vitae turpis varius et gravida ante pharetra. Morbi semper nunc et nibh feugiat at gravida justo blandit. Cras justo nibh, euismod fermentum vehicula sed, vestibulum at ipsum. Proin eu ante at sem vehicula iaculis vitae id dui. Duis non felis erat, ut pulvinar nibh. Nunc eu ipsum turpis.</p>
', '', 'text', '');
-- query
INSERT INTO app_pages VALUES ('2', '0', 'Facilisis lacus ac sollicitudin', 'Proin, pharetra facilisis, lacus, ac, sollicitudin, Sed congue, dolor, egestas, metus dictum, feugiatm, Ut eros', 'Sed congue dolor egestas metus dictum feugiat. Ut eros mi, pharetra vel adipiscing vitae', 'terms', 'Yestibulum ante ipsum primis', '<p>Vivamus sit amet velit ipsum. Sed eu ipsum eu diam placerat volutpat. Suspendisse arcu arcu, mattis blandit tempus non, faucibus a felis. Fusce quis diam lobortis metus interdum laoreet. Nunc sodales, turpis aliquam vehicula condimentum, dui ipsum dignissim massa, tincidunt cursus neque felis sit amet turpis. Integer accumsan tempor euismod. Aenean cursus, est ac vestibulum venenatis, nulla purus aliquet enim, eget adipiscing ligula velit non mauris. </p><p>Vivamus viverra rutrum lectus sit amet sagittis. Pellentesque sit amet lectus quis dui cursus iaculis eu et massa. Duis arcu elit, rutrum a interdum quis, vulputate et diam. Mauris eleifend cursus tortor. Sed ut leo quis nisi vehicula sagittis. Maecenas sed nisl at quam vulputate mattis in nec sapien. Etiam vel massa in eros sodales bibendum. Vestibulum ut urna cursus lectus sodales facilisis vel vitae sem. Aenean a nisl ut nulla ullamcorper tristique non quis sem. Vestibulum at orci a velit varius consectetur quis sit amet diam. Phasellus eget felis purus.</p><p>Sed congue dolor egestas metus dictum feugiat. Ut eros mi, pharetra vel adipiscing vitae, ultricies vel mauris. Vestibulum sed urna in nibh porta volutpat. Nulla risus dui, ultrices sit amet consequat quis, tincidunt nec ipsum. In dolor ante, volutpat quis semper quis, faucibus ac nibh. Curabitur in feugiat ligula. Ut feugiat justo quis metus feugiat ac vulputate mauris varius.</p><p>Etiam quis posuere elit. Sed vitae quam arcu. Aliquam erat volutpat. Cras malesuada sem id lacus consectetur ut laoreet justo fringilla. Nam nibh nunc, dapibus ac auctor vel, ultrices a neque. Nunc tempus odio vitae turpis varius et gravida ante pharetra. Morbi semper nunc et nibh feugiat at gravida justo blandit. Cras justo nibh, euismod fermentum vehicula sed, vestibulum at ipsum. </p><p>Proin eu ante at sem vehicula iaculis vitae id dui. Duis non felis erat, ut pulvinar nibh. Nunc eu ipsum turpis.</p>', '', '', 'Content');
-- query
INSERT INTO app_pages VALUES ('3', '0', 'Proin pharetra facilisis lacus ac sollicitudin', 'Proin, pharetra facilisis, lacus, ac, sollicitudin, Sed congue, dolor, egestas, metus dictum, feugiatm, Ut eros', 'Sed congue dolor egestas metus dictum feugiat. Ut eros mi, pharetra vel adipiscing vitae', 'homepage', 'Proin pharetra facilisis lacus ac sollicitudin', '<p>Sed congue dolor egestas metus dictum feugiat. Ut eros mi, pharetra vel adipiscing vitae, ultricies vel mauris. Vestibulum sed urna in nibh porta volutpat. Nulla risus dui, ultrices sit amet consequat quis, tincidunt nec ipsum. In dolor ante, volutpat quis semper quis, faucibus ac nibh. Curabitur in feugiat ligula. Ut feugiat justo quis metus feugiat ac vulputate mauris varius. Etiam quis posuere elit. Sed vitae quam arcu. Aliquam erat volutpat. Cras malesuada sem id lacus consectetur ut laoreet justo fringilla.</p><p>Nam nibh nunc, dapibus ac auctor vel, ultrices a neque. Nunc tempus odio vitae turpis varius et gravida ante pharetra. Morbi semper nunc et nibh feugiat at gravida justo blandit. Cras justo nibh, euismod fermentum vehicula sed, vestibulum at ipsum. Proin eu ante at sem vehicula iaculis vitae id dui. Duis non felis erat, ut pulvinar nibh. Nunc eu ipsum turpis.</p><p>Aliquam at enim non quam ultricies elementum vel at tortor. Duis vel nisl nibh. Vivamus vitae urna ut eros pulvinar consequat et vulputate diam. Aliquam neque urna, bibendum at aliquet id, sodales non ipsum. Fusce aliquam arcu non purus sagittis a varius felis facilisis. Maecenas sed diam purus. Pellentesque sit amet malesuada mauris. Aliquam a metus ligula.</p><p>Nunc mollis dictum molestie. Nunc id velit diam, quis gravida est. Proin porttitor condimentum nisl id bibendum. In eu pretium lectus.</p><p>Vivamus vulputate pharetra mauris, ut laoreet urna facilisis vel. Nulla et nunc dolor. Maecenas non risus turpis. Sed at lobortis nulla. Vestibulum et libero sem, at mollis mi. Proin convallis risus mauris. Nam porttitor ornare bibendum. Morbi a ante in erat fermentum interdum at a turpis. Nam scelerisque, erat et consectetur ornare, nulla nisi ornare purus, vitae rhoncus odio erat et massa. Nulla tempus justo vel nunc rutrum et condimentum mi semper.</p>', '', '', 'Content');
-- query
INSERT INTO app_pages VALUES ('4', '0', 'Blog | Lorem ipsum dolor sit amet, consectetur adipiscing elit', 'Lorem ipsum, Dolor sit amet, Consectetur adipiscing elit', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', 'Blog', 'blog', '<p>
	Blog</p>
', '', '', 'Content');
-- query
INSERT INTO app_pages VALUES ('5', '0', 'Payment Completed Successfully', 'Lorem ipsum dolor sit amet, consectetur adipiscing eli', 'Lorem ipsum dolor sit amet, consectetur adipiscing eli', 'payment-success', 'Payment Completed Successfully', '<p>
	We will contact us you soon.<br />
	<br />
	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor. Duis scelerisque viverra rutrum. Cras et bibendum libero. Vivamus ante diam, volutpat et gravida posuere, adipiscing tristique sapien. Donec eget tortor vitae erat pharetra dapibus et eu lectus. Nullam interdum mollis nisl at commodo. Duis vestibulum nunc in risus placerat ac rhoncus mi fringilla.</p>
<p>
	Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor. Duis scelerisque viverra rutrum. Cras et bibendum libero. Vivamus ante diam, volutpat et gravida posuere, adipiscing tristique sapien. Donec eget tortor vitae erat pharetra dapibus et eu lectus. Nullam interdum mollis nisl at commodo. Duis vestibulum nunc in risus placerat ac rhoncus mi fringilla.<br />
	<br />
	Vivamus porta laoreet ligula a convallis. Vestibulum sagittis nunc metus, ut aliquam massa. Nullam ut vestibulum urna.</p>
', '', '', 'Content');
-- query
INSERT INTO app_pages VALUES ('6', '0', 'Payment Failed', 'Consectetur adipiscing elit. Aenean volutpat consequat rhoncus.', 'Consectetur adipiscing elit. Aenean volutpat consequat rhoncus.', 'payment-failed', 'Sorry! Unfortunately your payment did not go through', '<p>
	Please<a href="checkout"> click here</a> to try again. We will contact you soon. <br />
	<br />
	Consectetur adipiscing elit. Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor. Duis scelerisque viverra rutrum. Cras et bibendum libero. Vivamus ante diam, volutpat et gravida posuere, adipiscing tristique sapien. Donec eget tortor vitae erat pharetra dapibus et eu lectus. Nullam interdum mollis nisl at commodo. Duis vestibulum nunc in risus placerat ac rhoncus mi fringilla.<br />
	<br />
	Eenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor. Duis scelerisque viverra rutrum. Cras et bibendum libero. Vivamus ante diam, volutpat et gravida posuere, adipiscing tristique sapien. Donec eget tortor vitae erat pharetra dapibus et eu lectus. Nullam interdum mollis nisl at commodo. Duis vestibulum nunc in risus placerat ac rhoncus mi fringilla.<br />
	<br />
	Vivamus porta laoreet ligula a convallis. Vestibulum sagittis nunc metus, ut aliquam massa. Nullam ut vestibulum urna.</p>
', '', '', 'Content');
-- query
INSERT INTO app_pages VALUES ('7', '0', 'Contact us | Duis arcu elit, rutrum a interdum quis, vulputate et diam. Mauris e', 'Duis arcu elit, rutrum a interdum quis, vulputate et diam. Mauris eleifend cursus tortor.', 'Duis arcu elit, rutrum a interdum quis, vulputate et diam. Mauris eleifend cursus tortor.', 'contact-us', '', '<p>
	Duis arcu elit, rutrum a interdum quis, vulputate et diam. Mauris eleifend cursus tortor. Sed ut leo quis nisi vehicula sagittis. Maecenas sed nisl at quam vulputate mattis in nec sapien. Etiam vel massa in eros sodales bibendum. Vestibulum ut urna cursus lectus sodales facilisis vel vitae sem. Aenean a nisl ut nulla ullamcorper tristique non quis sem.<br />
	<br />
	<strong>Vestibulum at orci a velit varius</strong><br />
	45/B consectetur quis sit amet<br />
	diam. <br />
	phasellus@eget felis.purus.</p>
', '', '', '');
-- query
INSERT INTO app_pages VALUES ('8', '0', 'Forum | Duis arcu elit, rutrum a interdum quis, vulputate et diam.', 'Duis arcu elit, rutrum a interdum quis, vulputate et diam.', 'Duis arcu elit, rutrum a interdum quis, vulputate et diam.', 'Forum', 'Forum', '<p>
	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sit amet velit ipsum. Sed eu ipsum eu diam placerat volutpat. Suspendisse arcu arcu, mattis blandit tempus non, faucibus a felis. Fusce quis diam lobortis metus interdum laoreet. Nunc sodales, turpis aliquam vehicula condimentum, dui ipsum dignissim massa, tincidunt cursus neque felis sit amet turpis. Integer accumsan tempor euismod. Aenean cursus, est ac vestibulum venenatis, nulla purus aliquet enim, eget adipiscing ligula velit non mauris. Vivamus viverra rutrum lectus sit amet sagittis. Pellentesque sit amet lectus quis dui cursus iaculis eu et massa.</p>
<p>
	Duis arcu elit, rutrum a interdum quis, vulputate et diam. Mauris eleifend cursus tortor. Sed ut leo quis nisi vehicula sagittis. Maecenas sed nisl at quam vulputate mattis in nec sapien. Etiam vel massa in eros sodales bibendum. Vestibulum ut urna cursus lectus sodales facilisis vel vitae sem. Aenean a nisl ut nulla ullamcorper tristique non quis sem. Vestibulum at orci a velit varius consectetur quis sit amet diam. Phasellus eget felis purus.</p>
<p>
	Sed congue dolor egestas metus dictum feugiat. Ut eros mi, pharetra vel adipiscing vitae, ultricies vel mauris. Vestibulum sed urna in nibh porta volutpat. Nulla risus dui, ultrices sit amet consequat quis, tincidunt nec ipsum. In dolor ante, volutpat quis semper quis, faucibus ac nibh. Curabitur in feugiat ligula. Ut feugiat justo quis metus feugiat ac vulputate mauris varius. Etiam quis posuere elit. Sed vitae quam arcu. Aliquam erat volutpat. Cras malesuada sem id lacus consectetur ut laoreet justo fringilla. Nam nibh nunc, dapibus ac auctor vel, ultrices a neque. Nunc tempus odio vitae turpis varius et gravida ante pharetra. Morbi semper nunc et nibh feugiat at gravida justo blandit. Cras justo nibh, euismod fermentum vehicula sed, vestibulum at ipsum. Proin eu ante at sem vehicula iaculis vitae id dui. Duis non felis erat, ut pulvinar nibh. Nunc eu ipsum turpis.</p>
', '', '', 'Content');
-- query
INSERT INTO app_pages VALUES ('10', '0', 'Gallery | Duis placerat libero eget est scelerisque in egestas nibh adipiscing', 'Duis placerat libero eget est scelerisque in egestas nibh adipiscing', 'Duis placerat libero eget est scelerisque in egestas nibh adipiscing', 'Gallery', 'Gallery', '<p>
	Duis placerat libero eget est scelerisque in egestas nibh adipiscing. Praesent magna nisl, ullamcorper non fringilla sed, feugiat quis augue. Duis dignissim lectus vel erat vestibulum sollicitudin. Suspendisse potenti. In eu elit et ipsum varius vehicula ac vel quam. Fusce ultricies molestie turpis, vitae dignissim sem tristique a. Nullam lectus urna, dapibus vitae venenatis nec, vestibulum sed lacus. Etiam odio odio, semper sit amet tincidunt eu, vehicula a turpis. Suspendisse potenti</p>
', '', '', 'Content');
-- query
INSERT INTO app_pages VALUES ('11', '0', 'Checkout | Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sit ', 'Lorem ipsum, Dolor sit amet, consectetur, adipiscing elit, Vivamus sit, Aamet velit, ipsum. ', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sit amet velit ipsum. ', 'Checkout', 'checkout', '<p>
	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sit amet velit ipsum.</p>
', '', '', 'Content');
-- query
INSERT INTO app_pages VALUES ('12', '0', '- Search Result', 'Crem ipsum, Dolor sit amet, consectetur adipiscing elit. Aenean volutpat, consequat rhoncus, Pellentesque, pharetra dictum, viverra', 'Crem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. ', 'search', 'Crem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. ', '<p>
	Crem ipsum dolor sit amet, consectetur adipiscing elit. Aenean volutpat consequat rhoncus. Pellentesque pharetra dictum viverra. Vivamus nisl leo, malesuada ut commodo eu, laoreet sit amet dolor. Duis scelerisque viverra rutrum. Cras et bibendum libero. Vivamus ante diam, volutpat et gravida posuere, adipiscing tristique sapien. Donec eget tortor vitae erat pharetra dapibus et eu lectus. Nullam interdum mollis nisl at commodo. Duis vestibulum nunc in risus placerat ac rhoncus mi fringilla.</p>
', '', '', 'Content');
-- query
INSERT INTO app_pages VALUES ('13', '0', 'Member login  | Suspendisse arcu arcu, mattis blandit tempus non, faucibus a fel', 'Suspendisse arcu arcu, mattis blandit tempus non, faucibus a felis. Fusce quis diam lobortis metus interdum laoreet', 'Suspendisse arcu arcu, mattis blandit tempus non, faucibus a felis. Fusce quis diam lobortis metus interdum laoreet', 'memberlogin', 'Suspendisse arcu arcu', '<p>
	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sit amet velit ipsum. Sed eu ipsum eu diam placerat volutpat. Suspendisse arcu arcu, mattis blandit tempus non, faucibus a felis. Fusce quis diam lobortis metus interdum laoreet.</p>
', '', '', 'Content');
-- query
INSERT INTO app_pages VALUES ('20', '0', '', '', '', 'samplephp', '', '<?php
/**
* Write PHP Code
*
* Example:
* $Config = App::Config()->siteInfo();
* pre($Config);
*/
?>', '', 'h_link', 'Snip');
-- query
DROP TABLE IF EXISTS app_sconfigs;
-- query
CREATE TABLE `app_sconfigs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkey` int(11) NOT NULL DEFAULT '0',
  `soption` text NOT NULL,
  `svalue` text NOT NULL,
  `sort_order` varchar(5) NOT NULL,
  `section` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;
-- query
INSERT INTO app_sconfigs VALUES ('1', '0', 'site_title', 'Start with appRain', '13', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('2', '0', 'admin_email', 'info@site.com', '14', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('3', '0', 'admin_title', 'Start with appRain Admin', '15', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('4', '0', 'support_email', 'info@apprain.com', '16', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('5', '0', 'website_moto', 'Sed congue dolor egestas metus', '17', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('6', '0', 'currency', '$', '18', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('7', '0', 'default_pagination', '15', '19', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('8', '0', 'is_site_alive', 'Yes', '20', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('9', '0', 'large_image_width', '500', '21', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('10', '0', 'large_image_height', '500', '22', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('11', '0', 'time_zone', 'America/Los_Angeles', '23', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('12', '0', 'rich_text_editor', 'Yes', '24', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('13', '0', 'rich_text_editor_mode', 'Simple', '25', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('14', '0', 'replace_cache', 'No', '26', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('15', '0', 'disable_page_meta_options', 'No', '27', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('16', '0', 'theme', 'whitecloud', '28', 'hidden');
-- query
INSERT INTO app_sconfigs VALUES ('17', '0', 'disable_accordion', 'Yes', '', 'opts');
-- query
INSERT INTO app_sconfigs VALUES ('18', '0', 'paypal_title', 'Paypal', '', 'paymentmethod');
-- query
INSERT INTO app_sconfigs VALUES ('19', '0', 'paypal_payment_email', 'payment@example.com', '', 'paymentmethod');
-- query
INSERT INTO app_sconfigs VALUES ('20', '0', 'paypal_mode', 'Sandbox', '', 'paymentmethod');
-- query
INSERT INTO app_sconfigs VALUES ('21', '0', 'paypal_status', 'Active', '', 'paymentmethod');
-- query
INSERT INTO app_sconfigs VALUES ('35', '0', 'galleryopt_current', 'UvumiGallery', '', 'gallery');
-- query
INSERT INTO app_sconfigs VALUES ('30', '0', 'authorizenet_login', '92yz8LWWB3A', '', 'paymentmethod');
-- query
INSERT INTO app_sconfigs VALUES ('29', '0', 'authorizenet_cgi_url', 'https://test.authorize.net/gateway/transact.dll', '', 'paymentmethod');
-- query
INSERT INTO app_sconfigs VALUES ('28', '0', 'authorizenet_title', 'Credit Card', '', 'paymentmethod');
-- query
INSERT INTO app_sconfigs VALUES ('31', '0', 'authorizenet_tran_key', '556rFb45ufRABQ5f', '', 'paymentmethod');
-- query
INSERT INTO app_sconfigs VALUES ('32', '0', 'authorizenet_tran_type', 'AUTH_ONLY', '', 'paymentmethod');
-- query
INSERT INTO app_sconfigs VALUES ('33', '0', 'authorizenet_mode', 'Test', '', 'paymentmethod');
-- query
INSERT INTO app_sconfigs VALUES ('34', '0', 'authorizenet_status', 'Active', '', 'paymentmethod');
-- query
INSERT INTO app_sconfigs VALUES ('38', '0', 'galleryopt_ainogalleria_mode', 'classic-01', '', 'gallery');
-- query
INSERT INTO app_sconfigs VALUES ('36', '0', 'galleryopt_title', 'Gallery', '', 'gallery');
-- query
INSERT INTO app_sconfigs VALUES ('37', '0', 'galleryopt_flashgalleryasymbio_mode', 'GalleryNewBeta', '', 'gallery');
-- query
INSERT INTO app_sconfigs VALUES ('39', '0', 'galleryopt_smoothsallery_mode', 'ContinuousHorizontal', '', 'gallery');
-- query
INSERT INTO app_sconfigs VALUES ('40', '0', 'galleryopt_dlectricprismslideshow_mode', 'FlashShow', '', 'gallery');
-- query
INSERT INTO app_sconfigs VALUES ('41', '0', 'galleryopt_dlectricprismslideshow_bottomnav', 'true', '', 'gallery');
-- query
INSERT INTO app_sconfigs VALUES ('42', '0', 'galleryopt_dlectricprismslideshow_caption', 'true', '', 'gallery');
-- query
INSERT INTO app_sconfigs VALUES ('43', '0', 'galleryopt_glitter_effect', 'Yes', '', 'gallery');
-- query
INSERT INTO app_sconfigs VALUES ('44', '0', 'site_logo_1', 'logo.gif', '', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('45', '0', 'site_logo_2', 'apprain-logo-yellow.gif', '', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('49', '0', 'copy_right_text', 'Copy Right [year] [website]', '', 'general');
-- query
INSERT INTO app_sconfigs VALUES ('50', '0', 'imagerotator_canvas_width', '980', '', 'imagerotator');
-- query
INSERT INTO app_sconfigs VALUES ('51', '0', 'imagerotator_canvas_height', '300', '', 'imagerotator');
-- query
INSERT INTO app_sconfigs VALUES ('52', '1', 'site_title', 'Site Title', '10', 'usersetting');
-- query
INSERT INTO app_sconfigs VALUES ('53', '1', 'site_email', 'user@domain.com', '11', 'usersetting');
-- query
INSERT INTO app_sconfigs VALUES ('54', '1', 'rich_text_editor', 'Yes', '12', 'usersetting');
-- query
INSERT INTO app_sconfigs VALUES ('55', '1', 'rich_text_editor_mode', 'Simple', '13', 'usersetting');
-- query
INSERT INTO app_sconfigs VALUES ('56', '1', 'time_zone', 'America/Los_Angeles', '14', 'usersetting');
-- query
INSERT INTO app_sconfigs VALUES ('57', '1', 'default_pagination', '20', '15', 'usersetting');
-- query
INSERT INTO app_sconfigs VALUES ('58', '1', 'large_image_width', '1000', '16', 'usersetting');
-- query
INSERT INTO app_sconfigs VALUES ('59', '1', 'large_image_height', '800', '17', 'usersetting');
-- query
INSERT INTO app_sconfigs VALUES ('60', '1', 'disable_page_meta_options', 'Yes', '18', 'usersetting');
-- query
INSERT INTO app_sconfigs VALUES ('61', '1', 'disable_accordion', 'Yes', '19', 'usersetting');
-- query
INSERT INTO app_sconfigs VALUES ('62', '0', 'contactussettings_title', 'Contact Me', '', 'contactussettings');
-- query
INSERT INTO app_sconfigs VALUES ('63', '0', 'contactussettings_replay_email_title', '', '', 'contactussettings');
-- query
INSERT INTO app_sconfigs VALUES ('64', '0', 'contactussettings_replay_email', '', '', 'contactussettings');
-- query
INSERT INTO app_sconfigs VALUES ('65', '0', 'contactussettings_create_sitemenu', 'Yes', '', 'contactussettings');
-- query
INSERT INTO app_sconfigs VALUES ('66', '0', 'activity_wiget', 'Yes', '', 'opts');
-- query
INSERT INTO app_sconfigs VALUES ('67', '0', 'leave_amessage_wiget', 'Yes', '', 'opts');
-- query
INSERT INTO app_sconfigs VALUES ('68', '0', 'whitecloud_disable_site_member_options', 'No', '', 'settings');
