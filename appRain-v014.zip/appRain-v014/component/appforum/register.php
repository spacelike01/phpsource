<?php
class Component_Appforum_Register extends appRain_Base_Component
{
    public function init()
    {
		App::Module('Hook')->setHookName('CSS')
                           ->setAction("register_css_code")
                           ->Register(get_class($this),"register_css_code");

		App::Module('Hook')->setHookName('Controller')
                           ->setAction("register_controller")
                           ->Register(get_class($this),"register_controller");

		App::Module('Hook')->setHookName('Model')
                           ->setAction("register_model")
                           ->Register(get_class($this),"register_model");

		App::Module('Hook')->setHookName('InformationSet')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_informationset_defination");

		App::Module('Hook')->setHookName('CategorySet')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_categoryset_defination");

		App::Module('Hook')->setHookName('InterfaceBuilder')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_interface_builder_defination");

		App::Module('Hook')->setHookName('Sitemenu')
                           ->setAction("register_sitemenu")
                           ->Register(get_class($this),"register_sitemenu");

		App::Module('Hook')->setHookName('URIManager')
                           ->setAction("on_initialize")
                           ->Register(get_class($this),"register_newrole");

		App::Module('Hook')->setHookName('Helper')
                           ->setAction("register_helper")
                           ->Register(get_class($this),"register_helper");
    }

    public function init_on_install()
	{
		$this->autoRegisterAdminTopNav('forum');
	}
    public function init_on_uninstall(){}

	public function register_css_code()
    {
        return App::Helper('Utility')->fetchFile($this->attachMyPath('css/styles.css'));
    }

	public function register_controller()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('name'=>'appForum',
                              'controller_path'=>$this->attachMyPath('controllers'));
        return $srcpaths;
    }

	public function register_informationset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('type'=>'forum-post',
                               'path'=>$this->attachMyPath('information_set/forum-post.xml'));
        return $srcpaths;
    }

	public function register_categoryset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('type'=>'forum-cat',
                              'path'=>$this->attachMyPath('category_set/forum-cat.xml'));
        return $srcpaths;
    }

	public function register_interface_builder_defination()
    {
        $srcpaths = Array();
        $srcpaths[] = $this->attachMyPath('interface_builder/forum.xml');
        return array('filepaths'=>$srcpaths);
    }

	public function register_model()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('name'=>'Comment',
                              'model_path'=>$this->attachMyPath('models'));
        return $srcpaths;
    }

	public function register_sitemenu($send)
	{
		$menu = Array();
		$menu[] = Array(App::Helper('Config')->baseurl("/forum"),'Forum','forum');
		return $menu;
	}

	public function register_newrole($def=null)
    {
        $def['pagerouter'][] = array("actual"=>Array("appforum","index"),"virtual"=>Array("forum"));
		$def['pagerouter'][] = array("actual"=>Array("appforum","submitpost"),"virtual"=>Array("add-post-to-forum"));
        return $def;
    }

	public function register_helper()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('name'=>'Data',
                              'path'=>$this->attachMyPath('helpers/data.php'));
        return $srcpaths;
    }
}