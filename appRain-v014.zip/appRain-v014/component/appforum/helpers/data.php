<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Inc. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/documents
 */

class Component_Appforum_Helpers_Data extends appRain_Base_Objects
{

    public function Category2ThreadCount($id = null)
    {
		$data = App::InformationSet('forum-post')->findAll(Array(Array('status'=>'Active'),'AND',Array("category"=>"{$id}")));
		return isset($data['data']) ?  count($data['data']) : 0;
    }

	public function Category2PostCount($id = null)
    {
		return App::Model('Comment')->countEntry("catid={$id} AND status='Active'");
    }

	public function postId2CommentCount($id = null)
    {
		return App::Model('Comment')->countEntry("postid={$id} AND status='Active'");
    }


	public function Id2CommentInfo($id=null ,$flag = true)
	{
		$html = App::Helper('Html');
		$config = App::Helper('Config');

		$data = App::Model('Comment')->findById($id);
		if(!empty($data))
		{
			$username = App::Model('Member')->fieldToField('id',$data['userid'],Array('f_name','l_name'));
			return $html->linkTag($config->baseurl("/profile/{$data['userid']}/" . App::Helper('Utility')->text2normalize($username)),$username)
			. (($flag)  ? $this->__(' <br />') : $this->__(' Says on, '))
			. App::Helper('Date')->dateFormated($data['dated'],'long');
		}

		return "&nbsp;";
	}

	public function Id2PostInfo($id=null,$flag = true)
	{
		$html = App::Helper('Html');
		$config = App::Helper('Config');

		$data = App::InformationSet('forum-post')->findById($id);
		if(!empty($data))
		{
			$username = App::Model('Member')->fieldToField('id',$data['userid'],Array('f_name','l_name'));

			if($flag)
			{
				return $this->__(' Posted  By ') . $html->linkTag($config->baseurl("/profile/{$data['userid']}/" . App::Helper('Utility')->text2normalize($username)),$username) . $this->__(' <br /> on ') . App::Helper('Date')->dateFormated($data['last_modified'],'long');
			}
			else
			{
				return $this->__(' Posted  By ') . $html->linkTag($config->baseurl("/profile/{$data['userid']}/" . App::Helper('Utility')->text2normalize($username)),$username) . $this->__('on ') . App::Helper('Date')->dateFormated($data['last_modified'],'long');
			}
		}

		return "&nbsp;";
	}

	public function Category2LastPostInfo($id=null)
	{
		$html = App::Helper('Html');
		$config = App::Helper('Config');

		$data = App::InformationSet('forum-post')->find("1 ORDER BY id DESC",Array(Array("category"=>$id),"AND",Array("status"=>"Active")));//Category $id
		if(!empty($data))
		{
			$username = App::Model('Member')->fieldToField('id',$data['userid'],Array('f_name','l_name'));
			return $html->linkTag($config->baseurl("/forum/p/{$data['id']}/" .  App::Helper('Utility')->text2normalize($data['title'])), substr($data['title'],0,60)) . $this->__(' <br />  By ') . $html->linkTag($config->baseurl("/profile/{$data['userid']}/" . App::Helper('Utility')->text2normalize($username)),$username) . $this->__(' <br /> on ') . App::Helper('Date')->dateFormated($data['last_modified'],'long');
		}

		return "&nbsp;";
	}
}