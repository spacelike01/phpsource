<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Inc. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/documents
 */
class appforumController extends appRain_Base_Core
{
    public $name = 'appForum';

    public function __preDispatch()
    {

    }

    /**
     * This function will reander the home page
     *
     * @return null
     */
    public function indexAction($action = null, $id = null)
    {
        $this->staticPageNameToMetaInfo('Forum');

        if(!empty($this->data))
        {
            $this->layout = 'empty';

            $capacha = App::Module('Session')->read('capacha');
            if($capacha['commentpost'] != $this->data['Comment']['capacha'])
            {
                echo(App::Module('Cryptography')->jsonEncode(Array("_status"=>"Error","_message"=>"Fille capacha text correclty.")));
            }
            else if($this->data['Comment']['desc'] == "")
            {
                echo(App::Module('Cryptography')->jsonEncode(Array("_status"=>"Error","_message"=>"Enter a comment.")));
            }
            else
            {
                $memberData = App::MemberManager()->memberInformation(App::MemberManager()->AppUserloggedInId());

                App::Model('Comment')
                     ->setPostid($id)
                     ->setCatid($this->data['Comment']['category'])
                     ->setUserid(App::MemberManager()->AppUserloggedInId())
                     ->setComment($this->data['Comment']['desc'])
                     ->setType('Forum')
                     ->setDated(date('Y-m-d H:i:s'))
                     ->setStatus('Inactive')
                     ->Save();
                echo(App::Module('Cryptography')->jsonEncode(Array("_status"=>"Success","_message"=>"Reply posted successfully. Waiting for pendig appproval.")));

                App::Helper('EmailTemplate')->setParameters(Array(
                                                                    'Name'=>"{$memberData['f_name']} {$memberData['l_name']}",
                                                                    'Comment'=>$this->data['Comment']['desc'],
                                                                    'EmailAddress'=>$memberData['email'],
                                                                    'Website'=>$memberData['website']
                                                            ))
                                            ->prepare('ForumComment',true);
            }
        }

        $this->addons = Array('syntaxhighlighter','validation','ajaxsubmit');

        if($action == 'c')
        {
            $postlist = App::Informationset('forum-post')->findAll('1 ORDER BY id DESC',Array(Array("status"=>"Active"),'AND',Array('category'=>$id)));
            $this->set('postlist',$postlist);
            $this->page_title = App::CategorySet()->idToName($id);
        }
        else if($action == 'p')
        {
            $postinfo = App::Informationset('forum-post')->findById($id);
            $this->set('postinfo',$postinfo);
            $this->page_title = $postinfo['title'];
            $commetns = App::Model('Comment')->findALl("postid = {$id} AND status='Active'");
            $this->set('commetns',$commetns);

        }
        else
        {
            $man_cat  = App::CategorySet('forum-cat')->findAll();
            $this->set('man_cat',$man_cat);
        }

        $this->set("section_title","Forum");
        $this->set("selected","forum");
        $this->set("action",$action);
        $this->set("id",$id);
    }

    public function submitpostAction()
    {
        $pageInfo = $this->staticPageNameToMetaInfo('ForumPost');

        /* Manage Post */
        if(!empty($this->data))
        {
            $this->layout = 'empty';
            $capacha = App::Module('Session')->read('capacha');
            if( $capacha['forumpost'] != $this->data["Forum"]['capacha'])
            {
                echo App::Module("Cryptography")->jsonEncode(
                           Array("_status"=>"Error","_message"=>$this->__("Please fillup capacha correctly."))
                         );
            }
            else
            {

                $errors = App::InformationSet('forum-post')
                            ->setTitle($this->data["Forum"]["title"])
                            ->setCategory($this->data["Forum"]["cat"])
                            ->setUserid(App::MemberManager()->AppUserloggedInId())
                            ->setDescription($this->data["Forum"]["desc"])
                            ->setStatus('Inactive')
                            ->save()
                            ->getErrorInfo();

                if(empty($errors))
                {
                    $memberData = App::MemberManager()->memberInformation(App::MemberManager()->AppUserloggedInId());
                    App::Helper('EmailTemplate')->setParameters(Array(
                                                                    'Name'=>"{$memberData['f_name']} {$memberData['l_name']}",
                                                                    'Title'=>$this->data['Forum']['title'],
                                                                    'EmailAddress'=>$memberData['email'],
                                                                    'Website'=>$memberData['website']
                                                            ))
                                                ->prepare('ForumPost',true);

                    echo App::Module("Cryptography")
                        ->jsonEncode(
                           Array("_status"=>"Success","_message"=>$this->__("Post submittedy Successfully, waiting for pending approval."))
                         );
                }
                else
                {
                    echo App::Module("Cryptography")->jsonEncode(
                           Array("_status"=>"Error","_message"=>$this->__("Please fillup the form correclty."))
                         );
                }
            }
        }

        $this->addons = array('validation','ajaxsubmit');

        $man_cat  = App::CategorySet('forum-cat')->findAll();
        $this->set('man_cat',$man_cat);
        $this->set("pageInfo",$pageInfo);
        $this->set("section_title","Forum");
        $this->set("selected","forum");
    }

    public function manageCommentAction($action = NULL, $id = NULL)
    {
        $this->addons = Array('row_manager');
        $this->setAdminTab('forum');

        if(!empty($this->data))
        {
            $this->data['Comment']['id'] = $id;
            App::Model('Comment')->Save($this->data);
            $this->redirect("/appforum/managecomment");///update/{$id}
            exit;
        }

        if($action == 'update')
        {
            $data = App::Model('Comment')->findById($id);
            $this->set("data_list",$data);
        }
        else
        {
            $data = App::Model('Comment')->paging("type='Forum' ORDER BY id DESC",20);
            $this->set("data_list",$data);
        }
        $this->set('action',$action);
    }
}