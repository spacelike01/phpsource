<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Inc. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/documents
 */
class appgalleryController extends appRain_Base_Core
{
    public $name = 'appGallery';
	const G_PREFIX = 'Component_appGallery_Helpers_Gallery_';

	public function __preDispatch()
	{
		$this->set("section_title",App::Helper('Config')->siteInfo('galleryopt_title'));
		$this->set("selected","gallery");
	}
    /**
     * This function will reander the home page
     *
     * @return null
     */
    public function indexAction($action=null, $id=null)
    {
		$staticPage = $this->staticPageNameToMetaInfo('Gallery');

		if($action=='bycat')
		{
			try
			{
				$currentgallery = App::Helper('Config')->siteInfo('galleryopt_current');
				$this->set('currentgallery',$currentgallery);

				if(strlen($currentgallery))
				{
					$this->layout = App::__obj(self::G_PREFIX . "{$currentgallery}")->initLayout();
					$this->addons = App::__obj(self::G_PREFIX . "{$currentgallery}")->initAddons();

				}
				else throw new AppException($this->__("System error, Select gallery from setting."));

				$catdata = App::Categoryset()->findById($id);
				$this->set('catdata',$catdata);

				// Overwrite preview section title
				$this->page_title = App::CategorySet()->idToName($id);
				$this->set("section_title",$catdata['title']);
			}
			catch (AppException $e)
			{
				die($e->getMessage());
				$this->set("error",$e->getMessage());
			}

		}
		else
		{
			if(App::Helper('Config')->siteInfo('galleryopt_glitter_effect') == 'Yes')
			{
				$this->addons = Array('glitter');
			}

			$this->assignCategories();
		}

		$this->set('action',$action);
    }

	private function assignCategories()
	{
		$categories = App::CategorySet('gallery-cat')->findAll("1 ORDER BY GENERIC ASC");
		if(count($categories['data']) == 1 )
		{
			$this->redirect("/gallery-by-cat/{$categories['data'][0]['id']}");
			exit;
		}
		$this->set('categories',$categories);
	}
	/**
	 * Applicable for the galleries requerd xml to share
	 */
	public function getXMLResourcesAction($action=NULL, $flag=NULL)
	{
		$this->layout = 'empty';
		header('Content-type: text/xml');

		$currentgallery = App::Helper('Config')->siteInfo('galleryopt_current');
		App::__Obj(self::G_PREFIX . "{$currentgallery}")->renderXMLResources($action,$flag);
	}
}
