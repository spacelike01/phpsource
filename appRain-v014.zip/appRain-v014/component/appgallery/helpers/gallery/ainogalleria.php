<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_appGallery_Helpers_Gallery_AinoGalleria extends Component_appGallery_Helpers_Data
{
	public function renderHTML()
	{
		$id = $this->getCategoryId();
		$pictures = App::InformationSet('picture')->findAll('1 ORDER BY ID DESC',Array(Array("category"=>"%{$id}%","cnd"=>"LIKE")));
		if(!empty($pictures['data']))
		{
			$html = '';
			foreach($pictures['data'] as $picture)
			{
					$html .=	App::Helper('Html')->imgTag(App::Helper("Config")->baseUrl("/uploads/filemanager/{$picture['image']}"),NULL,array(" title"=>$picture['title']));
			}

			$html = App::Helper('Html')->getTag('div',array('id'=>'galleria','style'=>'background-color:#000'),$html);
		}

		return	$html . $this->getJSCode();
	}

	private function getJSCode()
	{
		switch(App::Helper('Config')->siteInfo('galleryopt_ainogalleria_mode'))
		{
			case 'fullscreen-03':
									$code = 'Galleria.loadTheme(\'' . App::Helper("Config")->baseUrl('/addons/galleries/ainogalleria/src/themes/fullscreen/galleria.fullscreen.js'). '\');
									jQuery(\'#galleria\').galleria({
															image_crop: false, // don’t crop images
															transition: \'slide\', // sliding transition
															show_info: false, // don’t show captions
															thumbnails: false // hide the thumbnails
														});';
									break;
			case 'fullscreen-02':
									$code = 'Galleria.loadTheme(\'' . App::Helper("Config")->baseUrl('/addons/galleries/ainogalleria/src/themes/fullscreen/galleria.fullscreen.js'). '\');
									jQuery(\'#galleria\').galleria({
															image_crop: false, // don’t crop images
															transition: \'slide\', // sliding transition
														});';
									break;
			case 'fullscreen-01':
									$code = 'Galleria.loadTheme(\'' . App::Helper("Config")->baseUrl('/addons/galleries/ainogalleria/src/themes/fullscreen/galleria.fullscreen.js'). '\');
									jQuery(\'#galleria\').galleria();';
									break;
			case 'dots-01'	 	:
									$code = 'Galleria.loadTheme(\'' . App::Helper("Config")->baseUrl('/addons/galleries/ainogalleria/src/themes/dots/galleria.dots.js'). '\');
									jQuery(\'#galleria\').galleria();';
									break;
			case 'classic-02'	:
								$code = 'Galleria.loadTheme(\'' . App::Helper("Config")->baseUrl('/addons/galleries/ainogalleria/src/themes/classic/galleria.classic.js'). '\');

								jQuery(\'#galleria\').galleria({
									image_crop: true, // crop all images to fit
									thumb_crop: true, // crop all thumbnails to fit
									transition: \'fade\', // crossfade photos
									transition_speed: 700, // slow down the crossfade
									data_config: function(img) {
										return  {
											title: $(img).parent().next(\'strong\').html(),
											description: $(img).parent().next(\'strong\').next().html()
										};
									},
									extend: function() {
										this.bind(Galleria.IMAGE, function(e) {
											$(e.imageTarget).css(\'cursor\',\'pointer\').click(this.proxy(function() {
												this.openLightbox();
											}));
										});
									}
								});';
								break;
			default		  :
							$code = 'Galleria.loadTheme(\'' . App::Helper("Config")->baseUrl('/addons/galleries/ainogalleria/src/themes/classic/galleria.classic.js'). '\');
									 jQuery("#galleria").galleria();';
		}

		return App::Helper('Html')->getTag('script',array('type'=>'text/javascript'),$code);

	}

}