<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_appGallery_Helpers_Gallery_SmoothGallery extends Component_appGallery_Helpers_Data
{
	public function renderHTML()
	{
		$id = $this->getCategoryId();
		$pictures = App::InformationSet('picture')->findAll('1 ORDER BY ID DESC',Array(Array("category"=>"%{$id}%","cnd"=>"LIKE")));
		if(!empty($pictures['data']))
		{
			$html = App::Helper('Html');
			$html = '<div id="myGallery">';
			foreach($pictures['data'] as $picture)
			{
				$html .=
				'<div class="imageElement">
					<h3>' . $picture['title'] . '</h3>
					<p>Item 1 Description</p>
					<a href="#" title="open image" class="open"></a>
					<img src="' . App::Helper("Config")->baseUrl("/uploads/filemanager/{$picture['image']}") . '" class="full" />
					<img src="' . App::Helper("Config")->baseUrl("/uploads/filemanager/{$picture['imagethumb']}") . '" class="thumbnail" />
				</div>';
			}
			$html .= '</div>';

			return $html . $this->getjsCode();
		}
	}

	public function getjsCode()
	{
		$jsCode = "";
		switch(App::Helper("Config")->siteInfo("galleryopt_smoothsallery_mode"))
		{

			case "OffAutoSlide":
										$jsCode=
										"
											function startGallery() {
											var myGallery = new gallery($('myGallery'));
										}
										window.addEvent('domready',startGallery);
										";
										break;
			case "FadeSlideLeft":
										$jsCode=
										"
											function startGallery() {
												var myGallery = new gallery($('myGallery'), {
													timed: true,
													defaultTransition: 'fadeslideleft'
												});
											}
											window.addEvent('domready',startGallery);
										";
										break;
			case "ContinuousVertica":
									$jsCode=
									"
										function startGallery() {
											var myGallery = new gallery($('myGallery'), {
												timed: true,
												defaultTransition: 'continuousvertical'
											});
										}
										window.addEvent('domready',startGallery);
									";
									break;
			case "ContinuousHorizontal"	:
									$jsCode=
									"
										function startGallery() {
											var myGallery = new gallery($('myGallery'), {
												timed: true,
												defaultTransition: 'continuoushorizontal'
											});
										}
										window.addEvent('domready',startGallery);
									";
									break;
			default 	:
									$jsCode=
									"
										function startGallery() {
											var myGallery = new gallery($('myGallery'), {
												timed: true
											});
										}
										window.addEvent('domready',startGallery);
									";
		}

		return "<script type=\"text/javascript\">{$jsCode}</script>";
	}

}