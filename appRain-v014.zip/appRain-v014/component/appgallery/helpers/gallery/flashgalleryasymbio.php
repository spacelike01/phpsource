<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_appGallery_Helpers_Gallery_FlashGalleryASymbio extends Component_appGallery_Helpers_Data
{
	const  NAME = 'FlashGalleryASymbio';

	public function RenderHTML()
	{
		$xmlLocation = App::Helper("Config")->baseUrl("/appgallery/getXMLResources/bycat/" . $this->getCategoryId());
		if(App::Helper('Config')->siteInfo('galleryopt_flashgalleryasymbio_mode') == 'GalleryDefault')
		{
			$height ='690';
			$flashUrl = App::Helper("Config")->baseUrl("/addons/galleries/" . strtolower(self::NAME) . "/gallery.swf");
		}
		else
		{
			$height ='550';
			$flashUrl = App::Helper("Config")->baseUrl("/addons/galleries/" . strtolower(self::NAME) . "/gallerynew_beta.swf");
		}


		return
		'
			<object codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,18,0" width="920" height="' . $height . '" id="gallery" align="middle">
					<param name="allowScriptAccess" value="sameDomain" />
					<param name="allowFullScreen" value="true" />
					<param name="movie" value="' . $flashUrl . '?xml_file=' . $xmlLocation . '&t=' . time() . '" />
					<param name="quality" value="high" />
					<param name="scale" value="noscale" />
					<param name="bgcolor" value="#000000" />
					<embed src="' . $flashUrl . '?xml_file=' . $xmlLocation . '&t=' . time() . '" quality="high" allowFullScreen="true" scale="noscale" bgcolor="#000000" width="920px" height="' . $height . '" name="gallery" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
			</object>
		';
	}

	public function renderXMLResources($action=NULL, $id=NULL)
	{
		$pictures = App::InformationSet('picture')->findAll('1 ORDER BY ID DESC',Array(Array("category"=>"%{$id}%","cnd"=>"LIKE")));
		if(!empty($pictures['data']))
		{
			$xml = '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
			$xml .= '<images>';
			foreach($pictures['data'] as $picture)
			{
				$xml .=	"<pic>";
					$xml .=	"<image>" . App::Helper("Config")->baseUrl("/uploads/filemanager/{$picture['image']}"). "</image>";
					$xml .=	"<thumbnail>" . App::Helper("Config")->baseUrl("/uploads/filemanager/{$picture['imagethumb']}"). "</thumbnail>";
					$xml .=	"<caption>" . $picture['title'] . "</caption>";
				$xml .=	"</pic>";
			}
			$xml .= '</images>';

			echo $xml;
		}

	}
}