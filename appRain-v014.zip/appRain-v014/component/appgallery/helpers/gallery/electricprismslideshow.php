<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_appGallery_Helpers_Gallery_ElectricprismSlideShow extends Component_appGallery_Helpers_Data
{
	public function renderHTML()
	{
		$id = $this->getCategoryId();
		$pictures = App::InformationSet('picture')->findAll('1 ORDER BY ID DESC',Array(Array("category"=>"%{$id}%","cnd"=>"LIKE")));
		if(!empty($pictures['data']))
		{
			$code = '';
			$preload_pic = "";
			$preload_title = '';
			foreach($pictures['data'] as $key => $picture)
			{
				if($key == 0)
				{
					$preload_pic = $picture['image'];
					$preload_title = $picture['title'];
					$code .= "'{$picture['image']}': { caption: '{$picture['title']}' }";
				}
				else
				{
					$code .= ",'{$picture['image']}': { caption: '{$picture['title']}' }";
				}

			}
			$html =
			'
				<div id="show" class="slideshow">
					<img src="' . App::Helper('Config')->baseUrl("/uploads/filemanager/{$preload_pic}") . '" alt="' . $preload_title . '" />
				</div>
			' .
			"<script type=\"text/javascript\">
			//<![CDATA[
			  window.addEvent('domready', function(){
				var data = {
				  {$code}
				};
				"  . $this->getJSCode() . "
			  });
			//]]>
			</script>";

			return $html;
		}
	}

	public function getJSCode()
	{
		$url = App::Helper('Config')->baseUrl('/uploads/filemanager/');
		$code = "";
		$bottomnav = App::Helper("Config")->siteInfo("galleryopt_dlectricprismslideshow_bottomnav");
		$caption = App::Helper("Config")->siteInfo("galleryopt_dlectricprismslideshow_caption");

		switch(App::Helper("Config")->siteInfo("galleryopt_dlectricprismslideshow_mode"))
		{
			case "FoldShow" :
									$code = "var myShow = new Slideshow.Fold('show', data, { captions: {$caption}, center: false, controller: true, duration: 1000, height: 450, hu: '{$url}', thumbnails: {$bottomnav},transition: 'bounce:out',width: 850});";
									break;
			case "FlashShow" :
									$code = "var myShow = new Slideshow.Flash('show', data, { captions: {$caption}, color: ['#EC2415', '#7EBBFF'], controller: true, delay: 2500, duration: 3000, height: 450, hu: '{$url}', thumbnails: {$bottomnav},width: 850, zoom: 25 });";
									break;
			case "PushShow" :
									$code = "var myShow = new Slideshow.Push('show', data, { captions: {$caption}, controller: true, delay: 2500, duration: 2000, height: 450, hu: '{$url}', thumbnails: {$bottomnav},transition: 'elastic:out', width: 850, zoom: 25 });";
									break;
			case "KenBurns" :
									$code = "var myShow = new Slideshow.KenBurns('show', data, { captions: {$caption}, controller: true, delay: 5000, duration: 2000, height: 450, hu: '{$url}', thumbnails: {$bottomnav}, width: 850, zoom: 50 });";
									break;
			case "Transitions" :
									$code = "var myShow = new Slideshow('show', data, { captions: {$caption}, classes: ['', '', '', '', '', '', '', 'alternate-images'], controller: true, duration: 1250, height: 450, hu: '{$url}', overlap: false, thumbnails: {$bottomnav}, transition: 'back:in:out', width: 850});";
									break;
			default:
									$code = "var myShow = new Slideshow('show', data, {captions: {$caption},controller: true, height: 450, hu: '{$url}', thumbnails: {$bottomnav}, width: 850,transition: 'elastic:out'});";
									break;
		}

		return $code;
	}

}