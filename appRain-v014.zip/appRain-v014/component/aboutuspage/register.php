<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

 /**
  * Component Name: Contact us
  * Auther: Reazaul Karim
  * Email: info@apprain.com
  */
class Component_Aboutuspage_Register extends appRain_Base_Component
{
    /**
     * Initialize all resource
     * in side apprain environment.
     */
    public function init()
    {
        $page = App::PageManager()->getData('aboutus');
        if(empty($page))
        {
            App::Module('Hook')->setHookName('UI')->setAction("register_notification")->Register(get_class($this),"register_admin_notification");
            app::$__appData['componenterr'][] = array('About Us',$this->__('Please create a page in Page Manager with the name of "aboutus"'));
        }

        App::Module('Hook')->setHookName('Sitemenu')
                           ->setAction("register_sitemenu")
                           ->Register(get_class($this),"register_sitemenu");

        App::Module('Hook')->setHookName('URIManager')
                           ->setAction("on_initialize")
                           ->Register(get_class($this),"register_newrole");
    }

    public function register_admin_notification($e)
    {
        $messages = Array();

        $messages[] = array($this->__('Please create a page in Page Manager with the name of "aboutus"'),array('type'=>'admin-notice','level'=>'Warning'));

        return $messages;
    }

    /**
     * Register Site Menu
     */
    public function register_sitemenu($send)
    {
        $menu = Array();
        $menu[] = Array(App::Helper('Config')->baseurl("/about-us"),'About Us','aboutus');
        return $menu;
    }

    public function register_newrole($def=null)
    {
        $def['pagerouter'][] = array("actual"=>Array("page","view","aboutus"),"virtual"=>Array("about-us"));
        return $def;
    }
}
// Contact: info@apprain.com