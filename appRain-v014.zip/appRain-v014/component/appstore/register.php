<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_Appstore_Register extends appRain_Base_Component
{
    public function init()
    {

		/*App::Module('Hook')->setHookName('UI')
                           ->setAction("register_notification")
                           ->Register(get_class($this),"register_admin_notification");*/

		App::Module('Hook')->setHookName('CSS')
                           ->setAction("register_css_code")
                           ->Register(get_class($this),"register_css_code");

		App::Module('Hook')->setHookName('Sitemenu')
                           ->setAction("register_sitemenu")
                           ->Register(get_class($this),"register_sitemenu");

		App::Module('Hook')->setHookName('Controller')
                           ->setAction("register_controller")
                           ->Register(get_class($this),"register_controller");


		App::Module('Hook')->setHookName('InformationSet')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_informationset_defination");

		App::Module('Hook')->setHookName('CategorySet')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_categoryset_defination");

		App::Module('Hook')->setHookName('InterfaceBuilder')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_interface_builder_defination");

		App::Module('Hook')->setHookName('Sitesettings')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_sitesettings_defination");

		App::Module('Hook')->setHookName('Addon')
                           ->setAction("register_addon")
                           ->Register(get_class($this),"register_addon_defination");

		App::Module('Hook')->setHookName('Model')
                           ->setAction("register_model")
                           ->Register(get_class($this),"register_model");

		App::Module('Hook')->setHookName('URIManager')
                           ->setAction("on_initialize")
                           ->Register(get_class($this),"register_newrole");

		App::Module('Hook')->setHookName('Helper')
                           ->setAction("register_helper")
                           ->Register(get_class($this),"register_helper");

		App::Module('Hook')->setHookName('UI')
                           ->setAction("template_header_bottom_right_A")
                           ->Register(get_class($this),"add_cart_link");
    }

	public function register_admin_notification($e)
	{
		$messages = Array();

		$messages[] = array($this->__("Two commets waiting for approval.."),array('type'=>'admin-notice','level'=>'Warning'));

		return $messages;
	}

    public function init_on_install()
	{
		$this->autoRegisterAdminTopNav('catalog');
	}

    public function register_css_code()
    {
        return App::Helper('Utility')->fetchFile($this->attachMyPath('css/styles.css'));
    }

	public function register_controller()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('name'=>'appStore',
                              'controller_path'=>$this->attachMyPath('controllers'));
        return $srcpaths;
    }

	public function register_informationset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('type'=>'product',
                               'path'=>$this->attachMyPath('information_set/product.xml'));
        return $srcpaths;
    }

	public function register_categoryset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('type'=>'product-cat',
                              'path'=>$this->attachMyPath('category_set/product-cat.xml'));
        return $srcpaths;
    }

	public function register_interface_builder_defination()
    {
        $srcpaths = Array();
        $srcpaths[] = $this->attachMyPath('interface_builder/catalog.xml');
        return array('filepaths'=>$srcpaths);
    }

	public function register_model()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('name'=>'Item',
                              'model_path'=>$this->attachMyPath('models'));

		$srcpaths[] =   array('name'=>'Order',
                              'model_path'=>$this->attachMyPath('models'));

		/*$srcpaths[] =   array('name'=>'Comment',
                              'model_path'=>$this->attachMyPath('models'));*/


        return $srcpaths;
    }

	public function register_sitemenu($send)
	{
		$menu = Array();
		$menu[] = Array(App::Helper('Config')->baseurl("/store"),'Store','store');
		return $menu;
	}

	public function register_newrole($def=null)
    {
        $def['pagerouter'][] = array("actual"=>Array("appstore","index"),"virtual"=>Array("store"));
		$def['pagerouter'][] = array("actual"=>Array("appstore","index","bycat"),"virtual"=>Array("store-by-cat"));
		//$def['pagerouter'][] = array("actual"=>Array("appstore","index","byproduct"),"virtual"=>Array("blog-by-post"));
		$def['pagerouter'][] = array("actual"=>Array("appstore","checkout"),"virtual"=>Array("checkout"));

		$def['pagerouter'][] = array("actual"=>Array("appstore","statusmessage","payment-success"),"virtual"=>Array("payment-success"));
		$def['pagerouter'][] = array("actual"=>Array("appstore","statusmessage","payment-failed"),"virtual"=>Array("payment-failed"));

        return $def;
    }

	public function register_helper()
    {
        //Default path
    }

	public function register_sitesettings_defination()
    {
        $srcpaths = Array();
        $srcpaths[] = $this->attachMyPath('sitesettings/settings.xml');
        return array('filepaths'=>$srcpaths);
    }

	public function register_addon_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('type'=>'appstore',
                              'path'=>$this->attachMyPath('addons/appstore.xml'));
        return $srcpaths;
    }

	public function add_cart_link($send)
	{
		$Config = App::Helper('COnfig');
		$html  = "";
		$html .= '<div class="tcartinfo">';
		$html .= App::Helper('Html')->linkTag($Config->baseUrl("/checkout"),
											 $this->__('Cart') . ' (<span id="tqtycart">'  .
											 App::Component('appStore')->Helper('Data')->getCartTotalItem() .
											 '</span>)');
		$html .= '</div>';
		return $html;
	}
}