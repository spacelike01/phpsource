<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_Appstore_Helpers_Pgateway_Render extends appRain_Base_Objects
{
    public $methods = Array('paypal','authorizenet','invoice');
    private $selectedindex = 0;
    const STATUS_ACTIVE = 'Active';
    const STATUS_INACTIVE = 'Inactive';

	public function __construct()
	{

	}

	public function renderPaymentMethods()
    {
        if(empty($this->methods)) return null;

		$hookedMethods = App::Module('Hook')->getHandler('Plugin','paymentmethod');

        $html = "";
		foreach($hookedMethods as $key => $method)
        {
		   $title = (App::Helper('Config')->siteInfo("{$method['name']}_title",0)) ? App::Helper('Config')->siteInfo("{$method['name']}_title",0) : $method['name'];
           $html .=
					"<div id=\"payment_method_{$method['name']}_wrapper\">
						<input type=\"radio\" id=\"payment_method_{$method['name']}\" class=\"payment_method\" name=\"data[Payment][method]\" value=\"{$method['name']}\" />" . $title . "
						<div id=\"payment_method_{$method['name']}_add\" class=\"payment_method_add\">" . App::__pathToClass($method['class_path'] . DS . $method['name'] . SEXT )->htmlToRender($method) . "</div>
					</div>";
        }


        foreach($this->methods as $key => $method)
        {
           if(
                App::Helper('Config')->siteInfo("{$method}_status",false) == self::STATUS_ACTIVE
             )
             {
                $html .=
                        "<div id=\"payment_method_{$method}_wrapper\">
                            <input type=\"radio\" id=\"payment_method_{$method}\" class=\"payment_method\" name=\"data[Payment][method]\" value=\"{$method}\" />" . App::Helper('Config')->siteInfo("{$method}_title") . "
                            <div id=\"payment_method_{$method}_add\" class=\"payment_method_add\">" . App::Component('appStore')->Helper("Pgateway_{$method}")->htmlToRender($method) . "</div>
                        </div>";
             }
        }
        return $html;
    }
}