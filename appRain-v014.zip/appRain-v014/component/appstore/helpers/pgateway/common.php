<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_Appstore_Helpers_Pgateway_Common extends appRain_Base_Objects
{
    public function paymentStatus()
    {
        return Component_Appstore_Helpers_Data::STATUS_PAID;
    }

    public function shippingStatus()
    {
        return Component_Appstore_Helpers_Data::STATUS_PROCESSING;
    }

	public function getObject($methodName=null)
	{
		if(!isset($methodName))  return false;

		if(in_array($methodName,App::Component('appStore')->Helper("Pgateway_Render")->methods))
		{
			return App::Component('appStore')->Helper("Pgateway_{$methodName}");
		}
		else
		{
			$hookedMethods = App::Module('Hook')->getHandler('Plugin','paymentmethod');
			$obj = null;
			if(!empty($hookedMethods))
			{for($pg=0;$pg<count($hookedMethods); $pg++)
			{
				if($hookedMethods[$pg]['name'] == $methodName)
				{
					$obj = App::__pathToClass($hookedMethods[$pg]['class_path'] . DS . $hookedMethods[$pg]['name'] . SEXT );
					break;
				}
			}}

			return $obj;
		}
	}
}