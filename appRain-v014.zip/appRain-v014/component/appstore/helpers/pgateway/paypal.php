<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class Component_Appstore_Helpers_Pgateway_Paypal extends Component_Appstore_Helpers_Pgateway_Common
{
	public $paypal_url = 'https://www.paypal.com/cgi-bin/webscr';
	public $paypal_sandbox_url = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
	public $payment_success_url = '/payment-success';
	public $payment_failed_url = '/payment-failed';
	public $payment_notify_url = '/appstore/paypalipn';
	public $payment_post_url = '/appstore/paypal-post';
	const STATUS_NAME = 'Paypal';

	public function __construct()
	{

	}

	public function place()
	{
		echo App::Module("Cryptography")->jsonEncode(
													 Array(
															"_status" =>"Redirect",
															"_location"=> App::Helper('Config')->baseurl($this->payment_post_url)
															)
													 );
		exit;
	}

	public function getStatusName()
	{
		return self::STATUS_NAME;
	}

	public function submitPost()
	{
		$this->setCommonVars();

		$Config = App::Helper('Config');

		App::Plugin("Paypal_Standard")->add_field('business', $Config->siteInfo('paypal_payment_email'))
									  ->add_field('return', $Config->baseUrl($this->payment_success_url))
									  ->add_field('cancel_return', $Config->baseUrl($this->payment_failed_url))
									  ->add_field('notify_url', $Config->baseUrl($this->payment_notify_url))
									  ->add_field('currency_code', 'USD')
									  ->add_field('item_name', $Config->siteInfo('site_title'))
									  ->add_field('amount', $this->getAmount())
									  ->add_field('custom', $this->getOrderId())
									  ->submit_paypal_post();
	}

	public function ExecuteIPN()
	{
		$this->setCommonVars();

		if(App::Plugin("Paypal_Standard")->validate_ipn())
		{
			$orderid = App::Plugin("Paypal_Standard")->ipn_data['custom'];
			App::Helper("appStore")->setPaymentType('Paypal')
								   ->ChnageOrderStatus($orderid)
							       ->clearcart();
		}
	}

	public function setCommonVars()
	{
		if(App::Helper('Config')->siteInfo('paypal_mode') == 'Sandbox') App::Plugin("Paypal_Standard")->paypal_url = $this->paypal_sandbox_url;
		else App::Plugin("Paypal_Standard")->paypal_url = $this->paypal_url;

		return $this;
	}

    public function htmlToRender()
    {
        return $this->__("Paypal website standard payment");
    }
}