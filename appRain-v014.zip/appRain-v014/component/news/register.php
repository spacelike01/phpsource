<?php
class Component_News_Register extends appRain_Base_Component
{
    public function init()
    {
		App::Module('Hook')->setHookName('Controller')
                           ->setAction("register_controller")
                           ->Register(get_class($this),"register_controller");

		App::Module('Hook')->setHookName('InterfaceBuilder')
                           ->setAction("update_definition")
                           ->Register(get_class($this),"interfacebuilder_update_definition");

		App::Module('Hook')->setHookName('InformationSet')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_informationset_defination");
    }

    public function init_on_install(){}

    public function init_on_uninstall(){}

	public function register_controller()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('name'=>'news',
                              'controller_path'=>$this->attachMyPath('controllers'));
        return $srcpaths;
    }

	public function interfacebuilder_update_definition($send)
    {
        if(isset($send['component']['child']))
        {
            $send['component']['child'][] = Array("title"=>"News",
												"items"=>Array(array("title"=>"New News","link"=>"/information/manage/appnews/add"),
															   array("title"=>"Manage News","link"=>"/information/manage/appnews")),
                                                "adminicon" => array("type"=>"filePath",'location'=>'/component/mobilegallery/icon/logo.jpg'));
            return $send;
        }
    }

	public function register_informationset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('type'=>'appnews',
                               'path'=>$this->attachMyPath('information_set/appnews.xml'));
        return $srcpaths;
    }
}