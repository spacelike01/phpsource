<?php
class Component_Simplerss_Register extends appRain_Base_Component
{
    public function init()
    {
		App::Module('Hook')->setHookName('UI')
                           ->setAction("template_footer_after_footer_menu")
                           ->Register(get_class($this),"add_html");

		App::Module('Hook')->setHookName('Controller')
                           ->setAction("register_controller")
                           ->Register(get_class($this),"register_controller");

		App::Module('Hook')->setHookName('InterfaceBuilder')
                           ->setAction("update_definition")
                           ->Register(get_class($this),"interfacebuilder_update_definition");

		App::Module('Hook')->setHookName('InformationSet')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_informationset_defination");
    }

    public function init_on_install(){}

    public function init_on_uninstall(){}

	public function register_controller()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('name'=>'rss',
                              'controller_path'=>$this->attachMyPath('controllers'));
        return $srcpaths;
    }

	public function interfacebuilder_update_definition($send)
    {
        if(isset($send['component']['child']))
        {
            $send['component']['child'][] = Array("title"=>"Simple RSS ",
												"items"=>Array(
															   array("title"=>"New Slide","link"=>"/information/manage/simple-rss/add"),
															   array("title"=>"Manage Slides","link"=>"/information/manage/simple-rss")),
                                                "adminicon" => array("type"=>"filePath",'location'=>'/component/simplerss/icon/logo.jpg'));
            return $send;
        }
    }

	public function add_html($send)
    {
		return '<a href="' . App::Helper('Config')->baseUrl('/rss') . '">RSS Feed</a>';
	}
	public function register_informationset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('type'=>'simple-rss',
                               'path'=>$this->attachMyPath('information_set/simple-rss.xml'));
        return $srcpaths;
    }
}