<?php
class Component_Imagerotator_Register extends appRain_Base_Component
{
	const DEFAULT_WIDTH = '970';
	const DEFAULT_HEIGHT = '300';


    public function init()
    {
		App::Module('Hook')->setHookName('UI')
                           ->setAction("home_page_banner")
                           ->Register(get_class($this),"add_html");

		App::Module('Hook')->setHookName('Controller')
                           ->setAction("register_controller")
                           ->Register(get_class($this),"register_controller");

		App::Module('Hook')->setHookName('InterfaceBuilder')
                           ->setAction("update_definition")
                           ->Register(get_class($this),"interfacebuilder_update_definition");

		App::Module('Hook')->setHookName('InformationSet')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_informationset_defination");

		App::Module('Hook')->setHookName('Sitesettings')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_sitesettings_defination");
    }

    public function init_on_install()
	{
	}

    public function init_on_uninstall(){}

    public function add_html($send)
    {
		$width = App::Helper('Config')->siteInfo('imagerotator_canvas_width',false);
		$width = isset($width) ? $width : self::DEFAULT_WIDTH;

		$height = App::Helper('Config')->siteInfo('imagerotator_canvas_height',false);
		$height = isset($height) ? $height : self::DEFAULT_HEIGHT;


		return '<div id="imagerotator_container" style="text-align:center"><a href="http://www.macromedia.com/go/getflashplayer">Get the Flash Player</a> to see this rotator.</div>' .

			'<script type="text/javascript" src="' . App::Helper('Config')->baseUrl("/componentroot/imagerotator/swfobject.js") . '"></script>
			<script type="text/javascript">
				var s1 = new SWFObject("' . App::Helper('Config')->baseUrl("/componentroot/imagerotator/f_obj.swf"). '","rotator","' . $width . '","' . $height . '","7");
				s1.addParam("allowfullscreen","true");
				s1.addVariable("file","' . App::Helper('Config')->baseUrl("/jwplayerxml") . '");
				s1.addVariable("width","' . $width . '");
				s1.addVariable("height","' . $height . '");
				s1.write("imagerotator_container");
			</script>';
    }

	public function register_controller()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('name'=>'Jwplayerxml',
                              'controller_path'=>$this->attachMyPath('controllers'));
        return $srcpaths;
    }


	public function interfacebuilder_update_definition($send)
    {
        if(isset($send['component']['child']))
        {
            $send['component']['child'][] = Array("title"=>"Image Rotator",
                                            "items"=>Array(array("title"=>"New Image","link"=>"/information/manage/imagerotator-image/add"),
														   array("title"=>"Manage Images","link"=>"/information/manage/imagerotator-image"),
														   array("title"=>"Settings","link"=>"/admin/config/imagerotator")),
                                            "adminicon" => array("type"=>"filePath",'location'=>'/component/imagerotator/icon/logo.jpg'));
            return $send;
        }
    }

	public function register_informationset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('type'=>'imagerotator-image',
                               'path'=>$this->attachMyPath('information_set/imagerotator-image.xml'));
        return $srcpaths;
    }

	public function register_sitesettings_defination()
    {
        $srcpaths = Array();
        $srcpaths[] = $this->attachMyPath('settings/imagerotator.xml');
        return array('filepaths'=>$srcpaths);
    }
}
