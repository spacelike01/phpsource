<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Inc. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/documents
 */
class jwplayerxmlController extends appRain_Base_Core
{
    public $name = 'Jwplayerxml';
    
    public function __preDispatch(){}

    public function indexAction($id=null)
    {
        $this->layout="empty";
        $images = App::InformationSet('imagerotator-image')->findAllByStatus('Active');

        $html =
        '<?xml version="1.0" encoding="utf-8"?>
        <playlist version="1" xmlns="http://xspf.org/ns/0/">
            <trackList>';
            foreach($images['data'] as $image )
            {
                $html .=
                "<track>
                    <title>{$image['title']}</title>
                    <creator>{$image['title']}</creator>
                    <location>" . App::Helper('Config')->baseUrl("/uploads/filemanager/{$image['image']}") .  "</location>
                    <info>{$image['url']}</info>
                </track>";
            }
        $html .="</trackList>
        </playlist>";
        
        @header("Content-type:text/xml");
        echo $html;
    }
}
