<?php
class Component_Videopodcast_Helpers_Youtube extends appRain_Base_Objects
{
     public  $_url = 'http://gdata.youtube.com/feeds/api/videos?v=2';
     private $opts = null;

     public function _construct($url=null){
         if(isset($url))$this->_url = $url;
     }

     public function set($key,$val)
     {
        $this->opts[$key] = $val;
        return $this;
     }

     public function parse($isHTML=false)
     {
        $page = isset($_GET['page']) ? $_GET['page'] : 1;
        $s = ($page-1) *  $this->opts['max-results'];
        $s = ($s) ? $s : 1;
        $this->_url .= "&q={$this->opts['q']}";
        $this->_url .= "&start-index={$s}";
        $this->_url .= "&max-results=" . $this->opts['max-results'];

        $previousepage = $page - 1;
        $linkPrev = ($previousepage >0) ?  "<a href=\"?page={$previousepage}\">Previouse</a>" : "";

        $nextpage = $page + 1;
        $linkNext = "<a href=\"?page={$nextpage}\">Next</a>";

        $links = "";
        for($pp = ($nextpage-8); $pp <$nextpage; $pp++)
        {
            if($pp>0)$links .= " <a href=\"?page={$pp}\">{$pp}</a>";
        }


        $sxml = simplexml_load_file($this->_url);
   //var_dump( $sxml);
   //exit;
        // iterate over entries in feed
        $data = "";
        foreach ($sxml->entry as $entry)
        {

            $id = (string) $entry->id;
            $idarr = explode('video:',$id);

            $embaded = '<object width="480" height="385"><param name="movie" value="http://www.youtube.com/v/'. $idarr[1] .'?fs=1&amp;hl=en_US"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/'.$idarr[1].'?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="480" height="385"></embed></object>';

            // get nodes in media: namespace for media information
            $media = $entry->children('http://search.yahoo.com/mrss/');

            // get video player URL
            $attrs = $media->group->player->attributes();
            $watch = $attrs['url'];

            // get video thumbnail
            $attrs = $media->group->thumbnail[0]->attributes();
            $thumbnail = $attrs['url'];

            // get <yt:duration> node for video length
            $yt = $media->children('http://gdata.youtube.com/schemas/2007');
            $attrs = $yt->duration->attributes();
            $length = $attrs['seconds'];

            // get <yt:stats> node for viewer statistics
            $yt = $entry->children('http://gdata.youtube.com/schemas/2007');
            $attrs = $yt->statistics->attributes();
            $viewCount = $attrs['viewCount'];

            // get <gd:rating> node for video ratings
            $gd = $entry->children('http://schemas.google.com/g/2005');
            if ($gd->rating)
            {
                $attrs = $gd->rating->attributes();
                $rating = $attrs['average'];
            }
            else
            {
                $rating = 0;
            }



            if($isHTML){
            $data .=
            '<div class="item">
                <span class="title">
                  <a href="' . $watch . '">'.  $media->group->title . '</a>
                </span>
                <p>' . $media->group->description . '</p>
                <p>
                  <span class="thumbnail">
                    <img src="' . $thumbnail . '" />
                    <br/>
                  </span>
                  <span class="attr">By:</span> '. $entry->author->name . '<br/>
                  <span class="attr">Duration:</span>'. round($length/60,2) . '
                  min. <br/>
                  <span class="attr">Views:</span>' . $viewCount . '<br/>
                  <span class="attr">Rating:</span>' . $rating. '<br/>
                  <span class="attr">Embaded:</span><br/><textarea style="height:50px;border:1px solid">' . $embaded. '</textarea><br/>
                   <span class="attr">Video Link:</span>' . $rating. '

                </p>
              </div>';
            }
            else
            {
                $data['data'][] = Array
                          (
                                "title" => (string) $media->group->title,
                                "description" => (string) $media->group->description,
                                "thumbnail" => (string) $thumbnail,
                                "author_name" => (string) $entry->author->name,
                                "duration" => round($length/60,2),
                                "views" => (string) $viewCount,
                                "rating" => (string) $rating,
                                "embaded"=>$embaded
                          );
            }
        }

        if(!$isHTML)
        {
            $data['priviouse'] = $linkPrev;
            $data['next'] = $linkNext;
            $data['links'] = "{$links} | {$linkPrev} {$linkNext}" ;
            return $data;
        }
        else
        {
          return $data . "{$links} | {$linkPrev} {$linkNext}";
        }
     }
}