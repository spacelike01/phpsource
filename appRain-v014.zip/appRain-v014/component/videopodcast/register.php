<?php
class Component_Videopodcast_Register extends appRain_Base_Component
{
    public function init()
    {

		App::Module('Hook')->setHookName('InterfaceBuilder')
                           ->setAction("update_definition")
                           ->Register(get_class($this),"interfacebuilder_update_definition");

		App::Module('Hook')->setHookName('Controller')
                           ->setAction("register_controller")
                           ->Register(get_class($this),"register_controller");

		App::Module('Hook')->setHookName('InformationSet')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_informationset_defination");

		App::Module('Hook')->setHookName('Sitemenu')
                           ->setAction("register_sitemenu")
                           ->Register(get_class($this),"register_sitemenu");
    }

	public function register_sitemenu($send)
	{
		$menu = Array();
		$menu[] = Array(App::Helper('Config')->baseurl("/videopodcast"),'Videos','videos');
		return $menu;
	}

	public function register_controller()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('name'=>'Videopodcast',
                              'controller_path'=>$this->attachMyPath('controllers'));
        return $srcpaths;
    }


	public function interfacebuilder_update_definition($send)
    {
        if(isset($send['component']['child']))
        {
            $send['component']['child'][] = Array("title"=>"Video Podcast",
                                            "items"=>Array(array("title"=>"Add Video","link"=>"/information/manage/videopodcast/add"),
														   array("title"=>"Manage Videos","link"=>"/information/manage/videopodcast"),
														   array("title"=>"Search videos","link"=>"/videopodcast/searchvideo")),
                                             "adminicon" => array("type"=>"filePath",'location'=>'/component/videopodcast/icon/logo.jpg'));
            return $send;
        }
    }

	public function register_informationset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('type'=>'videopodcast',
                               'path'=>$this->attachMyPath('information_set/videopodcast.xml'));
        return $srcpaths;
    }

}
