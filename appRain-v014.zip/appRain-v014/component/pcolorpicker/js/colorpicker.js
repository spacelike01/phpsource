window.addEvent('domready', function(){
        $$('.picker table tr td').addEvent('click',function(){
                alert('Color Selected  ' +  this.getStyle('background-color'));
                //alert($$('.picker'));
                //$$('.picker').setStyle('display','none');
        });
                
        $$('.colorbutton').addEvent('click',function(){
                var obj = this.getChildren('div');
        
                $$('.picker').setStyle('display','none');
        
                if(obj.getStyle('display') == 'block') obj.setStyle('display','none');
                else obj.setStyle('display','block');    
        });
});