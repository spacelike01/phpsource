<?php
class Component_Pcolorpicker_Register extends appRain_Base_Component
{
    public function init()
    {
        App::Module('Hook')->setHookName('CSS')
                           ->setAction("register_css_code")
                           ->Register(get_class($this),"register_css_code");

        App::Module('Hook')->setHookName('Javascript')
                           ->setAction("register_javascript_code")
                           ->Register(get_class($this),"register_javascript_code");

        App::Module('Hook')->setHookName('UI')
                           ->setAction("appstore_checkout_button_left")
                           ->Register(get_class($this),"add_html");
    }

    public function init_on_install(){}

    public function init_on_uninstall(){}

    public function register_css_code()
    {
        return '
                .picker td{
                    width:20px;
                    height:20px;
                }
        ';
    }

    public function register_javascript_code()
    {
        return App::Helper('Utility')->fetchFile($this->attachMyPath('js/colorpicker.js'));
    }

    public function add_html($send)
    {
        return '
            <div class="colorbutton" style="display:inline;background-color:#CCC;position:relative;"><a href="javascript:void(0)" class="pickacolor">Color</a>
            <div class="picker" style="display:none;left:5px;position:absolute;z-inzex:500;width:200px;height:100px;background-color:#999">
                <table>
                    <tr>
                        <td style="background-color:#FF0000"></td>
                        <td style="background-color:#00FF00"></td>
                        <td style="background-color:#0000FF"></td>
                        <td style="background-color:#000000"></td>
                        <td style="background-color:#FF0000"></td>
                        <td style="background-color:#00FF00"></td>
                        <td style="background-color:#0000FF"></td>
                        <td style="background-color:#000000"></td>
                    </tr>
                    <tr>
                        <td style="background-color:#FF0000"></td>
                        <td style="background-color:#00FF00"></td>
                        <td style="background-color:#0000FF"></td>
                        <td style="background-color:#000000"></td>
                        <td style="background-color:#FF0000"></td>
                        <td style="background-color:#00FF00"></td>
                        <td style="background-color:#0000FF"></td>
                        <td style="background-color:#000000"></td>
                    </tr>
                    <tr>
                        <td style="background-color:#FF0000"></td>
                        <td style="background-color:#00FF00"></td>
                        <td style="background-color:#0000FF"></td>
                        <td style="background-color:#000000"></td>
                        <td style="background-color:#FF0000"></td>
                        <td style="background-color:#00FF00"></td>
                        <td style="background-color:#0000FF"></td>
                        <td style="background-color:#000000"></td>
                    </tr>
                </table>
            </div>
            </div>';
    }
}