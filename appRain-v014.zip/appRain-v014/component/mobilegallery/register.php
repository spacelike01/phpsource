<?php
class Component_Mobilegallery_Register extends appRain_Base_Component
{
    public function init()
    {
		App::Module('Hook')->setHookName('Controller')
                           ->setAction("register_controller")
                           ->Register(get_class($this),"register_controller");

		App::Module('Hook')->setHookName('InterfaceBuilder')
                           ->setAction("update_definition")
                           ->Register(get_class($this),"interfacebuilder_update_definition");

		App::Module('Hook')->setHookName('CategorySet')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_categoryset_defination");

		App::Module('Hook')->setHookName('InformationSet')
                           ->setAction("register_definition")
                           ->Register(get_class($this),"register_informationset_defination");
    }

    public function init_on_install(){}

    public function init_on_uninstall(){}

	public function register_controller()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('name'=>'wap',
                              'controller_path'=>$this->attachMyPath('controllers'));
        return $srcpaths;
    }

	public function interfacebuilder_update_definition($send)
    {
        if(isset($send['component']['child']))
        {
            $send['component']['child'][] = Array("title"=>"Mobile Gallery",
												"items"=>Array(array("title"=>"New Category","link"=>"/category/manage/mobilegallerycat/add"),
															   array("title"=>"Manage Categories","link"=>"/category/manage/mobilegallerycat"),
															   array("title"=>"New Slide","link"=>"/information/manage/mobilegallery/add"),
															   array("title"=>"Manage Slides","link"=>"/information/manage/mobilegallery")),
                                                "adminicon" => array("type"=>"filePath",'location'=>'/component/mobilegallery/icon/logo.jpg'));
            return $send;
        }
    }

	public function register_categoryset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('type'=>'mobilegallerycat',
                              'path'=>$this->attachMyPath('category_set/mobilegallerycat.xml'));
        return $srcpaths;
    }

	public function register_informationset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array('type'=>'mobilegallery',
                               'path'=>$this->attachMyPath('information_set/mobilegallery.xml'));
        return $srcpaths;
    }
}