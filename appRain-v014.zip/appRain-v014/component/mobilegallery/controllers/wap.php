<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Inc. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/documents
 */
class wapController extends appRain_Base_Core
{
    public $name = 'Wap';

    /**
     * Execute before the action
     */
    public function __preDispatch()
    {
        $this->set("section_title","Gallery In Mobile");
    }

    /**
     * This is blog starting page
     * We have configure this page from
     * URI_Manager >> Boot_Router
     */
    public function indexAction($action=null, $id=null)
    {

		$this->layout = 'blank';

		if($action=='cat')
		{
			$photos = App::InformationSet('mobilegallery')
						 ->setPagination('Yes')
						 ->setLimit(1)
						 ->setSmartPagination('No')
						 ->findAll("1 ORDER By id DESC",
									array(
										array("category"=>"%{$id}%","cnd"=>"like"),
										'AND',
										array("status"=>"Active")));
			$this->set('photos',$photos);

		}
		else
		{
			// Fetch Category
			$categories = App::CategorySet('mobilegallerycat')->findAll();
			$this->set('categories',$categories);
		}

		$this->set('id',$id);
		$this->set('action',$action);
    }
}
