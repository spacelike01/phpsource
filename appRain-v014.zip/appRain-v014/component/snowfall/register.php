<?php
class Component_Snowfall_Register extends appRain_Base_Component
{
    public function init()
    {
        App::Module('Hook')->setHookName('Javascript')
                           ->setAction("register_javascript_code")
                           ->Register(get_class($this),"register_javascript_code");
    }

    public function init_on_install(){}

    public function init_on_uninstall(){}

    public function register_javascript_code()
    {
        return App::Helper('Utility')->fetchFile($this->attachMyPath('js/snowfall.js'));
    }
}