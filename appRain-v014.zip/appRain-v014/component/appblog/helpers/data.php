<?php
class Component_Appblog_Helpers_Data extends appRain_Base_Objects
{
    public function getName()
    {
        return 'test';
    }
}