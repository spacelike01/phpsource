/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */
var s_s ={
	img_name:'.s_s_container img',
	img_fx_obj:{},
	transition_time:4000,
	transition_delay:200,
	hideall:function()
	{
		s_s.img_fx_obj.setOpacity(0);
	},
	show_img: function()
	{
		$$(s_s.img_name).set('tween', {duration:s_s.transition_time, transition:'sine:out'} );
		s_s.img_fx_obj.fade('in');
	},
	init: function(){
		s_s.img_fx_obj = $$(s_s.img_name);
		s_s.hideall();
		s_s.show_img.delay(s_s.transition_delay);
		s_s.img_fx_obj.setStyle('visibility','hidden');
	}
}
window.addEvent('load', s_s.init);