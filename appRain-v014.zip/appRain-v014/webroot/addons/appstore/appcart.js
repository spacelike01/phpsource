/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Inc. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */
var appcart =
{
	_minitem   :0,
	_buttonobj :null,
	_parentobj :null,
    _buttonref :'.add2cart-button',
	_parentref :'.add2cartwrapper',
	_unittref  :'.add2cart-input',
	_productref:'.productid',
	tqtycartref:'#tqtycart',
	_messageref:'cart-msg',
	_chkobtnref:'.checkout-button',
	_chkolink  :'/checkout',
	_delay	   :'slow',
	_l_img     :siteInfo.baseUrl + '/images/loading.gif',
	loading    :function(ptr)
                {
					if(ptr) jQuery(appcart._parentobj).css('background','url(' + appcart._l_img + ') left center no-repeat');
                    else jQuery(appcart._parentobj).css('background','none');
                },
   getUnitTotal:function()
				 {
					var _obj  = jQuery(appcart._parentobj).children(appcart._unittref);
					var total = jQuery(_obj).attr('value');
					if(total < appcart._minitem || isNaN(total))
					{
						total = appcart._minitem;
						jQuery(_obj).attr('value',appcart._minitem);
					}

					return total;
				},
	getProdId  :function()
				{
					return  jQuery(appcart._parentobj).children(appcart._productref).attr('value');
				},
	add2cart   :function()
				{
					appcart._buttonobj = this;
					appcart._parentobj = jQuery(this).parent();
					appcart.loading(true);
				
					jQuery.ajax({
						url: siteInfo.baseUrl + "/appstore/add2qcart/" + appcart.getProdId() + "/" + appcart.getUnitTotal() +  "?ajax=true",
						context: document.body,
						success: function(responseTxt){
							var responseObj = eval('(' + responseTxt + ')');
						  	jQuery(appcart.tqtycartref).text(responseObj.totalitem);							
							jQuery(appcart._parentobj).prepend('<div class="' + appcart._messageref + '">' + responseObj._message + '</div>');							
							appcart.checkoutbtn(responseObj._hastocheckout);
							appcart.clearmsg();
							appcart.loading(false);
						}
					  });
				},
	checkoutbtn:function(F)
				{
					jQuery(appcart._chkobtnref).removeClass('hide');
					jQuery(appcart._chkobtnref).removeClass('show');

					if(F)
					{
						jQuery(appcart._chkobtnref).addClass('show');
					}
					else
					{
						jQuery(appcart._chkobtnref).addClass('hide');
					}
				},
	checkout   :function()
				{
					window.location = siteInfo.baseUrl + appcart._chkolink;
				},
	clearmsg   :function()
				{
					jQuery('.cart-msg').fadeOut(appcart._delay);
				},
    init       :function()
                {
					jQuery(appcart._chkobtnref).click(appcart.checkout);
					jQuery(appcart._buttonref).click(appcart.add2cart);
                }
}

jQuery(document).ready(appcart.init);
