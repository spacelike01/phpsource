/*jQuery(document).ready(function () {
    jQuery("input.autocomplete").autocomplete({
        source: ["c++", "java", "php", "coldfusion", "javascript", "asp", "ruby"]
    });
});*/