jQuery(document).ready(function () {
    jQuery("#dialog").dialog({
        autoOpen: false
    });

    jQuery("#dialog-open").click(function () {
        jQuery("#dialog").dialog("open");
        return false;
    });

    jQuery("#dialog-modal").dialog({
        autoOpen: false,
		width:500,
        //height: 140,
        modal: true
    });

    jQuery("#dialog-modal-open").click(function () {
        jQuery("#dialog-modal").dialog("open");
        return false;
    });

    jQuery("#dialog-message").dialog({
        autoOpen: false,
        modal: true,
        buttons: {
            Ok: function () {
                jQuery(this).dialog('close');
            }
        }
    });

    jQuery("#dialog-message-open").click(function () {
        jQuery("#dialog-message").dialog("open");
        return false;
    });

    jQuery("#dialog-confirm").dialog({
        autoOpen: false,
        resizable: false,
        height: 140,
        modal: true,
        buttons: {
            'Delete all items': function () {
                jQuery(this).dialog('close');
            },
            Cancel: function () {
                jQuery(this).dialog('close');
            }
        }
    });

    jQuery("#dialog-confirm-open").click(function () {
        jQuery("#dialog-confirm").dialog("open");
        return false;
    });

    jQuery("#dialog-form").dialog({
        autoOpen: false,
        height: 300,
        width: 350,
        modal: true,
        buttons: {
            'Create an account': function () {
                jQuery(this).dialog('close');
            },
            Cancel: function () {
                jQuery(this).dialog('close');
            }
        },
        close: function () {
            allFields.val('').removeClass('ui-state-error');
        }
    });

    jQuery("#dialog-form-open").click(function () {
        jQuery("#dialog-form").dialog("open");
        return false;
    });
});