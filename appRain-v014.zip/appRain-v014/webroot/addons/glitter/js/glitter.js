/*var apprain_sliding_menu ={
	opacity: ".4",
	slide_wrapper: '.glitter',
	element: ".box",
	nodeObject : null,
	fadeOnload	   : false,
	clearOnMoveout : true,
	menuActive : function()
	{
		apprain_sliding_menu.inactiveAll();
		this.get('tween', {property: 'opacity', duration: 700}).start(1);
	},
	menuInActive : function()
	{
		alert(1)
		this.get('tween', {property: 'opacity', duration: 500}).start(apprain_sliding_menu.opacity);

		if( apprain_sliding_menu.clearOnMoveout )
		{
			apprain_sliding_menu.activeAll();
		}
	},
	inactiveAll: function ()
	{
		apprain_sliding_menu.nodeObject.each(function(e1)
		{
			e1.get('tween', {property: 'opacity', duration: 500}).start(apprain_sliding_menu.opacity);
		});

	},
	activeAll: function ()
	{
		apprain_sliding_menu.nodeObject.each(function(e1)
		{
			jQuery(e1).fadeOut();
			//e1.get('tween', {property: 'opacity', duration: 500}).start(1);
		});
	},
	init: function(){
		
		apprain_sliding_menu.nodeObject = jQuery(apprain_sliding_menu.slide_wrapper).children(apprain_sliding_menu.element);

		if( apprain_sliding_menu.fadeOnload )
		{
			apprain_sliding_menu.inactiveAll();
		}
		
		apprain_sliding_menu.nodeObject.each(function(k,e1)
		{alert(e1);
			jQuery(e1).css('cursor','pointer');
			jQuery(e1).mouseenter(apprain_sliding_menu.menuActive);
			jQuery(e1).mouseleave(apprain_sliding_menu.menuInActive);
		});
	}
}


jQuery(document).ready(apprain_sliding_menu.init);*/