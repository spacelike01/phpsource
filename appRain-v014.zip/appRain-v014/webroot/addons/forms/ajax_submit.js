/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */
var apprain_a_s ={
	action				: siteInfo.baseUrl,
	form				: '#auto_chk_submit',
	debug				: false,
	res_flag			: '',
	res_msg				: '',
	auto_hide			: true,
	message_holder		: '.erros_message',
	loading_img			: siteInfo.baseUrl + '/images/loading.gif',
	show_debug			: function(response){
							if( apprain_a_s.debug)
							{
								alert( response );
							}
						},
	s_ready:			function ()
						{
							return (!apprain_f_v.error);
						},
	process_on_success  : function()
						{
							jQuery(apprain_a_s.message_holder).html(apprain_a_s.res_msg);
							if( apprain_a_s.auto_hide )
							{
								jQuery(apprain_a_s.form).fadeOut();
							}
						},
	process_on_error	: function()
						{

							jQuery(apprain_a_s.message_holder).html(apprain_a_s.res_msg);
						},
	loading_image: 		function(flag )
						{
							if( flag == 'show')
							{
								jQuery(apprain_a_s.message_holder).html('&nbsp;');
								jQuery(apprain_a_s.message_holder).css("display","block");
								jQuery(apprain_a_s.message_holder).css('background','url(' + apprain_a_s.loading_img + ') no-repeat');
							}
							else jQuery(apprain_a_s.message_holder).css('background','none');
						},
	ajax_submit: 		function ()
						{
							apprain_a_s.loading_image('show');

							jQuery.ajax({
								url: jQuery(apprain_a_s.form).attr('action'),
								context: document.body,
								type: jQuery(apprain_a_s.form).attr('method'),
								data: jQuery(apprain_a_s.form).serialize(),
								success: function(responseTxt){
											apprain_a_s.loading_image('hide');
											apprain_a_s.show_debug(responseTxt);

											var responseObj = eval('(' + responseTxt + ')');

											apprain_a_s.res_flag = responseObj._status;
											apprain_a_s.res_msg = responseObj._message;

											if( apprain_a_s.res_flag.toLocaleLowerCase() == 'success') apprain_a_s.process_on_success();
											else if( apprain_a_s.res_flag.toLocaleLowerCase() == 'redirect') window.location = responseObj._location;
											else apprain_a_s.process_on_error();
										 }
							  });
						},
	init				: function(){
							try
							{
								apprain_a_s.form = as_form_name;
								apprain_a_s.debug = as_debug;
								apprain_a_s.message_holder = as_message_element;
								apprain_a_s.auto_hide = as_auto_hide;
								apprain_a_s.loading_img = loading_img;
							}
							catch (err){}
							jQuery(apprain_a_s.message_holder).html('&nbsp;');
							apprain_a_s.loading_image('hide');
							apprain_a_s.action = jQuery(apprain_a_s.form).get('action');
						}
}