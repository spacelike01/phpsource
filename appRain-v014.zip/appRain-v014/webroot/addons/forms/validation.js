/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */
var appValidate =
{
    _errBg	   : '#FF0000',
	_dflBg	   : '#FFFFFF',
	_errorMark : 'inline',
    _regExp    : {},
    _tmp_dt    : "Test",
    _fromName  : ".app_validation",
    _error     : false,
    _errLog    : Array(),
    _tipz	   : null,
    check      : function(e)
                 {
					jQuery('.inlineerror').remove();
					appValidate._error = false;

					jQuery('.app_validation').find('input[type=password],input[type=text],textarea,select').each(function(index,_obj){

                        if(_obj.offsetHeight > 0 || jQuery(_obj).hasClass('richtexteditor'))
                        {
                            appValidate.reset();
                            if(jQuery(_obj).hasClass("check_notempty")){appValidate.notEmpty(_obj);}
							if(jQuery(_obj).hasClass("check_notdefault")){appValidate.notDefault(_obj);}
                            if(jQuery(_obj).hasClass("check_email")){appValidate.email(_obj);}
                            if(jQuery(_obj).hasClass("check_password")){appValidate.password(_obj);}
                            //if(jQuery(_obj).hasClass("check_isimage")){appValidate.isImage(_obj);}
                            //if(jQuery(_obj).hasClass("check_isdoc")){appValidate.isDoc(_obj);}
                            //if(jQuery(_obj).hasClass("check_ispdf")){appValidate.isPdf(_obj);}
                            if(jQuery(_obj).hasClass("check_isnumber")){appValidate.isNumber(_obj);}
                            if(jQuery(_obj).hasClass("check_alphanumeric")){appValidate.alphaNumeric(_obj);}

                            if(appValidate._errLog.length>0)appValidate.displayErr(_obj,true);
                            else appValidate.displayErr(_obj,false);
                        }
                    });

					if(appValidate._error || _autoSubmit  == 'false')e.preventDefault();

					if(typeof(apprain_a_s) != "undefined" && appValidate._error == false)
					{
						if(apprain_a_s == true)
						{
							apprain_a_s.init();
							apprain_a_s.ajax_submit();
						}
					}
                 },
    reset      : function()
                 {
                    appValidate._errLog = Array();
                 },
    displayErr : function(_obj,errFlag)
                 {
                    if(errFlag)
					{
						appValidate._error = true;

						jQuery(_obj).addClass('error');

						/*if(appValidate._errToolTips != 'false')appValidate.addTTips(_obj);*/

						if(appValidate._errorMark=='background')
						{
							jQuery(_obj).css('background-color',appValidate._errBg);
						}
						else if (appValidate._errorMark=='inline')
						{
							jQuery('<span>').append(appValidate._errLog.join(","))
								   .addClass('inlineerror')
								   .appendTo(jQuery(_obj).parent());
						}
						/*else
						{
							jQuery(_obj).css('border','1px solid ' + appValidate._errBg);
						}*/
					}
                    else
					{
						jQuery(_obj).removeClass('error');
						//if(appValidate._errToolTips != 'false' && appValidate._tipz != null)appValidate._tipz.detach(_obj);
						if(appValidate._errorMark=='background')jQuery(_obj).css('background-color', appValidate._dflBg);
						//else jQuery(_obj).css('border','1px solid ' + appValidate._dflBg);
					}
                },
    /*addTTips   :function(_obj)
                {
                    _obj.store('tip:text', appValidate._errLog.join("<br />"));
                    appValidate._tipz = new Tips( _obj,{className: 'tipz'});
                    appValidate._tipz.addEvents({
                        'show': function(tip) {tip.fade('in');},
                        'hide': function(tip) {tip.fade('out');}
                    });
                },*/
	addToErrLog :function(_obj,msg)
				{
					appValidate._errLog.push((jQuery(_obj).attr('longdesc') ? jQuery(_obj).attr('longdesc') : msg));
				},
    notEmpty   :function(_obj)
                {
                    if(jQuery(_obj).val()=="")
					{
						appValidate.addToErrLog(_obj,'This field can not be left empty');
					}
                },
	notDefault  :function(_obj)
                {
                    if(jQuery(_obj).val()==jQuery(_obj).defaultValue())
					{
						appValidate.addToErrLog(_obj,'This field can not be left empty');
					}
                },
    email      :function(_obj)
                {
                    if(!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(jQuery(_obj).val())))
                    {
						appValidate.addToErrLog(_obj,'Please enter a valid Email Address');
                    }
                },
	password   :function(_obj)
                {
					var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])/;

                    if(!re.test(jQuery(_obj).val()))
                    {
						appValidate.addToErrLog(_obj,'Enter a valid Password (Length 8 and conbination A-Za-z0-9)');
                    }
                },
	isImage	   :function (_obj)
				{
					var ext = (/[.]/.exec(jQuery(_obj).val())) ? /[^.]+jQuery/.exec(jQuery(_obj).val()) : undefined;
					if(ext=="gif" || ext=="jpg" || ext=="png") return true;
					else
					{
						appValidate.addToErrLog(_obj,'Invalid image file entered. Supported extensions are *.gif, *.jpg, *.jpeg, *.png');
					}
				},
	isDoc	   :function (_obj)
				{
					var ext = (/[.]/.exec(jQuery(_obj).val())) ? /[^.]+jQuery/.exec(jQuery(_obj).val()) : "";
					if(ext=="doc" || ext=="docx" || ext=="txt" || ext=="rtf") return true;
					else
					{
						appValidate.addToErrLog(_obj,'Invalid document file entered. Supported extensions are *.doc, *.docx, *.txt, *.rtf');
					}
				},
	isPdf      :function (_obj)
				{
					var ext = (/[.]/.exec(jQuery(_obj).val())) ? /[^.]+jQuery/.exec(jQuery(_obj).val()) : undefined;
					if(ext=='pdf') return true;
					else
					{
						appValidate.addToErrLog(_obj,'Invalid Pdf file entered.');
					}
				},
	alphaNumeric:function (_obj)
				{
					var re = /^[\w ]+jQuery/;
					if(!re.test(jQuery(_obj).val()))
                    {
						appValidate.addToErrLog(_obj,'Aplha numeric value required');
                    }
				},
	isNumber   :function (_obj)
				{
					if(isNaN(jQuery(_obj).val()) || jQuery(_obj).val() == '')
					{
						appValidate.addToErrLog(_obj,'Please enter a valid numeric vlaue.');
					}
				},
	init	   :function(e)
                {
				    try
				    {
						appValidate._errBg = _errBg;
						appValidate._dflBg = _dflBg;
						appValidate._errToolTips = _errToolTips;
						appValidate._errorMark = _errorMark;

				    }
				    catch (err){}
					jQuery(appValidate._fromName).live('submit', appValidate.check);
                }
}

jQuery(document).ready(appValidate.init);