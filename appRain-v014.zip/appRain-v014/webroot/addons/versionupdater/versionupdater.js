/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */
var v_u ={
	obj				: { button :{_continue:"#continue_update", _cancel:"#cancel_update"},
						slider :{_check_update:null,_log_update:null}},

	cancel_update	: function()
					  {
						document.location = base + "/developer/update";
					  },
	do_update		: function()
					  {
							v_u.prepareUI();
							v_u.udateVersion('initialize');

					  },
	udateVersion    : function(state)
					  {
                          switch (state)
                          {
                                case 'initialize'		:
                                                        	v_u.getdefinition();
                                                        	break;
                                case 'parsedefinition'	:
                                                        	v_u.parsedefinition();
                                                        	break;
                                case 'preparation'		:
                                    						v_u.preparation('start');
                                    						break;
                                case 'createbackup'		:
            												v_u.createbackup('start');
            												break;
                                case 'download'		:
															v_u.download('start');
															break;
                                case 'review'		:
															v_u.review('start');
															break;
                                case 'install'		:
															v_u.install('start');
															break;
								case 'complete'		:
															v_u.complete();
															break;
                          }
					  },
	complete		  : function()
						{
						   v_u.addlog('Version Updated successfully.');
						   v_u.loading('start');
						   new Request({url:base,
								onSuccess: function(responseTxt)
								{
									responseObj = JSON.decode(responseTxt)
									v_u.addlog(responseObj.message);

                                    v_u.loading('end');

								},
								onFailure: function() {alert("Check your connection.");}
						   }).send({url:base + "/developer/versionupdateprocess/complete"});
						},
	install           : function(f)
    				  {
                          v_u.loading('start');
						  new Request({url:base,
								onSuccess: function(responseTxt)
								{
									responseObj = JSON.decode(responseTxt)
									v_u.addlog(responseObj.message);

									if(responseObj.nextstep == 'install' )
									{
										v_u.install('');
									}
									else
									{
										if(responseObj.status != 'Failed')v_u.udateVersion('complete');
									}
                                    v_u.loading('end');

								},
								onFailure: function() {alert("Check your connection.");}
						   }).send({url:base + "/developer/versionupdateprocess/install/" + f});
    				  },
	review 	          : function(f)
    				  {
                          v_u.loading('start');
						  new Request({url:base,
								onSuccess: function(responseTxt)
								{
									responseObj = JSON.decode(responseTxt)
									v_u.addlog(responseObj.message);

									if(responseObj.nextstep == 'review' )
									{
										v_u.review('');
									}
									else
									{
										if(responseObj.status != 'Failed')v_u.udateVersion('install');
									}
                                    v_u.loading('end');

								},
								onFailure: function() {alert("Check your connection.");}
						   }).send({url:base + "/developer/versionupdateprocess/review/" + f});
    				  },
	download 	    : function(f)
    				  {
                          v_u.loading('start');
						  new Request({url:base,
								onSuccess: function(responseTxt)
								{
									responseObj = JSON.decode(responseTxt)
									v_u.addlog(responseObj.message);

									if(responseObj.nextstep == 'download' )
									{
										v_u.download('');
									}
									else
									{
										if(responseObj.status != 'Failed')v_u.udateVersion('review');
									}
                                    v_u.loading('end');

								},
								onFailure: function() {alert("Check your connection.");}
						   }).send({url:base + "/developer/versionupdateprocess/download/" + f});
    				  },
	createbackup 	: function(f)
    				  {
                          v_u.loading('start');
						  new Request({url:base,
								onSuccess: function(responseTxt)
								{
									responseObj = JSON.decode(responseTxt)
									v_u.addlog(responseObj.message);

									if(responseObj.nextstep == 'createbackup' )
									{
										v_u.createbackup('');
									}
									else
									{
										if(responseObj.status != 'Failed')v_u.udateVersion('download');
									}
                                    v_u.loading('end');

								},
								onFailure: function() {alert("Check your connection.");}
						   }).send({url:base + "/developer/versionupdateprocess/createbackup/" + f});
    				  },
    preparation 	: function(f)
    				  {
                          v_u.loading('start');
						  new Request({url:base,
								onSuccess: function(responseTxt)
								{
									responseObj = JSON.decode(responseTxt)
									v_u.addlog(responseObj.message);

									if(responseObj.nextstep == 'preparation' )
									{
										v_u.preparation('');
									}
									else
									{
										if(responseObj.status != 'Failed')v_u.udateVersion('createbackup');
									}
                                    v_u.loading('end');

								},
								onFailure: function() {alert("Check your connection.");}
						   }).send({url:base + "/developer/versionupdateprocess/preparation/" + f});
    				  },
    parsedefinition	:  function()
                      {
                          v_u.loading('start');
						  new Request({url:base,
								onSuccess: function(responseTxt)
								{
							  		v_u.udateVersion('preparation');
                                    v_u.loading('end');
                                    responseObj = JSON.decode(responseTxt)
							  		v_u.addlog(responseObj.message);
								},
								onFailure: function() {alert("Check your connection.");}
						   }).send({url:base + "/developer/versionupdateprocess/parsedefinition"});
                      },
    getdefinition  : function ()
                      {
						  v_u.clearlog();
						  v_u.addlog('Initializing Request..');

						  v_u.loading('start');
						  new Request({url:base,
								onSuccess: function(responseTxt)
								{
									responseObj = JSON.decode(responseTxt)
									v_u.addlog(responseObj.message);
									v_u.loading('end');
									if(responseObj.status != 'Failed')v_u.udateVersion('parsedefinition');

								},
								onFailure: function() {alert("Check your connection.");}
						   }).send({url:base + "/developer/versionupdateprocess/getdefinition"});
                      },
    clearlog		: function()
    				  {
                    	  $$('.display_log').getChildren('li').each(function(e){ e.dispose();});
                      },
    addlog			: function(msg)
    				  {
                    	  var myFirstElement  = new Element('li', {'class': 'log-line'}).set('html', msg);
					  	  $$('.display_log').grab(myFirstElement, 'top');
    				  },
	loading			: function( flag )
					  {
						  if(flag == 'start')new Fx.Slide("log_signal").show();
						  else new Fx.Slide("log_signal").hide();
					  },
	prepareUI		: function()
					  {
						  v_u.obj.slider._check_update.toggle();
						  v_u.obj.slider._log_update.toggle();
					  },
	init			: function()
			  		  {
						  	v_u.obj.slider._check_update = new Fx.Slide("form_check_update");
						  	v_u.obj.slider._log_update = new Fx.Slide("log_update").hide();
							//alert('v_u.obj.button._continue');
			  				$$(v_u.obj.button._continue).addEvent('click', v_u.do_update);
							$$(v_u.obj.button._cancel).addEvent('click', v_u.cancel_update);
			  		  }
}
window.addEvent('load', v_u.init);