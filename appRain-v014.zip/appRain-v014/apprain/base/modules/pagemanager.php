<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

class appRain_Base_Modules_PageManager extends appRain_Base_Objects
{
    const CONTENT = 'Content';
    const SNIP = 'Snip';
    /**
     * Base function to call Page Section
     *
     * @param $type String
     * @return Object
     */
    public function PageManager()
    {
        $this->setFetchtype('PageManager');
        return $this;
    }

    /*public function getPage($pageName = NULL)
    {
        return $this->getData($pageName);
    }*/

    /**
     * Get Page data
     */
    public function getData($pageName = NULL, $fieldName = NULL, $cnd="")
    {
        $status_id = App::getUserStatusId();
        if($cnd!="")$cnd = "AND ($cnd)";

        if(isset($pageName))
        {
            $data = App::Load("Model/Page")->find("name='{$pageName}' AND fkey=$status_id $cnd");
            return isset($data[$fieldName]) ? $data[$fieldName] : $data;
        }
        else
        {
            return App::Load("Model/Page")->findAll("fkey=$status_id $cnd");
        }
    }

    /**
     * To process get static page information
     *
     * @param $flag String
     * @param $flag2 String
     */
    public function pages( $flag = "all", $flag2 = NULL)
    {

        $status_id = App::getUserStatusId();

        switch( $flag )
        {
            case "name_only":

                                $page_arr  =  App::Load("Model/Page")->findAll("fkey=$status_id");
                                $data = array();
                                foreach( $page_arr['data'] as $key => $val )$data[$val['id']] = $val['name'];
                                return $data;
                                break;
            case "title_only":
                                $page_arr  =  App::Load("Model/Page")->findAll("fkey=$status_id");
                                $data = array();
                                foreach( $page_arr['data'] as $key => $val )$data[$val['id']] = $val['title'];
                                return $data;
                                break;
            case "by_name"   :
                                return  App::Load("Model/Page")->findAll("name='$flag2' AND fkey=$status_id");
                                break;
            case "all":
                                return  App::Load("Model/Page")->findAll("fkey=$status_id ORDER BY title ASC");
                                break;
            default:
                                return App::Load("Model/Page")->findById("$flag");
                                break;
        }
    }

    public function registerCallBacks()
    {
        $status_id = App::getUserStatusId();
        $pages = App::Load("Model/Page")->findAll("(hook<>'' OR rendertype<>'') AND fkey=$status_id");

        foreach($pages['data'] as $page)
        {
            if($page['hook'] == 'sitemenu')
            {
                App::Module('Hook')->setHookName('Sitemenu')
                           ->setAction("register_sitemenu")
                           ->Register(get_class($this),"register_sitemenu",$page);
            }
            else
            {
                App::Module('Hook')->setHookName('UI')
                           ->setAction($page['hook'])
                           ->Register(get_class($this),"register_page_to_hook",$page);

            }

            App::Module('Hook')->setHookName('URIManager')
                           ->setAction("on_initialize")
                           ->Register(get_class($this),"register_newrole",$page);

        }
    }

    public function register_sitemenu($send,$data)
    {
        $menu = Array();
        if($data['rendertype']=='smart_h_link') $menu[] = Array(App::Helper('Config')->baseurl(strtolower("/{$data['name']}")),"{$data['title']}",strtolower("{$data['name']}"));
        //else if($data['rendertype']=='text') $menu[] = Array("",$data['content']);
        else $menu[] = Array(App::Helper('Config')->baseurl(strtolower("/page/view/{$data['name']}")),"{$data['title']}",strtolower("{$data['name']}"));

        return $menu;
    }

    public function register_page_to_hook($send=null,$data)
    {
        switch($data['rendertype'])
        {
            case 'smart_h_link' :
                            return " " . App::Helper('Html')->linkTag(App::Helper('Config')->baseUrl(strtolower("/{$data['name']}"),$data['title'])) . " ";
                            break;
            case 'text' :
                            return $data['content'];
                            break;
            default 	:
                            return " " . App::Helper('Html')->linkTag(App::Helper('Config')->baseUrl(strtolower("/page/view/{$data['name']}"),$data['title'])) . " ";
                            break;
        }
    }

    public function register_newrole($def=null,$data)
    {
        if($data['rendertype'] == 'smart_h_link')
        {
            $def['pagerouter'][] = array("actual"=>Array("page","view",$data['name']),"virtual"=>Array($data['name']));
        }
        return $def;
    }
}