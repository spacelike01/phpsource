<?php
/**
 * appRain v 0.1.x
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

abstract class appRain_Base_Modules_Javascript extends appRain_Base_Objects
{
    /**
     * Process the validation map
     * -----------------------------------------------------------------
     * @param $map Array()
     * @param $options Array()
     * @return String
     */
    public function validation_map($options = NULL)
    {
        $auto_submit = isset( $options['_autoSubmit']) ?  $options['_autoSubmit'] : 'false';
        $error_background = isset($options['_errBg']) ? $options['_errBg'] : '#FF5555';
        $default_background = isset($options['_dflBg']) ? $options['_dflBg'] : '#FFFFFF';
        $_errToolTips = isset($options['_errToolTips']) ? $options['_errToolTips'] : 'true';
        $_errorMark = isset($options['_errorMark']) ? $options['_errorMark'] : 'inline';

        $str  = "\n var _errBg = '$error_background';";
        $str .= "\n var _dflBg = '$default_background';";
        $str .= "\n var _autoSubmit = '$auto_submit';";
        $str .= "\n var _errToolTips = '$_errToolTips';";
        $str .= "\n var _errorMark = '$_errorMark';";

        return App::Load("Helper/Html")->get_tag('script',array('type'=> 'text/javascript'),$str);
    }

    /**
     * Create a configuration for Ajax Sumin
     * echo $this->ajax_submit(array("form_name"=>"#auto_chk_submit","debug"=>"false","auto_hide"=>"false"));
     *
     * @return String
     */
    public function ajax_submit($options = NULL)
    {
            $debug = 'false';
            if(app::__def()->sysConfig('DEBUG_MODE')) $debug = isset( $options['debug']) ?  $options['debug'] : 'false';
            $form_name = isset($options['form_name']) ? $options['form_name'] : '#auto_chk_submit';
            $message_element = isset($options['message_element']) ? $options['message_element'] : '.erros_message';
            $auto_hide = isset($options['auto_hide']) ? $options['auto_hide'] : 'ture';
            $loading_img = isset($options['loading_img']) ? $options['loading_img'] : "siteInfo.baseUrl + '/images/loading.gif'";

            $str  = "\n	var as_debug = $debug;";
            $str .= "\n var as_form_name = '$form_name';";
            $str .= "\n var as_message_element = '$message_element';";
            $str .= "\n var as_auto_hide = $auto_hide;";
            $str .= "\n var as_loading_img = $loading_img;";

            return App::Load("Helper/Html")->get_tag('script',array('type'=> 'text/javascript'),$str);
    }
    
    public function autoComplete($JSReferance="",$data=array())
    {
        
        $JSONData = App::Module('Cryptography')->jsonEncode(array_unique($data));
        
    
        return 
        '<script type="text/javascript">
                            jQuery(document).ready(function () {
                                jQuery("' . $JSReferance . '").autocomplete({
                                    source: ' . $JSONData . '
                                });
                            });
                        </script>';
    }
}