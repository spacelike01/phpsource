DROP TABLE "%--%_app";
DROP TABLE "%--%_app_menus";
DROP TABLE "%--%_app_form";
DROP TABLE "%--%_app_form_data";