DROP TABLE IF EXISTS `%--%_app`;
DROP TABLE IF EXISTS `%--%_app_menus`;
DROP TABLE IF EXISTS `%--%_app_form`;
DROP TABLE IF EXISTS `%--%_app_form_data`;